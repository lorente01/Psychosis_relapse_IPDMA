# Authored: Jose M Rubio M.D // jrubio13@northwell.edu
# Checked: George Schoretsanitis M.D.,PhD
# April 9th 2020

##COHORT: LILLY-F1D-MC-HGKA-1
#####################################################
# a function to match and merge from two datasets

match.and.merge.func <- function(dat1.id, dat2.id, dat2.var){
  dat1.var <- array( ,length(dat1.id))
  for(i in 1:length(dat1.id)){
    for(j in 1:length(dat2.id)){
      if(dat1.id[i]==dat2.id[j]){dat1.var[i]<-dat2.var[j]}}}
  return(dat1.var)                                      }

##IDENTIFY TOTAL DATASET
#Select only subject IDs allocated to arm 1. 

subjinfo.dat <- read.table("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
sdy.ids.u.1<-subjinfo.dat$SUBJID[subjinfo.dat$TRTSORT==1]
response.ids <-sdy.ids.u.1[!is.na(sdy.ids.u.1)] # ok 5-17-19

########DEFINE STATUS PER DATASET (1=event; 0=censor)
#here we give 1 for subjects, for whom visit.dat$EXBFLG=1

subijnfo.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
exb<-subjinfo.dat$EXBFLG
exb[is.na(exb)]<-0
subjinfo.ids.u<-unique(subjinfo.dat$SUBJID)

status.res<-match.and.merge.func(response.ids,subjinfo.ids.u,exb) # ok 5-17-19

######DEFINE TIME TO EVENT PER DATASET 
#here we take the time to relapse, which is provided by visit.dat$TMTEXB

subjinfo.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
tmtexb<-subjinfo.dat$TMTEXB
subjinfo.ids.u<-unique(subjinfo.dat$SUBJID)

time.to.event.res<-match.and.merge.func(response.ids,subjinfo.ids.u,tmtexb) # ok 5-17-19

######SURVIVAL ANALYSIS
library(survival)
surv.obj.res <- Surv(time.to.event.res, status.res)

survfit(surv.obj.res~1)

study1.surv.fit.res <- survfit(surv.obj.res~1)

plot(study1.surv.fit.res, xlab = "days", ylab = "survival function") # ok 5-17-19

#####CALCULATE PERSON YEARS AND ABSOLUTE AND PERSON X YEAR INCIDENCE RATE
#person-year
per.year.res<-sum(time.to.event.res)/365 # ok 5-17-19

#absolute incidence
abs.inc.res<-length(status.res[status.res==1])/length(status.res)*100 # ok 5-17-19

#incidence by 100 person-years

py.inc.res<-length(status.res[status.res==1])/per.year.res*100 # ok 5-17-19

######COVARIATES
demog.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")

sex.res <- match.and.merge.func(response.ids, demog.dat$SUBJID, demog.dat$SEX) # ok 5-17-19

age.res <- match.and.merge.func(response.ids, demog.dat$SUBJID, demog.dat$AGEYR) # ok 5-17-19

country<-as.character(demog.dat$COUNTRY)
demog.ids.u<-unique(demog.dat$SUBJID)
us<-array(0,length(demog.ids.u))
for(i in 1:length(demog.ids.u)){
  temp.country<-country[demog.dat$SUBJID==demog.ids.u[i]]
  if(temp.country=="US"){us[i]<-1}}

region.res <- match.and.merge.func(response.ids, demog.dat$SUBJID, us) # ok 5-17-19

vital.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",") 

weight.kg<-vital.dat$WGTKGBL
height.cm<-vital.dat$HGTCMBL							                               						

weight.res <- match.and.merge.func(response.ids, vital.dat$SUBJID, weight.kg)
height.res <- match.and.merge.func(response.ids, vital.dat$SUBJID, height.cm)

BMI.res<-weight.res/(height.res/100)^2  # ok 5-17-19

aims.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/aims.csv", header=TRUE, sep=",")
ad1 <- aims.dat[(aims.dat$AIMSBLFLGII==1)&(aims.dat$AIMSQSNUM=="AIMSS8"),] 
ad1.ids.u <- unique(ad1$SUBJID) #here we select the unique IDs
aiscorec.sum <- array(,length(ad1.ids.u)) 
for (i in 1:length(ad1.ids.u)){
  temp<-ad1$AIMSRN[ad1$SUBJID==ad1.ids.u[i]]
  if(temp>2){aiscorec.sum[i] <- 1 }else{aiscorec.sum[i] <- 0}}

aims.res <- match.and.merge.func(response.ids, ad1.ids.u, aiscorec.sum) # ok 5-17-19

bars.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/barnes.csv", header=TRUE, sep=",")
ba1<-bars.dat[(bars.dat$BARBLFLGII==1)&(bars.dat$BARQSNUM=="BARS4"),] 
ba1.ids.u <- unique(ba1$SUBJID)
bascorec.sum <-array(,length(ba1.ids.u))	
for (i in 1:length(ba1.ids.u)){
  temp<-ba1$BARRN[ba1$SUBJID==ba1.ids.u[i]]
  if(temp>2){bascorec.sum[i]<-1}else{bascorec.sum[i]<-0}}

bars.res<- match.and.merge.func(response.ids, ba1.ids.u,bascorec.sum) # ok 5-17-19

cgi.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/gi.csv", header=TRUE, sep=",")
cgi1 <- cgi.dat[(cgi.dat$GIBLFLGII==1)&(cgi.dat$GIQSNUM=="CGISS"),]
cgi.ids.u <- unique(cgi1$SUBJID) 
cgi.bl <- array(,length(cgi.ids.u)) 
for (i in 1:length(cgi.ids.u)){
  cgi.bl[i] <- cgi1$GIRN[cgi1$SUBJID==cgi.ids.u[i]]
}

cgi.res <- match.and.merge.func(response.ids, cgi.ids.u, cgi.bl) # ok 5-17-19

subjinfo.table <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
date.bl<-as.Date(subjinfo.table$ENRLDT,"%d%B%Y")
date.bl1<-as.character(date.bl)
year.bl.d.1<-substr(date.bl1,1,4)

year.bl.res <- match.and.merge.func(response.ids, subjinfo.table$SUBJID, year.bl.d.1)

n.year.bl.2<- as.numeric(year.bl.res) # ok 5-17-19

psyhistp.table <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/psyhistp.csv", header=TRUE, sep=",")
onset<-psyhistp.table$DISONSDTYY

y.onset.2  <- match.and.merge.func(response.ids, psyhistp.table$SUBJID, onset)

doi.res<- n.year.bl.2 - y.onset.2 # ok 5-17-19

age.diag.res <- age.res-doi.res # ok 5-17-19

subjinfo.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
tobacco<-subjinfo.dat$TBBL

nicotine.res <- match.and.merge.func(response.ids, subjinfo.table$SUBJID, tobacco)  # ok 5-17-19

panss.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/panss.csv", header=TRUE, sep=",")
panss.dat.bas <- panss.dat[panss.dat$PNSBLFLGII == 1,]
panss.id.u<-unique(panss.dat.bas$SUBJID)

panss.gen<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array1<-panss.dat.bas$PNSRN[panss.dat.bas$SUBJID==panss.id.u[i] & panss.dat.bas$PNSQSNUM=="PNSPSYP"]
  panss.gen[i]<-sum(temp.array1,na.rm=T)}

panss.gen.res <- match.and.merge.func(response.ids, panss.id.u, panss.gen) # ok 5-17-19

panss.total<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array2<-panss.dat.bas$PNSRN[panss.dat.bas$SUBJID==panss.id.u[i] & panss.dat.bas$PNSQSNUM=="PNS30TS" ]
  panss.total[i]<-sum(temp.array2,na.rm=T)}

panss.tot.res <- match.and.merge.func(response.ids, panss.id.u, panss.total) # ok 5-17-19

panss.neg<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array3<-panss.dat.bas$PNSRN[panss.dat.bas$SUBJID==panss.id.u[i] & panss.dat.bas$PNSQSNUM=="PNSNEG"]
  panss.neg[i]<-sum(temp.array3,na.rm=T)}

panss.neg.res <- match.and.merge.func(response.ids, panss.id.u, panss.neg) # ok 5-17-19

panss.pos<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array4<-panss.dat.bas$PNSRN[panss.dat.bas$SUBJID==panss.id.u[i] & panss.dat.bas$PNSQSNUM=="PNSPS" ]
  panss.pos[i]<-sum(temp.array4,na.rm=T)}

panss.pos.res <- match.and.merge.func(response.ids, panss.id.u, panss.pos) # ok 5-17-19

simpson.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/simpson.csv", header=TRUE, sep=",")

simpson <- simpson.dat[(simpson.dat$SABLFLGII==1)&(simpson.dat$SAQSNUM=="SATS"),] 
simpson.ids.u <- unique(simpson$SUBJID) #here we select the unique IDs
simpson.tot <- array(,length(ad1.ids.u)) 
for (i in 1:length(ad1.ids.u)){
  temp.array <- simpson$SARN[simpson$SUBJID==simpson.ids.u[i]]
  temp.array2<-sum(temp.array,na.rm=T)/10
  if(temp.array2>0.65){simpson.tot[i] <- 1}else{simpson.tot[i]<-0}} 

eps.res <- match.and.merge.func(response.ids, simpson.ids.u, simpson.tot) # ok 5-17-19

#NUMBER OF EPISODES IN LAST 24M 
psyhistp.table <- read.table("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/psyhistp.csv", header=TRUE, sep=",")
pr.ep<-psyhistp.table$MHN
pr.ep[pr.ep<3]<-0
pr.ep[pr.ep>2]<-1

pr.ep.res  <- match.and.merge.func(response.ids, psyhistp.table$SUBJID, pr.ep) # ok 5-17-19

#TIME SINCE LAST DC

psyhistp.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/psyhistp.csv", header=TRUE, sep=",")
date.dc<-as.Date(psyhistp.dat$MRDT,"%d%B%Y")
date.dc1 <- as.character(date.dc)

date.dc.1.res<-match.and.merge.func(response.ids, psyhistp.dat$SUBJID, date.dc1)

date.dc.d.1.res<-as.Date(date.dc.1.res)

subjinfo.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
date.bl<-as.Date(subjinfo.dat$ENRLDT,"%d%B%Y")
date.bl1<-as.character(date.bl)

date.bl.1.res<-match.and.merge.func(response.ids, subjinfo.dat$SUBJID, date.bl1)

date.bl.d.1.res<-as.Date(date.bl.1.res)

last.hosp.res<-date.bl.d.1.res-date.dc.d.1.res 
last.hosp.res[last.hosp.res<365]<-1
last.hosp.res[last.hosp.res>364]<-0

# ok 5-17-19

#FAMILY HISTORY OF PSYCHOSIS
psyhistf.dat.1 <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGKA/Files/Analysis Datasets/R_analysis/psyhistf.csv", header=TRUE, sep=",")
psyhistf.dat <- psyhistf.dat.1[psyhistf.dat.1$PSYHISTFQSNUM=="MHOCCUR160",]
ids.fh.u<-unique(psyhistf.dat$SUBJID)
famhx.prov<-array(,length(ids.fh.u))

for(i in 1:length(ids.fh.u)){
  famhx.prov[i]<-psyhistf.dat$PSYHISTFRN[psyhistf.dat$SUBJID==ids.fh.u[i]]}
famhx.prov[famhx.prov==97]<-NA

famhx.res  <- match.and.merge.func(response.ids, psyhistf.dat$SUBJID, famhx.prov) # ok 5-17-19

#####COX REGRESSION

coxph(formula = surv.obj.res ~sex.res ) #

coxph(formula = surv.obj.res ~age.res )#

coxph(formula = surv.obj.res ~region.res)#

coxph(formula = surv.obj.res ~BMI.res)#

coxph(formula = surv.obj.res ~aims.res )

coxph(formula = surv.obj.res ~bars.res )	 

coxph(formula = surv.obj.res ~cgi.res )#

coxph(formula = surv.obj.res ~age.diag.res )#

coxph(formula = surv.obj.res ~doi.res)#

coxph(formula = surv.obj.res ~nicotine.res )#

coxph(formula = surv.obj.res ~panss.gen.res) #

coxph(formula = surv.obj.res ~panss.neg.res) #

coxph(formula = surv.obj.res ~panss.pos.res) #

coxph(formula = surv.obj.res ~panss.tot.res)#

coxph(formula = surv.obj.res ~pr.ep.res) #

coxph(formula = surv.obj.res ~last.hosp.res) #

coxph(formula = surv.obj.res ~eps.res) #

coxph(formula = surv.obj.res ~ famhx.res)#

######CALCULATE HR AND 95%CI

sex.hr.res<-coxph(formula = surv.obj.res ~sex.res )

se.sex.hr.res<-sqrt(sex.hr.res[[2]])
beta.sex.hr.res<-sex.hr.res[[1]]

up.lim.sex.hr.res<-exp(beta.sex.hr.res+(1.96*se.sex.hr.res))
low.lim.sex.hr.res<-exp(beta.sex.hr.res-(1.96*se.sex.hr.res))
hr.sex.res<-exp(beta.sex.hr.res)

age.hr.res<-coxph(formula = surv.obj.res ~age.res )

se.age.hr.res<-sqrt(age.hr.res[[2]])
beta.age.hr.res<-age.hr.res[[1]]

up.lim.age.hr.res<-exp(beta.age.hr.res+(1.96*se.age.hr.res))
low.lim.age.hr.res<-exp(beta.age.hr.res-(1.96*se.age.hr.res))
hr.age.res<-exp(beta.age.hr.res)

reg.hr.res<-coxph(formula = surv.obj.res ~region.res)

se.reg.hr.res<-sqrt(reg.hr.res[[2]])
beta.reg.hr.res<-reg.hr.res[[1]]

up.lim.reg.hr.res<-exp(beta.reg.hr.res+(1.96*se.reg.hr.res))
low.lim.reg.hr.res<-exp(beta.reg.hr.res-(1.96*se.reg.hr.res))

hr.reg.res<-exp(beta.reg.hr.res)

bmi.hr.res<-coxph(formula = surv.obj.res ~BMI.res)

se.bmi.hr.res<-sqrt(bmi.hr.res[[2]])
beta.bmi.hr.res<-bmi.hr.res[[1]]

up.lim.bmi.hr.res<-exp(beta.bmi.hr.res+(1.96*se.bmi.hr.res))
low.lim.bmi.hr.res<-exp(beta.bmi.hr.res-(1.96*se.bmi.hr.res))
hr.bmi.res<-exp(beta.bmi.hr.res)

aim.hr.res<-coxph(formula = surv.obj.res ~aims.res )

se.aim.hr.res<-sqrt(aim.hr.res[[2]])
beta.aim.hr.res<-aim.hr.res[[1]]

up.lim.aim.hr.res<-exp(beta.aim.hr.res+(1.96*se.aim.hr.res))
low.lim.aim.hr.res<-exp(beta.aim.hr.res-(1.96*se.aim.hr.res))
hr.aim.res<-exp(beta.aim.hr.res)

bar.hr.res<-coxph(formula = surv.obj.res ~bars.res )

se.bar.hr.res<-sqrt(bar.hr.res[[2]])
beta.bar.hr.res<-bar.hr.res[[1]]

up.lim.bar.hr.res<-exp(beta.bar.hr.res+(1.96*se.bar.hr.res))
low.lim.bar.hr.res<-exp(beta.bar.hr.res-(1.96*se.bar.hr.res))
hr.bar.res<-exp(beta.bar.hr.res)

cgi.hr.res<-coxph(formula = surv.obj.res ~cgi.res )

se.cgi.hr.res<-sqrt(cgi.hr.res[[2]])
beta.cgi.hr.res<-cgi.hr.res[[1]]

up.lim.cgi.hr.res<-exp(beta.cgi.hr.res+(1.96*se.cgi.hr.res))
low.lim.cgi.hr.res<-exp(beta.cgi.hr.res-(1.96*se.cgi.hr.res))
hr.cgi.res<-exp(beta.cgi.hr.res)

dia.hr.res<-coxph(formula = surv.obj.res ~age.diag.res )

se.dia.hr.res<-sqrt(dia.hr.res[[2]])
beta.dia.hr.res<-dia.hr.res[[1]]

up.lim.dia.hr.res<-exp(beta.dia.hr.res+(1.96*se.dia.hr.res))
low.lim.dia.hr.res<-exp(beta.dia.hr.res-(1.96*se.dia.hr.res))
hr.dia.res<-exp(beta.dia.hr.res)

doi.hr.res<-coxph(formula = surv.obj.res ~doi.res)

se.doi.hr.res<-sqrt(doi.hr.res[[2]])
beta.doi.hr.res<-doi.hr.res[[1]]

up.lim.doi.hr.res<-exp(beta.doi.hr.res+(1.96*se.doi.hr.res))
low.lim.doi.hr.res<-exp(beta.doi.hr.res-(1.96*se.doi.hr.res))
hr.doi.res<-exp(beta.doi.hr.res)

nic.hr.res<-coxph(formula = surv.obj.res ~nicotine.res )

se.nic.hr.res<-sqrt(nic.hr.res[[2]])
beta.nic.hr.res<-nic.hr.res[[1]]

up.lim.nic.hr.res<-exp(beta.nic.hr.res+(1.96*se.nic.hr.res))
low.lim.nic.hr.res<-exp(beta.nic.hr.res-(1.96*se.nic.hr.res))
hr.nic.res<-exp(beta.nic.hr.res)

gen.hr.res<-coxph(formula = surv.obj.res ~panss.gen.res) 

se.gen.hr.res<-sqrt(gen.hr.res[[2]])
beta.gen.hr.res<-gen.hr.res[[1]]

up.lim.gen.hr.res<-exp(beta.gen.hr.res+(1.96*se.gen.hr.res))
low.lim.gen.hr.res<-exp(beta.gen.hr.res-(1.96*se.gen.hr.res))
hr.gen.res<-exp(beta.gen.hr.res)

neg.hr.res<-coxph(formula = surv.obj.res ~panss.neg.res) 

se.neg.hr.res<-sqrt(neg.hr.res[[2]])
beta.neg.hr.res<-neg.hr.res[[1]]

up.lim.neg.hr.res<-exp(beta.neg.hr.res+(1.96*se.neg.hr.res))
low.lim.neg.hr.res<-exp(beta.neg.hr.res-(1.96*se.neg.hr.res))
hr.neg.res<-exp(beta.neg.hr.res)

pos.hr.res<-coxph(formula = surv.obj.res ~panss.pos.res) 

se.pos.hr.res<-sqrt(pos.hr.res[[2]])
beta.pos.hr.res<-pos.hr.res[[1]]

up.lim.pos.hr.res<-exp(beta.pos.hr.res+(1.96*se.pos.hr.res))
low.lim.pos.hr.res<-exp(beta.pos.hr.res-(1.96*se.pos.hr.res))
hr.pos.res<-exp(beta.pos.hr.res)

tot.hr.res<-coxph(formula = surv.obj.res ~panss.tot.res)

se.tot.hr.res<-sqrt(tot.hr.res[[2]])
beta.tot.hr.res<-tot.hr.res[[1]]

up.lim.tot.hr.res<-exp(beta.tot.hr.res+(1.96*se.tot.hr.res))
low.lim.tot.hr.res<-exp(beta.tot.hr.res-(1.96*se.tot.hr.res))
hr.tot.res<-exp(beta.tot.hr.res)

pre.hr.res<-coxph(formula = surv.obj.res ~pr.ep.res) 

se.pre.hr.res<-sqrt(pre.hr.res[[2]])
beta.pre.hr.res<-pre.hr.res[[1]]

up.lim.pre.hr.res<-exp(beta.pre.hr.res+(1.96*se.pre.hr.res))
low.lim.pre.hr.res<-exp(beta.pre.hr.res-(1.96*se.pre.hr.res))
hr.pre.res<-exp(beta.pre.hr.res)

las.hr.res<-coxph(formula = surv.obj.res ~last.hosp.res) 

se.las.hr.res<-sqrt(las.hr.res[[2]])
beta.las.hr.res<-las.hr.res[[1]]

up.lim.las.hr.res<-exp(beta.las.hr.res+(1.96*se.las.hr.res))
low.lim.las.hr.res<-exp(beta.las.hr.res-(1.96*se.las.hr.res))
hr.las.res<-exp(beta.las.hr.res)

eps.hr.res<-coxph(formula = surv.obj.res ~eps.res) 

se.eps.hr.res<-sqrt(eps.hr.res[[2]])
beta.eps.hr.res<-eps.hr.res[[1]]

up.lim.eps.hr.res<-exp(beta.eps.hr.res+(1.96*se.eps.hr.res))
low.lim.eps.hr.res<-exp(beta.eps.hr.res-(1.96*se.eps.hr.res))
hr.eps.res<-exp(beta.eps.hr.res)

fam.hr.res<-coxph(formula = surv.obj.res ~famhx.res) 

se.fam.hr.res<-sqrt(fam.hr.res[[2]])
beta.fam.hr.res<-fam.hr.res[[1]]

up.lim.fam.hr.res<-exp(beta.fam.hr.res+(1.96*se.fam.hr.res))
low.lim.fam.hr.res<-exp(beta.fam.hr.res-(1.96*se.fam.hr.res))
hr.fam.res<-exp(beta.fam.hr.res)


#####SUMMARY TABLES

colname.desc.cont<- c("Age (mean)", "Age (SD)", "BMI (mean)", "BMI (SD)","Age at diagnosis (mean)","Age at diagnosis (SD)","Duration of illness (mean)",
                      "Duration of illness (SD)", "CGI (mean)","CGI (SD)","Psychopathology total score (mean)","Psychopathology total score (SD)", 
                      "Psychopathology general score (mean)","Psychopathology general score (SD)","Psychopathology positive score (mean)","Psychopathology positive score (SD)",
                      "Psychopathology negative score (mean)","Psychopathology negative score (SD)","General functioning score (mean)","General functioning score (SD)", 
                      "Quality of life score (mean)","Quality of life score (SD)")




mean.age.res<-mean(age.res, na.rm=T)

sd.age.res<-sd(age.res,na.rm=T)

mean.BMI.res<-mean(BMI.res,na.rm=T)

sd.BMI.res<-sd(BMI.res,na.rm=T)

mean.agediagnosis.res<-mean(age.diag.res, na.rm=T)

sd.agediagnsosis.res<-sd(age.diag.res,na.rm=T)

mean.doi.res<-mean(doi.res,na.rm=T)

sd.doi.res<-sd(doi.res,na.rm=T)

mean.cgi.res<-mean(cgi.res,na.rm=T)

sd.cgi.res<-sd(cgi.res,na.rm=T)

mean.totps.res<-mean(panss.tot.res,na.rm=T)

sd.totps.res<-sd(panss.tot.res, na.rm=T)

mean.genps.res<-mean(panss.gen.res,na.rm=T)
sd.genps.res<-sd(panss.gen.res,na.rm=T)
mean.posps.res<-mean(panss.pos.res,na.rm=T)

sd.posps.res<-sd(panss.pos.res,na.rm=T)

mean.negps.res<-mean(panss.neg.res,na.rm=T)

sd.negps.res<-sd(panss.neg.res,na.rm=T)

mean.func.res<-NA
sd.func.res<-NA
mean.qol.res<-NA

sd.qol.res<-NA



desc.cont.res<-c(mean.age.res,sd.age.res,mean.BMI.res,sd.BMI.res,mean.agediagnosis.res,sd.agediagnsosis.res,mean.doi.res,sd.doi.res,mean.cgi.res,sd.cgi.res,mean.totps.res,sd.totps.res,mean.genps.res,sd.genps.res,mean.posps.res,sd.posps.res,mean.negps.res,sd.negps.res,mean.func.res,sd.func.res,mean.qol.res,sd.qol.res)



desc.cont.mat.res<-rbind(colname.desc.cont,desc.cont.res)



colname.desc.cat<- c("Male (n)","Male (%)", "US (n)", "US (%)", "Family history (n)", "Family history (%)", "Smoking (n)", "Smoking (%)",
                     "Drug use (n)", "Drug use (%)","Moderate TD (n)","Moderate TD (%)","Moderate akathisia (n)","Moderate akathisia (%)","Moderate EPS (n)","Moderate EPS (%)","Hospitalized within last year (n)","Hospitalized within last year (%)","3 or more previous hospitalizations (n)","3 or more previous hospitalizations (%)")



n.male.res<- length(sex.res[sex.res==2])

perc.male.res<-length(sex.res[sex.res==2])/length(sex.res)*100

n.us.res<- length(response.ids)

perc.us.res<-100

n.fhx.res<- length(famhx.res[famhx.res==1])
perc.fhx.res<- n.fhx.res/length(famhx.res)*100
n.smok.res<-length(nicotine.res[nicotine.res==1])
perc.smok.res<-length(nicotine.res[nicotine.res==1])/length(nicotine.res)*100

n.drug.res<- NA
perc.drug.res<-NA
n.aims.res<-length(aims.res[aims.res==1])
perc.aims.res<-n.aims.res/length(aims.res)*100
n.bars.res<-length(bars.res[bars.res==1])
perc.bars.res<-n.bars.res/length(bars.res)*100
n.eps.res<-length(eps.res[eps.res==1])
perc.eps.res<-n.eps.res/length(eps.res)*100
n.hosplastyr<-length(last.hosp.res[last.hosp.res==1])
perc.hosp.lastyr<-n.hosplastyr/length(last.hosp.res)*100
n.more2hosp<-length(pr.ep.res[pr.ep.res==1])
perc.more2hosp<-n.more2hosp/length(pr.ep.res)*100



desc.cat.res<-c(n.male.res,perc.male.res,n.us.res,perc.us.res,n.fhx.res,perc.fhx.res,n.smok.res,perc.smok.res,n.drug.res,perc.drug.res,n.aims.res,perc.aims.res,n.bars.res,perc.bars.res,n.eps.res,perc.eps.res,n.hosplastyr,
                perc.hosp.lastyr,n.more2hosp,perc.more2hosp)



desc.cat.mat.res<-rbind(colname.desc.cat,desc.cat.res)

colname.outc<-c("Total sample 'n'","Relapse 'n'","Relapse '%'","Median time to relapse(days)","Events per 100 patient-years")




n.total.res<-length(response.ids)

n.relapse.res<-length(status.res[status.res==1])

perc.relapse.res<-length(status.res[status.res==1])/length(status.res)*100

median.time.res<-median(time.to.event.res, na.rm=T)

py.inc.res



outc.res<-c(n.total.res,n.relapse.res,perc.relapse.res,median.time.res,py.inc.res)



outc.mat.res<-rbind(colname.outc,outc.res)



colname.HR<-c("Male gender HR","Male gender Lower 95% CI","Male gender Upper 95% CI","Age HR", "Age Lower 95% CI","Age	Upper 95% CI","Proportion US HR",
              "Proportion US Lower 95% CI","Proportion US Upper 95% CI","BMI HR",  "BMI Lower 95% CI","BMI Upper 95% CI", "Age at diagnosis HR",
              "Age at diagnosis Lower 95% CI","Age at diagnosis Upper 95% CI","Duration of illness HR","Duration of illness Lower 95% CI","Duration of illness Upper 95% CI",
              "Time since last hospitalization HR","Time since last hospitalization Lower 95% CI","Time since last hospitalization Upper 95% CI",
              "Number of previous hospitalizations HR","Number of previous hospitalizations Lower 95% CI","Number of previous hospitalizations Upper 95% CI",
              "Family history HR","Family history Lower 95% CI","Family history Upper 95% CI","Smoking HR","Smoking Lower 95% CI","Smoking Upper 95% CI","Drug use HR",
              "Drug use Lower 95% CI","Drug use Upper 95% CI","CGI HR","CGI Lower 95% CI","CGI Upper 95% CI","Psychopathology total score HR",
              "Psychopathology total score Lower 95% CI","Psychopathology total score Upper 95% CI","Psychopathology general score HR","Psychopathology general score Lower 95% CI",
              "Psychopathology general score Upper 95% CI","Psychopathology positive score HR","Psychopathology positive score Lower 95% CI",
              "Psychopathology positive score Upper 95% CI","Psychopathology negative score HR","Psychopathology negative score Lower 95% CI",
              "Psychopathology negative score Upper 95% CI","General functioning score HR",  "General functioning score Lower 95% CI","General functioning score Upper 95% CI",
              "Quality of life score HR",  "Quality of life score Lower 95% CI","Quality of life score Upper 95% CI","Tardive dyskinesia score HR",
              "Tardive dyskinesia score Lower 95% CI","Tardive dyskinesia score Upper 95% CI","Akathisia score HR","Akathisia score Lower 95% CI",
              "Akathisia score Upper 95% CI","Parkinsonism score HR","Parkinsonism score Lower 95% CI","Parkinsonism score Upper 95% CI")




hr.res<- cbind(
  hr.sex.res,low.lim.sex.hr.res,up.lim.sex.hr.res,
  hr.age.res,low.lim.age.hr.res,up.lim.age.hr.res,
  hr.reg.res,low.lim.reg.hr.res,up.lim.reg.hr.res,
  hr.bmi.res,low.lim.bmi.hr.res,up.lim.bmi.hr.res,
  hr.dia.res,low.lim.dia.hr.res,up.lim.dia.hr.res,
  hr.doi.res,low.lim.doi.hr.res,up.lim.doi.hr.res,
  hr.las.res,low.lim.las.hr.res,up.lim.las.hr.res,
  hr.pre.res,low.lim.pre.hr.res,up.lim.pre.hr.res,
  hr.fam.res,low.lim.fam.hr.res,up.lim.fam.hr.res,
  hr.nic.res,low.lim.nic.hr.res,up.lim.nic.hr.res,
  NA,NA,NA,
  hr.cgi.res,low.lim.cgi.hr.res,up.lim.cgi.hr.res,
  hr.tot.res,low.lim.tot.hr.res,up.lim.tot.hr.res,
  hr.gen.res,low.lim.gen.hr.res,up.lim.gen.hr.res,
  hr.pos.res,low.lim.pos.hr.res,up.lim.pos.hr.res,
  hr.neg.res,low.lim.neg.hr.res,up.lim.neg.hr.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim.res,low.lim.aim.hr.res,up.lim.aim.hr.res,
  hr.bar.res,low.lim.bar.hr.res,up.lim.bar.hr.res,
  hr.eps.res,low.lim.eps.hr.res,up.lim.eps.hr.res)



hr.mat.res<-rbind(colname.HR,hr.res)

surv.obj.res <- Surv(time.to.event.res/7, status.res)
survfit(surv.obj.res~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)

xx.res<-study1.surv.fit.res
xx.t.res<-xx.res[[2]]
xx.p.res<-xx.res[[6]]
surv.mat.res<-cbind(xx.t.res,xx.p.res)


write.table(surv.mat.res,file="D:/Users/mse0jmr/Documents/CODE/LILLY-F1D-MC-HGKA-1/results/surv_res1.csv",sep=",")
write.table(desc.cont.mat.res,file="D:/Users/mse0jmr/Documents/CODE/LILLY-F1D-MC-HGKA-1/results/desc_cont_res1.csv",sep=",")

write.table(desc.cat.mat.res,file="D:/Users/mse0jmr/Documents/CODE/LILLY-F1D-MC-HGKA-1/results/desc_cat.res1.csv",sep=",")

write.table(outc.mat.res,file="D:/Users/mse0jmr/Documents/CODE/LILLY-F1D-MC-HGKA-1/results/outc.res1.csv",sep=",")

write.table(hr.mat.res,file="D:/Users/mse0jmr/Documents/CODE/LILLY-F1D-MC-HGKA-1/results/hr.res1.csv",sep=",")




