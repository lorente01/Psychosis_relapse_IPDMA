# Authored: Jose M Rubio M.D // jrubio13@northwell.edu
# April 7th 2020

##COHORT: Otsuka-246
#################################
### a function to match and merge variables from two datasets

match.and.merge.func <- function(dat1.id, dat2.id, dat2.var){
  dat1.var <- array(,length(dat1.id)) 
  for(i in 1:length(dat1.id)){
    for(j in 1:length(dat2.id)){
      if(dat1.id[i] == dat2.id[j]){ dat1.var[i] <- dat2.var[j] }}}
  return(dat1.var)                                       }

##########IDENTIFY TOTAL DATASET (I.E., THIS WILL BE IN FACT TREATED AS response.ids)
#ALL INDIVIDUALS RANDOMIZED TO LAI ON PHASE 4

recur.dat <- read.csv("X:/Data/Otsuka-Data_31-07-246/AnonymizedCSV/eff0.csv", header = TRUE, sep = ",")

total.ids<-recur.dat$PTCODE[recur.dat$TRT4P=="ARIP IMD"]

##########IDENTIFY 'REMISSION' DATASET
#no need since all pts entering phase 3 met remission criteria

########DEFINE STATUS PER DATASET (1=event; 0=censor)
recur.dat <- read.csv("X:/Data/Otsuka-Data_31-07-246/AnonymizedCSV/eff0.csv", header = TRUE, sep = ",")
relapse<-recur.dat$RELAPSE
recur<-as.numeric(recur.dat$PTCODE[relapse==1])

status<-array(0,length(total.ids))
for(i in 1:length(total.ids)){
  for (j in 1:length(recur)){
    if(total.ids[i]==recur[j]){status[i]<-1}}}

######DEFINE TIME TO EVENT PER DATASET 
time.to.all<-recur.dat$TTDISC

time.to.event<-match.and.merge.func(total.ids,recur.dat$PTCODE,time.to.all)

##CALCULATE PERSON YEARS AND ABSOLUTE AND PERSON X YEAR INCIDENCE RATE
#person-year
per.year<-sum(time.to.event)/365

#absolute incidence
abs.inc<-length(status[status==1])/length(status)*100 

#person-year incidence

py.inc<-length(status[status==1])/per.year*100

#SURVIVAL ANALYSIS

library(survival)
surv.obj <- Surv(time.to.event, status)

survfit(surv.obj~1)

study1.surv.fit <- survfit(surv.obj~1)

#############COVARIATES
demog.dat<-read.csv("X:/Data/Otsuka-Data_31-07-246/AnonymizedCSV/demog0.csv", header=TRUE,sep=",")
sex.1<-as.numeric(as.character(demog.dat$SEX))
sex.1[sex.1==2]<-0
sex  <- match.and.merge.func(total.ids, demog.dat$PTCODE, sex.1)

age.1<-as.character(demog.dat$AGE)
age.1[age.1=="20 or younger"]<-20
age.2<-as.numeric(age.1)

age  <- match.and.merge.func(total.ids, demog.dat$PTCODE, age.2)

reg<-as.character(demog.dat$REGION)
reg[reg=="NON-US"]<-0
reg[reg=="US"]<-1
reg.1<-as.numeric(reg)

region  <- match.and.merge.func(total.ids, demog.dat$PTCODE, reg.1)

vital.dat<-read.csv("X:/Data/Otsuka-Data_31-07-246/AnonymizedCSV/vital0.csv", header=TRUE,sep=",")
vital.bmi<-vital.dat[(vital.dat$TEST=="BMI") & (vital.dat$VISID=="PHASE 3 WEEK 1"),]
BMI.1<-as.numeric(as.character(vital.bmi$RESULT_A))

BMI<- match.and.merge.func(total.ids, vital.bmi$PTCODE, BMI.1)

panss.dat<-read.csv("X:/Data/Otsuka-Data_31-07-246/AnonymizedCSV/panss0.csv", header=TRUE,sep=",")
panss.dat<-panss.dat[panss.dat$AVISIT=="BASELINE PHASE 3",]

panss.dat.gen<-panss.dat[panss.dat$ITEM=="GEN_TOT",]
score.gen<-as.numeric(as.character(panss.dat.gen$SCORE))
panss.gen<-match.and.merge.func(total.ids, panss.dat.gen$PTCODE,score.gen)

panss.dat.neg<-panss.dat[panss.dat$ITEM=="NEG_TOT",]
score.neg<-as.numeric(as.character(panss.dat.neg$SCORE))
panss.neg<-match.and.merge.func(total.ids, panss.dat.neg$PTCODE,score.neg)

panss.dat.pos<-panss.dat[panss.dat$ITEM=="POS_TOT",]
score.pos<-as.numeric(as.character(panss.dat.pos$SCORE))
panss.pos<-match.and.merge.func(total.ids, panss.dat.pos$PTCODE,score.pos)

panss.dat.tot<-panss.dat[panss.dat$ITEM=="PAN_TOT",]
score.tot<-as.numeric(as.character(panss.dat.tot$SCORE))
panss.tot<-match.and.merge.func(total.ids, panss.dat.tot$PTCODE,score.tot)

psp.dat<-read.csv("X:/Data/Otsuka-Data_31-07-246/AnonymizedCSV/psp0.csv", header=TRUE,sep=",")
psp.dat<-psp.dat[(psp.dat$VISID=="WEEK 12/END OF PHASE 2") & (psp.dat$ITEM=="PSP_TOT"),]
score.psp<-as.numeric(as.character(psp.dat$SCORE))
functioning<-match.and.merge.func(total.ids, psp.dat$PTCODE,score.psp)

pshx.dat<-read.csv("X:/Data/Otsuka-Data_31-07-246/AnonymizedCSV/psychhx0.csv", header=TRUE,sep=",")
age.diag<-match.and.merge.func(total.ids, pshx.dat$PTCODE,pshx.dat$AGEFIRST)
doi<-age-age.diag

cgi.dat<-read.csv("X:/Data/Otsuka-Data_31-07-246/AnonymizedCSV/cgi0.csv", header=TRUE,sep=",")
cgi.dat<-cgi.dat[cgi.dat$AVISIT=="BASELINE PHASE 3",]
cgi<-match.and.merge.func(total.ids, cgi.dat$PTCODE,cgi.dat$SCORE)


##COX REGRESSION

coxph(formula = surv.obj ~sex )

coxph(formula = surv.obj ~age )

coxph(formula = surv.obj ~region)

coxph(formula = surv.obj ~BMI)

coxph(formula = surv.obj ~cgi )

coxph(formula = surv.obj ~age.diag )

coxph(formula = surv.obj ~doi)

coxph(formula = surv.obj ~panss.gen )

coxph(formula = surv.obj ~panss.neg) 

coxph(formula = surv.obj ~panss.pos)  

coxph(formula = surv.obj ~panss.tot)

coxph(formula = surv.obj ~functioning) 


######CALCULATE HR AND 95%CI

sex.hr<-coxph(formula = surv.obj ~sex )

se.sex.hr<-sqrt(sex.hr[[2]])
beta.sex.hr<-sex.hr[[1]]

up.lim.sex.hr<-exp(beta.sex.hr+(1.96*se.sex.hr))
low.lim.sex.hr<-exp(beta.sex.hr-(1.96*se.sex.hr))
hr.sex<-exp(beta.sex.hr)

age.hr<-coxph(formula = surv.obj ~age )

se.age.hr<-sqrt(age.hr[[2]])
beta.age.hr<-age.hr[[1]]

up.lim.age.hr<-exp(beta.age.hr+(1.96*se.age.hr))
low.lim.age.hr<-exp(beta.age.hr-(1.96*se.age.hr))
hr.age<-exp(beta.age.hr)

reg.hr<-coxph(formula = surv.obj ~region)

se.reg.hr<-sqrt(reg.hr[[2]])
beta.reg.hr<-reg.hr[[1]]

up.lim.reg.hr<-exp(beta.reg.hr+(1.96*se.reg.hr))
low.lim.reg.hr<-exp(beta.reg.hr-(1.96*se.reg.hr))
hr.reg<-exp(beta.reg.hr)

bmi.hr<-coxph(formula = surv.obj ~BMI)

se.bmi.hr<-sqrt(bmi.hr[[2]])
beta.bmi.hr<-bmi.hr[[1]]

up.lim.bmi.hr<-exp(beta.bmi.hr+(1.96*se.bmi.hr))
low.lim.bmi.hr<-exp(beta.bmi.hr-(1.96*se.bmi.hr))
hr.bmi<-exp(beta.bmi.hr)

cgi.hr<-coxph(formula = surv.obj ~cgi )

se.cgi.hr<-sqrt(cgi.hr[[2]])
beta.cgi.hr<-cgi.hr[[1]]

up.lim.cgi.hr<-exp(beta.cgi.hr+(1.96*se.cgi.hr))
low.lim.cgi.hr<-exp(beta.cgi.hr-(1.96*se.cgi.hr))
hr.cgi<-exp(beta.cgi.hr)

dia.hr<-coxph(formula = surv.obj ~age.diag )

se.dia.hr<-sqrt(dia.hr[[2]])
beta.dia.hr<-dia.hr[[1]]

up.lim.dia.hr<-exp(beta.dia.hr+(1.96*se.dia.hr))
low.lim.dia.hr<-exp(beta.dia.hr-(1.96*se.dia.hr))
hr.dia<-exp(beta.dia.hr)

doi.hr<-coxph(formula = surv.obj ~doi)

se.doi.hr<-sqrt(doi.hr[[2]])
beta.doi.hr<-doi.hr[[1]]

up.lim.doi.hr<-exp(beta.doi.hr+(1.96*se.doi.hr))
low.lim.doi.hr<-exp(beta.doi.hr-(1.96*se.doi.hr))
hr.doi<-exp(beta.doi.hr)

gen.hr<-coxph(formula = surv.obj ~panss.gen ) 

se.gen.hr<-sqrt(gen.hr[[2]])
beta.gen.hr<-gen.hr[[1]]

up.lim.gen.hr<-exp(beta.gen.hr+(1.96*se.gen.hr))
low.lim.gen.hr<-exp(beta.gen.hr-(1.96*se.gen.hr))
hr.gen<-exp(beta.gen.hr)

neg.hr<-coxph(formula = surv.obj ~panss.neg) 

se.neg.hr<-sqrt(neg.hr[[2]])
beta.neg.hr<-neg.hr[[1]]

up.lim.neg.hr<-exp(beta.neg.hr+(1.96*se.neg.hr))
low.lim.neg.hr<-exp(beta.neg.hr-(1.96*se.neg.hr))
hr.neg<-exp(beta.neg.hr)

pos.hr<-coxph(formula = surv.obj ~panss.pos) 

se.pos.hr<-sqrt(pos.hr[[2]])
beta.pos.hr<-pos.hr[[1]]

up.lim.pos.hr<-exp(beta.pos.hr+(1.96*se.pos.hr))
low.lim.pos.hr<-exp(beta.pos.hr-(1.96*se.pos.hr))
hr.pos<-exp(beta.pos.hr)

tot.hr<-coxph(formula = surv.obj ~panss.tot)

se.tot.hr<-sqrt(tot.hr[[2]])
beta.tot.hr<-tot.hr[[1]]

up.lim.tot.hr<-exp(beta.tot.hr+(1.96*se.tot.hr))
low.lim.tot.hr<-exp(beta.tot.hr-(1.96*se.tot.hr))
hr.tot<-exp(beta.tot.hr)	 

fun.hr<-coxph(formula = surv.obj ~functioning) 

se.fun.hr<-sqrt(fun.hr[[2]])
beta.fun.hr<-fun.hr[[1]]

up.lim.fun.hr<-exp(beta.fun.hr+(1.96*se.fun.hr))
low.lim.fun.hr<-exp(beta.fun.hr-(1.96*se.fun.hr))
hr.fun<-exp(beta.fun.hr)


#####SUMMARY TABLES

colname.desc.cont<- c("Age (mean)", "Age (SD)", "BMI (mean)", "BMI (SD)","Age at diagnosis (mean)","Age at diagnosis (SD)","Duration of illness (mean)","Duration of illness (SD)", "CGI (mean)","CGI (SD)","Psychopathology total score (mean)","Psychopathology total score (SD)", "Psychopathology general score (mean)","Psychopathology general score (SD)","Psychopathology positive score (mean)","Psychopathology positive score (SD)","Psychopathology negative score (mean)","Psychopathology negative score (SD)","General functioning score (mean)","General functioning score (SD)", "Quality of life score (mean)","Quality of life score (SD)")

mean.age<-mean(age, na.rm=T)
sd.age<-sd(age,na.rm=T)
mean.BMI<-mean(BMI,na.rm=T)
sd.BMI<-sd(BMI,na.rm=T)
mean.agediagnosis<-mean(age.diag, na.rm=T)
sd.agediagnsosis<-sd(age.diag,na.rm=T)
mean.doi<-mean(doi,na.rm=T)
sd.doi<-sd(doi,na.rm=T)
mean.cgi<-mean(cgi,na.rm=T)
sd.cgi<-sd(cgi,na.rm=T)
mean.totps<-mean(panss.tot,na.rm=T)
sd.totps<-sd(panss.tot, na.rm=T)
mean.genps<- mean(panss.gen, na.rm=T)
sd.genps<-sd(panss.gen, na.rm=T)
mean.posps<-mean(panss.pos, na.rm=T)
sd.posps<-sd(panss.pos, na.rm=T)
mean.negps<-mean(panss.neg, na.rm=T)
sd.negps<-sd(panss.neg, na.rm=T)
mean.func<-mean(functioning,na.rm=T)
sd.functioning<-sd(functioning, na.rm=T)
mean.qol<-NA
sd.qol<-NA

desc.cont<-c(mean.age,sd.age,mean.BMI,sd.BMI,mean.agediagnosis,sd.agediagnsosis,mean.doi,sd.doi,mean.cgi,sd.cgi,mean.totps,sd.totps,mean.genps,sd.genps,mean.posps,sd.posps,mean.negps,sd.negps,mean.func,sd.functioning,mean.qol,sd.qol)

desc.cont.mat<-rbind(colname.desc.cont,desc.cont)

colname.desc.cat<- c("Male (n)","Male (%)", "US (n)", "US (%)", "Family history (n)", "Family history (%)", "Smoking (n)", "Smoking (%)", "Drug use (n)", "Drug use (%)",">=3 prior hospitalizations(n)",">=3 prior hospitalizations (%)","Hospitalized in previous year (n)","Hospitalized in previous year (%)",">Moderate TD (n)",">Moderate TD (%)",">Moderate akathisia (n)",">Moderate akathisia (%)",">Moderate EPS (n)",">Moderate EPS (%)")

n.male<- length(sex[sex==1])
perc.male<-length(sex[sex==1])/length(sex)*100
n.us<- length(region[region==1])
perc.us<-length(region[region==1])/length(region)*100
n.fhx<- NA
perc.fhx<-NA
n.smok<- NA
perc.smok<-NA
n.drug<- NA
perc.drug<-NA
n.hosp.n<-NA
perc.hosp.n<-NA
n.hosp.t<-NA
perc.hosp.t<-NA
n.td<-NA
perc.td<-NA
n.aka<-NA
perc.aka<-NA
n.eps<-NA
perc.eps<-NA

desc.cat<-c(n.male,perc.male,n.us,perc.us,n.fhx,perc.fhx,n.smok,perc.smok,n.drug,perc.drug,n.hosp.n,perc.hosp.n,n.hosp.t,perc.hosp.t,n.td,perc.td,n.aka,perc.aka,n.eps,perc.eps)

desc.cat.mat<-rbind(colname.desc.cat,desc.cat)

colname.outc<-c("Total sample 'n'", "Relapse 'n'", "Relapse '%'", "Median time to relapse 'days'", "Events per 100 patient - years")

n.total<-length(total.ids)
n.relapse<-length(status[status==1])
perc.relapse<-length(status[status==1])/length(status)*100
median.time<-median(time.to.event, na.rm=T)
py.inc

outc<-c(n.total,n.relapse,perc.relapse,median.time,py.inc)

outc.mat<-rbind(colname.outc,outc)


colname.HR<-c("Male gender HR","Male gender Lower 95% CI","Male gender Upper 95% CI","Age HR", "Age Lower 95% CI","Age	Upper 95% CI","Proportion US HR",
              "Proportion US Lower 95% CI","Proportion US Upper 95% CI","BMI HR",  "BMI Lower 95% CI","BMI Upper 95% CI", "Age at diagnosis HR",
              "Age at diagnosis Lower 95% CI","Age at diagnosis Upper 95% CI","Duration of illness HR","Duration of illness Lower 95% CI","Duration of illness Upper 95% CI",
              "Time since last hospitalization HR","Time since last hospitalization Lower 95% CI","Time since last hospitalization Upper 95% CI",
              "Number of previous hospitalizations HR","Number of previous hospitalizations Lower 95% CI","Number of previous hospitalizations Upper 95% CI",
              "Family history HR","Family history Lower 95% CI","Family history Upper 95% CI","Smoking HR","Smoking Lower 95% CI","Smoking Upper 95% CI",
              "Drug use HR","Drug use Lower 95% CI","Drug use Upper 95% CI","CGI HR","CGI Lower 95% CI","CGI Upper 95% CI","Psychopathology total score HR",
              "Psychopathology total score Lower 95% CI","Psychopathology total score Upper 95% CI","Psychopathology general score HR",
              "Psychopathology general score Lower 95% CI","Psychopathology general score Upper 95% CI","Psychopathology positive score HR",
              "Psychopathology positive score Lower 95% CI","Psychopathology positive score Upper 95% CI","Psychopathology negative score HR",
              "Psychopathology negative score Lower 95% CI","Psychopathology negative score Upper 95% CI","General functioning score HR", 
              "General functioning score Lower 95% CI","General functioning score Upper 95% CI", "Quality of life score HR",  "Quality of life score Lower 95% CI","Quality of life score Upper 95% CI","Tardive dyskinesia score HR","Tardive dyskinesia score Lower 95% CI","Tardive dyskinesia score Upper 95% CI","Akathisia score HR","Akathisia score Lower 95% CI","Akathisia score Upper 95% CI","Parkinsonism score HR","Parkinsonism score Lower 95% CI","Parkinsonism score Upper 95% CI")

hr<- cbind(
  hr.sex,low.lim.sex.hr,up.lim.sex.hr,
  hr.age,low.lim.age.hr,up.lim.age.hr,
  hr.reg,low.lim.reg.hr,up.lim.reg.hr,
  hr.bmi,low.lim.bmi.hr,up.lim.bmi.hr,
  hr.dia,low.lim.dia.hr,up.lim.dia.hr,
  hr.doi,low.lim.doi.hr,up.lim.doi.hr,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  hr.cgi,low.lim.cgi.hr,up.lim.cgi.hr,
  hr.tot,low.lim.tot.hr,up.lim.tot.hr,
  hr.gen,low.lim.gen.hr,up.lim.gen.hr,
  hr.pos,low.lim.pos.hr,up.lim.pos.hr,
  hr.neg,low.lim.neg.hr,up.lim.neg.hr,
  hr.fun,low.lim.fun.hr,up.lim.fun.hr,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA)

hr.mat<-rbind(colname.HR,hr)

surv.obj <- Surv(time.to.event/7, status)

survfit(surv.obj~1)

study1.surv.fit <- survfit(surv.obj~1)

xx<-study1.surv.fit

xx.t<-xx[[2]]
xx.p<-xx[[6]]

surv.mat<-cbind(xx.t,xx.p)

write.table(surv.mat,file="X:/Workspace/Results/surv_246.csv",sep=",")

write.table(desc.cont.mat,file="X:/Workspace/Results/desc_cont_246.csv",sep=",")

write.table(desc.cat.mat,file="X:/Workspace/Results/desc_cat_246.csv",sep=",")

write.table(outc.mat,file="X:/Workspace/Results/outc_246.csv",sep=",")

write.table(hr.mat,file="X:/Workspace/Results/hr_246.csv",sep=",")










