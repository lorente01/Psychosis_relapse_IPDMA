# Authored: Jose M Rubio M.D // jrubio13@northwell.edu
# Checked: George Schoretsanitis M.D.,PhD
# April 9th 2020

##COHORT: ACLAIMS-H
library(dplyr)
library(readr)

#################################

### a function to match and merge variables from two datasets

match.and.merge.func<-function(dat1.id, dat2.id, dat2.var){
  dat1.var<- array(,length(dat1.id))
  for(i in 1: length(dat1.id)){
    for(j in 1:length(dat2.id)){
      if(dat1.id[i]==dat2.id[j]){dat1.var[i]<-dat2.var[j]}}}
  return(dat1.var)}

##########IDENTIFY TOTAL DATASET
#ALLOCATED TO HALDOL DEC 
#FOLLOWED FOR SUFFICIENT TIME TO HAVE A THERAPEUTIC ANTIPSYCHOTIC PLASMA LEVEL (1WK)

arm.dat<-read_csv("/Users/joserubio/ACLAIMS_data/partdev.csv")
arm.hal.prov<-arm.dat$subjectkey[arm.dat$TRT01P=="Haloperidol decanoate"]


cont.dat1<-read_csv("/Users/joserubio/ACLAIMS_data/smf.csv")
cont.dat<-cont.dat1[cont.dat1$SMFA1==1,]
cont.dat.clean <- cont.dat[!is.na(cont.dat$subjectkey),]

id.char.a<-as.character(cont.dat.clean$subjectkey)
id.char.u<-unique(id.char.a)
day.tt<- cont.dat.clean$SMFA0B

w8<-array(0,length(id.char.u))
last.inj<-array(0,length(id.char.u))
for(i in 1:length(id.char.u)){
  temp.array<-day.tt[id.char.a==id.char.u[i]]
  max.dy<-max(temp.array,na.rm=T)
  if(max.dy>7){w8[i]<-1}
  last.inj[i]<-max.dy
}

ids.w8.char<-id.char.u[w8==1]

total.ids<-intersect(arm.hal.prov,ids.w8.char)
##########IDENTIFY 'RESPONSE' DATASET (THESE ARE IN FACT REMITTERS, IN THIS TRIAL, GIVEN SPARCITY OF DATA, WE ARE ONLY ABLE TO USE "MILD OR LESS" AT PANSS POSITIVE AT THE END OF THE STABILIZATION PERIOD [V10])

panss.dat<-read.delim("/Users/joserubio/ACLAIMS_data/panss01.txt", header=TRUE, sep="\t")
panss.dat<-panss.dat[-1,] 
panss.vis.num<-as.numeric(as.character(panss.dat$visit))
panss.dat<-panss.dat[panss.vis.num==10,]
panss.id<-as.character(panss.dat$subjectkey)
panss.id.u<-as.character(unique(panss.dat$subjectkey))


p1<-as.numeric(as.character(panss.dat$pos_p1))
p2<-as.numeric(as.character(panss.dat$pos_p2))
p3<-as.numeric(as.character(panss.dat$pos_p3))
p4<-as.numeric(as.character(panss.dat$pos_p4))
p5<-as.numeric(as.character(panss.dat$pos_p5))
p6<-as.numeric(as.character(panss.dat$pos_p6))
p7<-as.numeric(as.character(panss.dat$pos_p7))


panss.res.id<-array(0,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  pos.array<-c(p1[panss.id==panss.id.u[i]],p2[panss.id==panss.id.u[i]],p3[panss.id==panss.id.u[i]],p4[panss.id==panss.id.u[i]],p5[panss.id==panss.id.u[i]],p6[panss.id==panss.id.u[i]],p7[panss.id==panss.id.u[i]])
  max.pos<-max(pos.array, na.rm=T)
  if(max.pos<4){panss.res.id[i]<-1}}

response.ids.pr<-panss.id.u[panss.res.id==1]
response.ids<-intersect(total.ids,response.ids.pr)
no.response.ids<-setdiff(total.ids,response.ids)

########DEFINE STATUS PER DATASET (1=event; 0=censor)

adj.dat.t<-read.delim("/Users/joserubio/ACLAIMS_data/adj01.txt", header=TRUE, sep="\t")
adj.dat<-adj.dat.t[-1,]
stat.num<-as.numeric(as.character(adj.dat$adja2a))
adj.id<-as.character(adj.dat$subjectkey)
adj.id.u<-unique(adj.id)

status.t<-array(0,length(adj.id.u))
for(i in 1:length(adj.id.u)){
  temp.array<-stat.num[adj.id==adj.id.u[i]]
  stat<-min(temp.array,na.rm=T)
  if(stat==1){status.t[i]<-1}}

status<-match.and.merge.func(total.ids,adj.id.u,status.t)
status.res<-match.and.merge.func(response.ids,adj.id.u,status.t)
status.no.res<-match.and.merge.func(no.response.ids,adj.id.u,status.t)

######DEFINE TIME TO EVENT PER DATASET

adj.dat.t<-read.delim("/Users/joserubio/ACLAIMS_data/adj01.txt", header=TRUE, sep="\t")

adj.dat<-adj.dat.t[-1,]

day.adj<- as.numeric(as.character(adj.dat$adja3))

#individuals without the event are NAs that we first assign 0

time.to<-array(,length(adj.id.u))
for(i in 1:length(adj.id.u)){
  temp.array<-day.adj[adj.id==adj.id.u[i]]
  temp.array[is.na(temp.array)]<-0
  max.dy<-max(temp.array)
  time.to[i]<-max.dy
}

#now change those 0s to the last injection day

cont.dat<-read_csv("/Users/joserubio/ACLAIMS_data/smf.csv")
cont.dat<-cont.dat[cont.dat$SMFA1==1,]
cont.dat.clean <- cont.dat[!is.na(cont.dat$subjectkey),]

id.char.a<-as.character(cont.dat.clean$subjectkey)
id.char.u<-unique(id.char.a)
day.tt<- cont.dat.clean$SMFA0B

last.inj.char<-array(,length(id.char.u))
for(i in 1:length(id.char.u)){
  temp.array<-day.tt[id.char.a==id.char.u[i]]
  max.dy<-max(temp.array,na.rm=T)
  last.inj.char[i]<-max.dy
}

for(i in 1:length(time.to)){
  if(time.to[adj.id.u==adj.id.u[i]]==0){time.to[i]<-last.inj.char[id.char.u==adj.id.u[i]]}}

time.to.event<-match.and.merge.func(total.ids,adj.id.u,time.to) 
time.to.event.res<-match.and.merge.func(response.ids,adj.id.u,time.to) 
time.to.event.no.res<-match.and.merge.func(no.response.ids,adj.id.u,time.to) 

rem.stat<-array(0,length(total.ids))
for(i in 1: length(total.ids)){
  for(j in 1: length(response.ids)){
    if(total.ids[i]==response.ids[j]){
      rem.stat[i]<-1
    }
  }
}

#SURVIVAL ANALYSIS

library(survival)
surv.obj <- Surv(time.to.event, status)
surv.obj.res <- Surv(time.to.event.res, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res, status.no.res)

survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)

study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)

##CALCULATE PERSON YEARS AND ABSOLUTE AND PERSON X YEAR INCIDENCE RATE

#person-year
per.year<-sum(time.to.event)/365
per.year.res<-sum(time.to.event.res)/365
per.year.no.res<-sum(time.to.event.no.res)/365

#absolute incidence
abs.inc<-length(status[status==1])/length(status)*100 
abs.inc.res<-length(status.res[status.res==1])/length(status.res)*100
abs.inc.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100

#person-year incidence
py.inc<-length(status[status==1])/per.year*100
py.inc.res<-length(status.res[status.res==1])/per.year.res*100
py.inc.no.res<-length(status.no.res[status.no.res==1])/per.year.no.res*100

#############COVARIATES

##AGE
dem.dat<-read.delim("/Users/joserubio/ACLAIMS_data/demof01.txt", header=TRUE, sep = "\t")

dem.dat<-dem.dat[-1,]
dem.seq<-as.numeric(as.character(dem.dat$fseqno))
dem.dat<-dem.dat[dem.seq==1,]
dem.id<-as.character(dem.dat$subjectkey)
dem.id.u<-as.character(unique(dem.dat$subjectkey))

age.1<-as.numeric(as.character(dem.dat$interview_age))/12

age<-match.and.merge.func(total.ids,dem.id.u,age.1) 
age.res<-match.and.merge.func(response.ids,dem.id.u,age.1) #
age.no.res<-match.and.merge.func(no.response.ids,dem.id.u,age.1) 

##SEX
dem.dat<-read.delim("/Users/joserubio/ACLAIMS_data/demof01.txt", header=TRUE, sep = "\t")

dem.dat<-dem.dat[-1,]
dem.seq<-as.numeric(as.character(dem.dat$fseqno))
dem.dat<-dem.dat[dem.seq==1,]
dem.id<-as.character(dem.dat$subjectkey)
dem.id.u<-as.character(unique(dem.dat$subjectkey))

sex.1<-as.character(dem.dat$gender)

sex<-match.and.merge.func(total.ids,dem.id.u,sex.1) 
sex.res<-match.and.merge.func(response.ids,dem.id.u,sex.1) 
sex.no.res<-match.and.merge.func(no.response.ids,dem.id.u,sex.1) 

#REGION
region<-array(1,length(total.ids))
region.res<-array(1,length(response.ids))
region.no.res<-array(1,length(no.response.ids))

#BMI
vitals.dat<-read.delim("/Users/joserubio/ACLAIMS_data/vitals01.txt", header=TRUE, sep="\t")
vitals.bl<-vitals.dat[vitals.dat$visitid=="1",]
ids.vs.u<-unique(vitals.bl$subjectkey)
bmi<-as.numeric(as.character(vitals.bl$bmi))


BMI <- match.and.merge.func(total.ids, ids.vs.u, bmi)
BMI.res <- match.and.merge.func(response.ids, ids.vs.u, bmi)
BMI.no.res <- match.and.merge.func(no.response.ids, ids.vs.u, bmi)


#AIMS
aims.dat<-read.delim("/Users/joserubio/ACLAIMS_data/aims01.txt", header=TRUE, sep="\t")
aims.dat<-aims.dat[-1,]
aims.vis.num<-as.numeric(as.character(aims.dat$visitid))
aims.dat<-aims.dat[aims.vis.num==2,]
fseqno<-as.character(aims.dat$fseqno)
aims.dat<-aims.dat[fseqno=="1",] 
aims.id<-as.character(aims.dat$subjectkey)
aims.id.u<-as.character(unique(aims.dat$subjectkey))

aims.1<-as.numeric(as.character(aims.dat$aims_global8_date1))

aims.score<-array(,length(aims.id.u))
for(i in 1:length(aims.id.u)){
  aims.score[i]<-aims.1[aims.id==aims.id.u[i]]}
aims.score[aims.score<=1]<-0
aims.score[aims.score>1]<-1


aims <- match.and.merge.func(total.ids,aims.id.u, aims.score) 
aims.res <- match.and.merge.func(response.ids,aims.id.u, aims.score)
aims.no.res <- match.and.merge.func(no.response.ids,aims.id.u, aims.score)


##BARNES
akath.dat.p<-read.delim("/Users/joserubio/ACLAIMS_data/bns01.txt", header=TRUE, sep="\t")
akath.dat<-akath.dat.p[-1,]
akath.vis.num<-as.numeric(as.character(akath.dat$visitid))
akath.dat<-akath.dat[akath.vis.num==2,]
akath.seq<-as.numeric(as.character(akath.dat$fseqno))
akath.dat<-akath.dat[akath.seq==1,]
akath.id<-as.character(akath.dat$subjectkey)
akath.id.u<-unique(akath.id)

akg<-as.numeric(as.character(akath.dat$bnsa4))

barnes.score<-array(,length(akath.id.u))
for(i in 1:length(akath.id.u)){
  barnes.score[i]<-akg[akath.id==akath.id.u[i]]
}
barnes.score[barnes.score<=1]<-0
barnes.score[barnes.score>1]<-1

bars<-match.and.merge.func(total.ids,akath.id.u,barnes.score) #ok
bars.res<-match.and.merge.func(response.ids,akath.id.u,barnes.score) 
bars.no.res<-match.and.merge.func(no.response.ids,akath.id.u,barnes.score)

##CGI

cgi.dat<-read.delim("/Users/joserubio/ACLAIMS_data/cgi01.txt", header=TRUE, sep="\t")

cgi.dat<-cgi.dat[-1,]
cgi.vis.num<-as.numeric(as.character(cgi.dat$visit))
cgi.dat<-cgi.dat[cgi.vis.num==2,]
cgi.seq<-as.numeric(as.character(cgi.dat$fseqno))
cgi.dat<-cgi.dat[cgi.seq==1,]
cgi.id<-as.character(cgi.dat$subjectkey)
cgi.id.u<-as.character(unique(cgi.dat$subjectkey))

cgi<-as.numeric(as.character(cgi.dat$cgi_si))

cgi.score<-array(,length(cgi.id.u))
for(i in 1:length(cgi.id.u)){
  cgi.score[i]<-cgi[cgi.id==cgi.id.u[i]]
}

cgi<-match.and.merge.func(total.ids,cgi.id.u,cgi.score) #ok
cgi.res<-match.and.merge.func(response.ids,cgi.id.u,cgi.score) #ok
cgi.no.res<-match.and.merge.func(no.response.ids,cgi.id.u,cgi.score) 

#AGE AT DIAGNOSIS
scid.dat<-read.delim("/Users/joserubio/ACLAIMS_data/scid_ph01.txt", header=TRUE, sep="\t")
scid.dat<-scid.dat[-1,]
scid.id<-as.character(scid.dat$subjectkey)
scid.id.u<-unique(scid.id)

age.diag.1<-as.numeric(as.character(scid.dat$scda15))

age.diag<-match.and.merge.func(total.ids,scid.id.u,age.diag.1) 
age.diag.res<-match.and.merge.func(response.ids,scid.id.u,age.diag.1)
age.diag.no.res<-match.and.merge.func(no.response.ids,scid.id.u,age.diag.1)

##DOI

age.iv<-as.numeric(as.character(scid.dat$interview_age))/12

age.int<-match.and.merge.func(total.ids,scid.id.u,age.iv) 
age.int.res<-match.and.merge.func(response.ids,scid.id.u,age.iv) 
age.int.no.res<-match.and.merge.func(no.response.ids,scid.id.u,age.iv) 

#there are negative values which we assume are errors, we are changing to NAs

doi<-age.int-age.diag
doi[doi<0]<-NA
doi.res<-age.int.res-age.diag.res
doi.no.res<-age.int.no.res-age.diag.no.res

##NUMBER PREVIOUS HOSPITALIZATIONS
num.hosp<-as.numeric(as.character(scid.dat$scda17))

num.hosp[num.hosp<=2]<-0
num.hosp[num.hosp>2]<-1

num.prev.hosp<-match.and.merge.func(total.ids,scid.id.u,num.hosp) 
num.prev.hosp.res<-match.and.merge.func(response.ids,scid.id.u,num.hosp)
num.prev.hosp.no.res<-match.and.merge.func(no.response.ids,scid.id.u,num.hosp)  

##DRUG USE AND NICOTINE USE

drugs.dat<-read.delim("/Users/joserubio/ACLAIMS_data/subuq01.txt", header=TRUE, sep="\t")
drugs.dat<-drugs.dat[-1,]
drugs.vis.num<-as.numeric(as.character(drugs.dat$visitid))
drugs.dat<-drugs.dat[drugs.vis.num==2,]
drugs.seq<-as.numeric(as.character(drugs.dat$fseqno))
drugs.dat<-drugs.dat[drugs.seq==1,]

drugs.id<-as.character(drugs.dat$subjectkey)
drugs.id.u<-as.character(unique(drugs.dat$subjectkey))

drug.use<-as.numeric(as.character(drugs.dat$dusa9))
drug.use[drug.use==1]<-0
drug.use[drug.use>1]<-1

drugs<-match.and.merge.func(total.ids,drugs.id.u,drug.use) 
drugs.res<-match.and.merge.func(response.ids,drugs.id.u,drug.use)
drugs.no.res<-match.and.merge.func(no.response.ids,drugs.id.u,drug.use) 

#NICOTINE

nicotine.use<-as.numeric(as.character(drugs.dat$dusa1))
nicotine.use[nicotine.use==1]<-0
nicotine.use[nicotine.use==2]<-1

nicotine<-match.and.merge.func(total.ids,drugs.id.u,nicotine.use) 
nicotine.res<-match.and.merge.func(response.ids,drugs.id.u,nicotine.use) 
nicotine.no.res<-match.and.merge.func(no.response.ids,drugs.id.u,nicotine.use) 

##PANSS
panss.dat<-read.delim("/Users/joserubio/ACLAIMS_data/panss01.txt", header=TRUE, sep="\t")
panss.dat<-panss.dat[-1,]
panss.vis.num<-as.numeric(as.character(panss.dat$visit))
panss.dat<-panss.dat[panss.vis.num==2,]
panss.id<-as.character(panss.dat$subjectkey)
panss.id.u<-as.character(unique(panss.dat$subjectkey))


p1<-as.numeric(as.character(panss.dat$pos_p1))
p2<-as.numeric(as.character(panss.dat$pos_p2))
p3<-as.numeric(as.character(panss.dat$pos_p3))
p4<-as.numeric(as.character(panss.dat$pos_p4))
p5<-as.numeric(as.character(panss.dat$pos_p5))
p6<-as.numeric(as.character(panss.dat$pos_p6))
p7<-as.numeric(as.character(panss.dat$pos_p7))
n1<-as.numeric(as.character(panss.dat$neg_n1))
n2<-as.numeric(as.character(panss.dat$neg_n2))
n3<-as.numeric(as.character(panss.dat$neg_n3))
n4<-as.numeric(as.character(panss.dat$neg_n4))
n5<-as.numeric(as.character(panss.dat$neg_n5))
n6<-as.numeric(as.character(panss.dat$neg_n6))
n7<-as.numeric(as.character(panss.dat$neg_n7))
g1<-as.numeric(as.character(panss.dat$gps_g1))
g2<-as.numeric(as.character(panss.dat$gps_g2))
g3<-as.numeric(as.character(panss.dat$gps_g3))
g4<-as.numeric(as.character(panss.dat$gps_g4))
g5<-as.numeric(as.character(panss.dat$gps_g5))
g6<-as.numeric(as.character(panss.dat$gps_g6))
g7<-as.numeric(as.character(panss.dat$gps_g7))
g8<-as.numeric(as.character(panss.dat$gps_g8))
g9<-as.numeric(as.character(panss.dat$gps_g9))
g10<-as.numeric(as.character(panss.dat$gps_g10))
g11<-as.numeric(as.character(panss.dat$gps_g11))
g12<-as.numeric(as.character(panss.dat$gps_g12))
g13<-as.numeric(as.character(panss.dat$gps_g13))
g14<-as.numeric(as.character(panss.dat$gps_g14))
g15<-as.numeric(as.character(panss.dat$gps_g15))
g16<-as.numeric(as.character(panss.dat$gps_g16))

panss.pos.score<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  pos.array<-c(p1[panss.id==panss.id.u[i]],p2[panss.id==panss.id.u[i]],p3[panss.id==panss.id.u[i]],p4[panss.id==panss.id.u[i]],p5[panss.id==panss.id.u[i]],p6[panss.id==panss.id.u[i]],p7[panss.id==panss.id.u[i]])
  panss.pos.score[i]<-sum(pos.array)
}


panss.neg.score<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  neg.array<-c(n1[panss.id==panss.id.u[i]],n2[panss.id==panss.id.u[i]],n3[panss.id==panss.id.u[i]],n4[panss.id==panss.id.u[i]],n5[panss.id==panss.id.u[i]],n6[panss.id==panss.id.u[i]],n7[panss.id==panss.id.u[i]])
  panss.neg.score[i]<-sum(neg.array)
}

panss.gen.score<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  gen.array<-c(g1[panss.id==panss.id.u[i]],g2[panss.id==panss.id.u[i]],g3[panss.id==panss.id.u[i]],g4[panss.id==panss.id.u[i]],g5[panss.id==panss.id.u[i]],g6[panss.id==panss.id.u[i]],g7[panss.id==panss.id.u[i]],g8[panss.id==panss.id.u[i]],g9[panss.id==panss.id.u[i]],g10[panss.id==panss.id.u[i]],g11[panss.id==panss.id.u[i]],g12[panss.id==panss.id.u[i]],g13[panss.id==panss.id.u[i]],g14[panss.id==panss.id.u[i]],g15[panss.id==panss.id.u[i]],g16[panss.id==panss.id.u[i]])
  panss.gen.score[i]<-sum(gen.array)
}

panss.tot.score<-panss.pos.score+panss.neg.score+panss.gen.score

panss.tot<-match.and.merge.func(total.ids,panss.id.u,panss.tot.score) 
panss.tot.res<-match.and.merge.func(response.ids,panss.id.u,panss.tot.score) 
panss.tot.no.res<-match.and.merge.func(no.response.ids,panss.id.u,panss.tot.score) 

panss.pos<-match.and.merge.func(total.ids,panss.id.u,panss.pos.score) 
panss.pos.res<-match.and.merge.func(response.ids,panss.id.u,panss.pos.score) 
panss.pos.no.res<-match.and.merge.func(no.response.ids,panss.id.u,panss.pos.score) 

panss.neg<-match.and.merge.func(total.ids,panss.id.u,panss.neg.score) 
panss.neg.res<-match.and.merge.func(response.ids,panss.id.u,panss.neg.score) 
panss.neg.no.res<-match.and.merge.func(no.response.ids,panss.id.u,panss.neg.score) 

panss.gen<-match.and.merge.func(total.ids,panss.id.u,panss.gen.score) 
panss.gen.res<-match.and.merge.func(response.ids,panss.id.u,panss.gen.score) #ok
panss.gen.no.res<-match.and.merge.func(no.response.ids,panss.id.u,panss.gen.score)


#EPS

sas.dat<-read.delim("/Users/joserubio/ACLAIMS_data/sas01.txt", header=TRUE, sep="\t")
sas.dat<-sas.dat[-1,]
sas.vis.num<-as.numeric(as.character(sas.dat$visitid))
sas.dat<-sas.dat[sas.vis.num==2,]
sas.seq<-as.numeric(as.character(sas.dat$fseqno))
sas.dat<-sas.dat[sas.seq==1,]

sas.id<-as.character(sas.dat$subjectkey)
sas.id.u<-as.character(unique(sas.dat$subjectkey))

s1<-as.numeric(as.character(sas.dat$sas01))
s2<-as.numeric(as.character(sas.dat$sas02))
s3<-as.numeric(as.character(sas.dat$sas03))
s4<-as.numeric(as.character(sas.dat$sas04))
s5<-as.numeric(as.character(sas.dat$sas05))
s6<-as.numeric(as.character(sas.dat$sas06))
s7<-as.numeric(as.character(sas.dat$sas07))
s8<-as.numeric(as.character(sas.dat$sas08))
s9<-as.numeric(as.character(sas.dat$sas09))
s10<-as.numeric(as.character(sas.dat$sas10))

sas.score<-array(,length(sas.id.u))
for(i in 1:length(sas.id.u)){
  temp.array<-c(s1[sas.id==sas.id.u[i]],s2[sas.id==sas.id.u[i]],s3[sas.id==sas.id.u[i]],s4[sas.id==sas.id.u[i]],s5[sas.id==sas.id.u[i]],s9[sas.id==sas.id.u[i]])
  sas.score[i]<-sum(temp.array, na.rm=T)/10
}
sas.score[sas.score<=0.3]<-0
sas.score[sas.score>0.3]<-1

eps<-match.and.merge.func(total.ids,sas.id.u,sas.score) 
eps.res<-match.and.merge.func(response.ids,sas.id.u,sas.score) 
eps.no.res<-match.and.merge.func(no.response.ids,sas.id.u,sas.score) 

coxph(formula = surv.obj ~sex)
coxph(formula = surv.obj.res ~ sex.res)
coxph(formula = surv.obj.no.res ~sex.no.res)
coxph(formula = surv.obj ~age )
coxph(formula = surv.obj.res ~age.res )
coxph(formula = surv.obj.no.res ~age.no.res )
coxph(formula = surv.obj ~region)
coxph(formula = surv.obj.res ~region.res)
coxph(formula = surv.obj.no.res ~region.no.res)
coxph(formula = surv.obj ~BMI)
coxph(formula = surv.obj.res ~BMI.res)
coxph(formula = surv.obj.no.res ~BMI.no.res)
coxph(formula = surv.obj ~aims )
coxph(formula = surv.obj.res ~aims.res )
coxph(formula = surv.obj.no.res ~aims.no.res )
coxph(formula = surv.obj ~bars)
coxph(formula = surv.obj.res ~bars.res )
coxph(formula = surv.obj.no.res ~bars.no.res )
coxph(formula = surv.obj ~cgi )
coxph(formula = surv.obj.res ~cgi.res )
coxph(formula = surv.obj.no.res ~cgi.no.res )
coxph(formula = surv.obj ~age.diag )
coxph(formula = surv.obj.res ~age.diag.res )
coxph(formula = surv.obj.no.res ~age.diag.no.res )
coxph(formula = surv.obj ~doi)
coxph(formula = surv.obj.res ~doi.res)
coxph(formula = surv.obj.no.res ~doi.no.res)
coxph(formula = surv.obj ~drugs )
coxph(formula = surv.obj.res ~drugs.res )
coxph(formula = surv.obj.no.res ~drugs.no.res )
coxph(formula = surv.obj ~nicotine )
coxph(formula = surv.obj.res ~nicotine.res )
coxph(formula = surv.obj.no.res ~nicotine.no.res )
coxph(formula = surv.obj ~panss.gen )
coxph(formula = surv.obj.res ~panss.gen.res) 
coxph(formula = surv.obj.no.res ~panss.gen.no.res) 
coxph(formula = surv.obj ~panss.neg) 
coxph(formula = surv.obj.res ~panss.neg.res) 
coxph(formula = surv.obj.no.res ~panss.neg.no.res)
coxph(formula = surv.obj ~panss.pos) 
coxph(formula = surv.obj.res ~panss.pos.res) 
coxph(formula = surv.obj.no.res ~panss.pos.no.res) 
coxph(formula = surv.obj ~panss.tot)
coxph(formula = surv.obj.res ~panss.tot.res)
coxph(formula = surv.obj.no.res ~panss.tot.no.res)
coxph(formula = surv.obj ~num.prev.hosp) 
coxph(formula = surv.obj.res ~num.prev.hosp.res) 
coxph(formula = surv.obj.no.res ~num.prev.hosp.no.res) 
coxph(formula = surv.obj ~eps) 
coxph(formula = surv.obj.res ~eps.res) 
coxph(formula = surv.obj.no.res ~eps.no.res) 


ci.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex ))[8])[c(3,9,12)]
ci.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age ))[8])[c(3,9,12)]
ci.int.region<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region ))[8])[c(3,9,12)]
ci.int.BMI<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[8])[c(3,9,12)]
ci.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims ))[8])[c(3,9,12)]
ci.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars ))[8])[c(3,9,12)]
ci.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi ))[8])[c(3,9,12)]
ci.int.agediag<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age.diag))[8])[c(3,9,12)]
ci.int.doi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*doi ))[8])[c(3,9,12)]
ci.int.drugs<-unlist(summary(coxph(formula = surv.obj ~rem.stat*drugs ))[8])[c(3,9,12)]
ci.int.nicotine<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine ))[8])[c(3,9,12)]
ci.int.panss.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen ))[8])[c(3,9,12)]
ci.int.panss.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg))[8])[c(3,9,12)]
ci.int.panss.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos ))[8])[c(3,9,12)]
ci.int.panss.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot ))[8])[c(3,9,12)]
ci.int.num.prev.hosp<-unlist(summary(coxph(formula = surv.obj ~rem.stat*num.prev.hosp ))[8])[c(3,9,12)]
ci.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps ))[8])[c(3,9,12)]

#LogHR and LogSE for interaction terms
sei.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex ))[7])[c(3,9)]
sei.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age ))[7])[c(3,9)]
sei.int.region<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region ))[7])[c(3,9)]
sei.int.BMI<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[7])[c(3,9)]
sei.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims ))[7])[c(3,9)]
sei.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars ))[7])[c(3,9)]
sei.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi ))[7])[c(3,9)]
sei.int.agediag<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age.diag))[7])[c(3,9)]
sei.int.doi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*doi ))[7])[c(3,9)]
sei.int.drugs<-unlist(summary(coxph(formula = surv.obj ~rem.stat*drugs ))[7])[c(3,9)]
sei.int.nicotine<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine ))[7])[c(3,9)]
sei.int.panss.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen ))[7])[c(3,9)]
sei.int.panss.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg))[7])[c(3,9)]
sei.int.panss.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos ))[7])[c(3,9)]
sei.int.panss.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot ))[7])[c(3,9)]
sei.int.num.prev.hosp<-unlist(summary(coxph(formula = surv.obj ~rem.stat*num.prev.hosp ))[7])[c(3,9)]
sei.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps ))[7])[c(3,9)]

#LogHR and LogSE for Cox for no.remission.ids
sei.sex<-unlist(summary(coxph(formula = surv.obj.no.res ~sex.no.res ))[7])[c(1,3)]
sei.age<-unlist(summary(coxph(formula = surv.obj.no.res ~age.no.res  ))[7])[c(1,3)]
sei.region<-unlist(summary(coxph(formula = surv.obj.no.res ~region.no.res  ))[7])[c(1,3)]
sei.BMI<-unlist(summary(coxph(formula = surv.obj.no.res ~BMI.no.res ))[7])[c(1,3)]
sei.aims<-unlist(summary(coxph(formula = surv.obj.no.res ~aims.no.res  ))[7])[c(1,3)]
sei.bars<-unlist(summary(coxph(formula = surv.obj.no.res ~bars.no.res  ))[7])[c(1,3)]
sei.cgi<-unlist(summary(coxph(formula = surv.obj.no.res ~cgi.no.res  ))[7])[c(1,3)]
sei.agediag<-unlist(summary(coxph(formula = surv.obj.no.res ~age.diag.no.res ))[7])[c(1,3)]
sei.doi<-unlist(summary(coxph(formula = surv.obj.no.res ~doi.no.res  ))[7])[c(1,3)]
sei.drugs<-unlist(summary(coxph(formula = surv.obj.no.res ~drugs.no.res  ))[7])[c(1,3)]
sei.nicotine<-unlist(summary(coxph(formula = surv.obj.no.res ~nicotine.no.res  ))[7])[c(1,3)]
sei.panss.gen<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.gen.no.res  ))[7])[c(1,3)]
sei.panss.neg<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.neg.no.res ))[7])[c(1,3)]
sei.panss.pos<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.pos.no.res  ))[7])[c(1,3)]
sei.panss.tot<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.tot.no.res  ))[7])[c(1,3)]
sei.num.prev.hosp<-unlist(summary(coxph(formula = surv.obj.no.res ~num.prev.hosp.no.res  ))[7])[c(1,3)]
sei.eps<-unlist(summary(coxph(formula = surv.obj.no.res ~eps.no.res ))[7])[c(1,3)]

######CALCULATE HR AND 95%CI

sex.hr<-coxph(formula = surv.obj ~sex )
sex.hr.res<-coxph(formula = surv.obj.res ~sex.res )
sex.hr.no.res<-coxph(formula = surv.obj.no.res ~sex.no.res )

se.sex.hr<-sqrt(sex.hr[[2]])
beta.sex.hr<-sex.hr[[1]]

up.lim.sex.hr<-exp(beta.sex.hr+(1.96*se.sex.hr))
low.lim.sex.hr<-exp(beta.sex.hr-(1.96*se.sex.hr))
hr.sex<-exp(beta.sex.hr)

se.sex.hr.res<-sqrt(sex.hr.res[[2]])
beta.sex.hr.res<-sex.hr.res[[1]]

up.lim.sex.hr.res<-exp(beta.sex.hr.res+(1.96*se.sex.hr.res))
low.lim.sex.hr.res<-exp(beta.sex.hr.res-(1.96*se.sex.hr.res))
hr.sex.res<-exp(beta.sex.hr.res)

se.sex.hr.no.res<-sqrt(sex.hr.no.res[[2]])
beta.sex.hr.no.res<-sex.hr.no.res[[1]]

up.lim.sex.hr.no.res<-exp(beta.sex.hr.no.res+(1.96*se.sex.hr.no.res))
low.lim.sex.hr.no.res<-exp(beta.sex.hr.no.res-(1.96*se.sex.hr.no.res))
hr.sex.no.res<-exp(beta.sex.hr.no.res)

age.hr<-coxph(formula = surv.obj ~age )
age.hr.res<-coxph(formula = surv.obj.res ~age.res )
age.hr.no.res<-coxph(formula = surv.obj.no.res ~age.no.res )

se.age.hr<-sqrt(age.hr[[2]])
beta.age.hr<-age.hr[[1]]

up.lim.age.hr<-exp(beta.age.hr+(1.96*se.age.hr))
low.lim.age.hr<-exp(beta.age.hr-(1.96*se.age.hr))
hr.age<-exp(beta.age.hr)

se.age.hr.res<-sqrt(age.hr.res[[2]])
beta.age.hr.res<-age.hr.res[[1]]

up.lim.age.hr.res<-exp(beta.age.hr.res+(1.96*se.age.hr.res))
low.lim.age.hr.res<-exp(beta.age.hr.res-(1.96*se.age.hr.res))
hr.age.res<-exp(beta.age.hr.res)

se.age.hr.no.res<-sqrt(age.hr.no.res[[2]])
beta.age.hr.no.res<-age.hr.no.res[[1]]

up.lim.age.hr.no.res<-exp(beta.age.hr.no.res+(1.96*se.age.hr.no.res))
low.lim.age.hr.no.res<-exp(beta.age.hr.no.res-(1.96*se.age.hr.no.res))
hr.age.no.res<-exp(beta.age.hr.no.res)

reg.hr<-coxph(formula = surv.obj ~region)
reg.hr.res<-coxph(formula = surv.obj.res ~region.res)
reg.hr.no.res<-coxph(formula = surv.obj.no.res ~region.no.res)

se.reg.hr<-sqrt(reg.hr[[2]])
beta.reg.hr<-reg.hr[[1]]

up.lim.reg.hr<-exp(beta.reg.hr+(1.96*se.reg.hr))
low.lim.reg.hr<-exp(beta.reg.hr-(1.96*se.reg.hr))
hr.reg<-exp(beta.reg.hr)

se.reg.hr.res<-sqrt(reg.hr.res[[2]])
beta.reg.hr.res<-reg.hr.res[[1]]

up.lim.reg.hr.res<-exp(beta.reg.hr.res+(1.96*se.reg.hr.res))
low.lim.reg.hr.res<-exp(beta.reg.hr.res-(1.96*se.reg.hr.res))
hr.reg.res<-exp(beta.reg.hr.res)

se.reg.hr.no.res<-sqrt(reg.hr.no.res[[2]])
beta.reg.hr.no.res<-reg.hr.no.res[[1]]

up.lim.reg.hr.no.res<-exp(beta.reg.hr.no.res+(1.96*se.reg.hr.no.res))
low.lim.reg.hr.no.res<-exp(beta.reg.hr.no.res-(1.96*se.reg.hr.no.res))
hr.reg.no.res<-exp(beta.reg.hr.no.res)

bmi.hr<-coxph(formula = surv.obj ~BMI)
bmi.hr.res<-coxph(formula = surv.obj.res ~BMI.res)
bmi.hr.no.res<-coxph(formula = surv.obj.no.res ~BMI.no.res)

se.bmi.hr<-sqrt(bmi.hr[[2]])
beta.bmi.hr<-bmi.hr[[1]]

up.lim.bmi.hr<-exp(beta.bmi.hr+(1.96*se.bmi.hr))
low.lim.bmi.hr<-exp(beta.bmi.hr-(1.96*se.bmi.hr))
hr.bmi<-exp(beta.bmi.hr)

se.bmi.hr.res<-sqrt(bmi.hr.res[[2]])
beta.bmi.hr.res<-bmi.hr.res[[1]]

up.lim.bmi.hr.res<-exp(beta.bmi.hr.res+(1.96*se.bmi.hr.res))
low.lim.bmi.hr.res<-exp(beta.bmi.hr.res-(1.96*se.bmi.hr.res))
hr.bmi.res<-exp(beta.bmi.hr.res)

se.bmi.hr.no.res<-sqrt(bmi.hr.no.res[[2]])
beta.bmi.hr.no.res<-bmi.hr.no.res[[1]]

up.lim.bmi.hr.no.res<-exp(beta.bmi.hr.no.res+(1.96*se.bmi.hr.no.res))
low.lim.bmi.hr.no.res<-exp(beta.bmi.hr.no.res-(1.96*se.bmi.hr.no.res))
hr.bmi.no.res<-exp(beta.bmi.hr.no.res)

aim.hr<-coxph(formula = surv.obj ~aims )
aim.hr.res<-coxph(formula = surv.obj.res ~aims.res )
aim.hr.no.res<-coxph(formula = surv.obj.no.res ~aims.no.res )

se.aim.hr<-sqrt(aim.hr[[2]])
beta.aim.hr<-aim.hr[[1]]

up.lim.aim.hr<-exp(beta.aim.hr+(1.96*se.aim.hr))
low.lim.aim.hr<-exp(beta.aim.hr-(1.96*se.aim.hr))
hr.aim<-exp(beta.aim.hr)

se.aim.hr.res<-sqrt(aim.hr.res[[2]])
beta.aim.hr.res<-aim.hr.res[[1]]

up.lim.aim.hr.res<-exp(beta.aim.hr.res+(1.96*se.aim.hr.res))
low.lim.aim.hr.res<-exp(beta.aim.hr.res-(1.96*se.aim.hr.res))
hr.aim.res<-exp(beta.aim.hr.res)

se.aim.hr.no.res<-sqrt(aim.hr.no.res[[2]])
beta.aim.hr.no.res<-aim.hr.no.res[[1]]

up.lim.aim.hr.no.res<-exp(beta.aim.hr.no.res+(1.96*se.aim.hr.no.res))
low.lim.aim.hr.no.res<-exp(beta.aim.hr.no.res-(1.96*se.aim.hr.no.res))
hr.aim.no.res<-exp(beta.aim.hr.no.res)

bar.hr<-coxph(formula = surv.obj ~bars)
bar.hr.res<-coxph(formula = surv.obj.res ~bars.res )
bar.hr.no.res<-coxph(formula = surv.obj.no.res ~bars.no.res )

se.bar.hr<-sqrt(bar.hr[[2]])
beta.bar.hr<-bar.hr[[1]]

up.lim.bar.hr<-exp(beta.bar.hr+(1.96*se.bar.hr))
low.lim.bar.hr<-exp(beta.bar.hr-(1.96*se.bar.hr))
hr.bar<-exp(beta.bar.hr)

se.bar.hr.res<-sqrt(bar.hr.res[[2]])
beta.bar.hr.res<-bar.hr.res[[1]]

up.lim.bar.hr.res<-exp(beta.bar.hr.res+(1.96*se.bar.hr.res))
low.lim.bar.hr.res<-exp(beta.bar.hr.res-(1.96*se.bar.hr.res))
hr.bar.res<-exp(beta.bar.hr.res)

se.bar.hr.no.res<-sqrt(bar.hr.no.res[[2]])
beta.bar.hr.no.res<-bar.hr.no.res[[1]]

up.lim.bar.hr.no.res<-exp(beta.bar.hr.no.res+(1.96*se.bar.hr.no.res))
low.lim.bar.hr.no.res<-exp(beta.bar.hr.no.res-(1.96*se.bar.hr.no.res))
hr.bar.no.res<-exp(beta.bar.hr.no.res)

cgi.hr<-coxph(formula = surv.obj ~cgi )
cgi.hr.res<-coxph(formula = surv.obj.res ~cgi.res )
cgi.hr.no.res<-coxph(formula = surv.obj.no.res ~cgi.no.res )

se.cgi.hr<-sqrt(cgi.hr[[2]])
beta.cgi.hr<-cgi.hr[[1]]

up.lim.cgi.hr<-exp(beta.cgi.hr+(1.96*se.cgi.hr))
low.lim.cgi.hr<-exp(beta.cgi.hr-(1.96*se.cgi.hr))
hr.cgi<-exp(beta.cgi.hr)

se.cgi.hr.res<-sqrt(cgi.hr.res[[2]])
beta.cgi.hr.res<-cgi.hr.res[[1]]

up.lim.cgi.hr.res<-exp(beta.cgi.hr.res+(1.96*se.cgi.hr.res))
low.lim.cgi.hr.res<-exp(beta.cgi.hr.res-(1.96*se.cgi.hr.res))
hr.cgi.res<-exp(beta.cgi.hr.res)

se.cgi.hr.no.res<-sqrt(cgi.hr.no.res[[2]])
beta.cgi.hr.no.res<-cgi.hr.no.res[[1]]

up.lim.cgi.hr.no.res<-exp(beta.cgi.hr.no.res+(1.96*se.cgi.hr.no.res))
low.lim.cgi.hr.no.res<-exp(beta.cgi.hr.no.res-(1.96*se.cgi.hr.no.res))
hr.cgi.no.res<-exp(beta.cgi.hr.no.res)

dia.hr<-coxph(formula = surv.obj ~age.diag )
dia.hr.res<-coxph(formula = surv.obj.res ~age.diag.res )
dia.hr.no.res<-coxph(formula = surv.obj.no.res ~age.diag.no.res )

se.dia.hr<-sqrt(dia.hr[[2]])
beta.dia.hr<-dia.hr[[1]]

up.lim.dia.hr<-exp(beta.dia.hr+(1.96*se.dia.hr))
low.lim.dia.hr<-exp(beta.dia.hr-(1.96*se.dia.hr))
hr.dia<-exp(beta.dia.hr)

se.dia.hr.res<-sqrt(dia.hr.res[[2]])
beta.dia.hr.res<-dia.hr.res[[1]]

up.lim.dia.hr.res<-exp(beta.dia.hr.res+(1.96*se.dia.hr.res))
low.lim.dia.hr.res<-exp(beta.dia.hr.res-(1.96*se.dia.hr.res))
hr.dia.res<-exp(beta.dia.hr.res)

se.dia.hr.no.res<-sqrt(dia.hr.no.res[[2]])
beta.dia.hr.no.res<-dia.hr.no.res[[1]]

up.lim.dia.hr.no.res<-exp(beta.dia.hr.no.res+(1.96*se.dia.hr.no.res))
low.lim.dia.hr.no.res<-exp(beta.dia.hr.no.res-(1.96*se.dia.hr.no.res))
hr.dia.no.res<-exp(beta.dia.hr.no.res)

doi.hr<-coxph(formula = surv.obj ~doi)
doi.hr.res<-coxph(formula = surv.obj.res ~doi.res)
doi.hr.no.res<-coxph(formula = surv.obj.no.res ~doi.no.res)

se.doi.hr<-sqrt(doi.hr[[2]])
beta.doi.hr<-doi.hr[[1]]

up.lim.doi.hr<-exp(beta.doi.hr+(1.96*se.doi.hr))
low.lim.doi.hr<-exp(beta.doi.hr-(1.96*se.doi.hr))
hr.doi<-exp(beta.doi.hr)

se.doi.hr.res<-sqrt(doi.hr.res[[2]])
beta.doi.hr.res<-doi.hr.res[[1]]

up.lim.doi.hr.res<-exp(beta.doi.hr.res+(1.96*se.doi.hr.res))
low.lim.doi.hr.res<-exp(beta.doi.hr.res-(1.96*se.doi.hr.res))
hr.doi.res<-exp(beta.doi.hr.res)

se.doi.hr.no.res<-sqrt(doi.hr.no.res[[2]])
beta.doi.hr.no.res<-doi.hr.no.res[[1]]

up.lim.doi.hr.no.res<-exp(beta.doi.hr.no.res+(1.96*se.doi.hr.no.res))
low.lim.doi.hr.no.res<-exp(beta.doi.hr.no.res-(1.96*se.doi.hr.no.res))
hr.doi.no.res<-exp(beta.doi.hr.no.res)

dru.hr<-coxph(formula = surv.obj ~drugs )
dru.hr.res<-coxph(formula = surv.obj.res ~drugs.res )
dru.hr.no.res<-coxph(formula = surv.obj.no.res ~drugs.no.res )

se.dru.hr<-sqrt(dru.hr[[2]])
beta.dru.hr<-dru.hr[[1]]

up.lim.dru.hr<-exp(beta.dru.hr+(1.96*se.dru.hr))
low.lim.dru.hr<-exp(beta.dru.hr-(1.96*se.dru.hr))
hr.dru<-exp(beta.dru.hr)

se.dru.hr.no.res<-sqrt(dru.hr.no.res[[2]])
beta.dru.hr.no.res<-dru.hr.no.res[[1]]

up.lim.dru.hr.no.res<-exp(beta.dru.hr.no.res+(1.96*se.dru.hr.no.res))
low.lim.dru.hr.no.res<-exp(beta.dru.hr.no.res-(1.96*se.dru.hr.no.res))
hr.dru.no.res<-exp(beta.dru.hr.no.res)

se.dru.hr.res<-sqrt(dru.hr.res[[2]])
beta.dru.hr.res<-dru.hr.res[[1]]

up.lim.dru.hr.res<-exp(beta.dru.hr.res+(1.96*se.dru.hr.res))
low.lim.dru.hr.res<-exp(beta.dru.hr.res-(1.96*se.dru.hr.res))
hr.dru.res<-exp(beta.dru.hr.res)

nic.hr<-coxph(formula = surv.obj ~nicotine )
nic.hr.res<-coxph(formula = surv.obj.res ~nicotine.res )
nic.hr.no.res<-coxph(formula = surv.obj.no.res ~nicotine.no.res )

se.nic.hr<-sqrt(nic.hr[[2]])
beta.nic.hr<-nic.hr[[1]]

up.lim.nic.hr<-exp(beta.nic.hr+(1.96*se.nic.hr))
low.lim.nic.hr<-exp(beta.nic.hr-(1.96*se.nic.hr))
hr.nic<-exp(beta.nic.hr)

se.nic.hr.res<-sqrt(nic.hr.res[[2]])
beta.nic.hr.res<-nic.hr.res[[1]]

up.lim.nic.hr.res<-exp(beta.nic.hr.res+(1.96*se.nic.hr.res))
low.lim.nic.hr.res<-exp(beta.nic.hr.res-(1.96*se.nic.hr.res))
hr.nic.res<-exp(beta.nic.hr.res)

se.nic.hr.no.res<-sqrt(nic.hr.no.res[[2]])
beta.nic.hr.no.res<-nic.hr.no.res[[1]]

up.lim.nic.hr.no.res<-exp(beta.nic.hr.no.res+(1.96*se.nic.hr.no.res))
low.lim.nic.hr.no.res<-exp(beta.nic.hr.no.res-(1.96*se.nic.hr.no.res))
hr.nic.no.res<-exp(beta.nic.hr.no.res)

gen.hr<-coxph(formula = surv.obj ~panss.gen )
gen.hr.res<-coxph(formula = surv.obj.res ~panss.gen.res) 
gen.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.gen.no.res) 

se.gen.hr<-sqrt(gen.hr[[2]])
beta.gen.hr<-gen.hr[[1]]

up.lim.gen.hr<-exp(beta.gen.hr+(1.96*se.gen.hr))
low.lim.gen.hr<-exp(beta.gen.hr-(1.96*se.gen.hr))
hr.gen<-exp(beta.gen.hr)

se.gen.hr.res<-sqrt(gen.hr.res[[2]])
beta.gen.hr.res<-gen.hr.res[[1]]

up.lim.gen.hr.res<-exp(beta.gen.hr.res+(1.96*se.gen.hr.res))
low.lim.gen.hr.res<-exp(beta.gen.hr.res-(1.96*se.gen.hr.res))
hr.gen.res<-exp(beta.gen.hr.res)

se.gen.hr.no.res<-sqrt(gen.hr.no.res[[2]])
beta.gen.hr.no.res<-gen.hr.no.res[[1]]

up.lim.gen.hr.no.res<-exp(beta.gen.hr.no.res+(1.96*se.gen.hr.no.res))
low.lim.gen.hr.no.res<-exp(beta.gen.hr.no.res-(1.96*se.gen.hr.no.res))
hr.gen.no.res<-exp(beta.gen.hr.no.res)

neg.hr<-coxph(formula = surv.obj ~panss.neg) 
neg.hr.res<-coxph(formula = surv.obj.res ~panss.neg.res) 
neg.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.neg.no.res) 

se.neg.hr<-sqrt(neg.hr[[2]])
beta.neg.hr<-neg.hr[[1]]

up.lim.neg.hr<-exp(beta.neg.hr+(1.96*se.neg.hr))
low.lim.neg.hr<-exp(beta.neg.hr-(1.96*se.neg.hr))
hr.neg<-exp(beta.neg.hr)

se.neg.hr.res<-sqrt(neg.hr.res[[2]])
beta.neg.hr.res<-neg.hr.res[[1]]

up.lim.neg.hr.res<-exp(beta.neg.hr.res+(1.96*se.neg.hr.res))
low.lim.neg.hr.res<-exp(beta.neg.hr.res-(1.96*se.neg.hr.res))
hr.neg.res<-exp(beta.neg.hr.res)

se.neg.hr.no.res<-sqrt(neg.hr.no.res[[2]])
beta.neg.hr.no.res<-neg.hr.no.res[[1]]

up.lim.neg.hr.no.res<-exp(beta.neg.hr.no.res+(1.96*se.neg.hr.no.res))
low.lim.neg.hr.no.res<-exp(beta.neg.hr.no.res-(1.96*se.neg.hr.no.res))
hr.neg.no.res<-exp(beta.neg.hr.no.res)

pos.hr<-coxph(formula = surv.obj ~panss.pos) 
pos.hr.res<-coxph(formula = surv.obj.res ~panss.pos.res) 
pos.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.pos.no.res) 

se.pos.hr<-sqrt(pos.hr[[2]])
beta.pos.hr<-pos.hr[[1]]

up.lim.pos.hr<-exp(beta.pos.hr+(1.96*se.pos.hr))
low.lim.pos.hr<-exp(beta.pos.hr-(1.96*se.pos.hr))
hr.pos<-exp(beta.pos.hr)

se.pos.hr.res<-sqrt(pos.hr.res[[2]])
beta.pos.hr.res<-pos.hr.res[[1]]

up.lim.pos.hr.res<-exp(beta.pos.hr.res+(1.96*se.pos.hr.res))
low.lim.pos.hr.res<-exp(beta.pos.hr.res-(1.96*se.pos.hr.res))
hr.pos.res<-exp(beta.pos.hr.res)

se.pos.hr.no.res<-sqrt(pos.hr.no.res[[2]])
beta.pos.hr.no.res<-pos.hr.no.res[[1]]

up.lim.pos.hr.no.res<-exp(beta.pos.hr.no.res+(1.96*se.pos.hr.no.res))
low.lim.pos.hr.no.res<-exp(beta.pos.hr.no.res-(1.96*se.pos.hr.no.res))
hr.pos.no.res<-exp(beta.pos.hr.no.res)

tot.hr<-coxph(formula = surv.obj ~panss.tot)
tot.hr.res<-coxph(formula = surv.obj.res ~panss.tot.res)
tot.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.tot.no.res)

se.tot.hr<-sqrt(tot.hr[[2]])
beta.tot.hr<-tot.hr[[1]]

up.lim.tot.hr<-exp(beta.tot.hr+(1.96*se.tot.hr))
low.lim.tot.hr<-exp(beta.tot.hr-(1.96*se.tot.hr))
hr.tot<-exp(beta.tot.hr)

se.tot.hr.res<-sqrt(tot.hr.res[[2]])
beta.tot.hr.res<-tot.hr.res[[1]]

up.lim.tot.hr.res<-exp(beta.tot.hr.res+(1.96*se.tot.hr.res))
low.lim.tot.hr.res<-exp(beta.tot.hr.res-(1.96*se.tot.hr.res))
hr.tot.res<-exp(beta.tot.hr.res)

se.tot.hr.no.res<-sqrt(tot.hr.no.res[[2]])
beta.tot.hr.no.res<-tot.hr.no.res[[1]]

up.lim.tot.hr.no.res<-exp(beta.tot.hr.no.res+(1.96*se.tot.hr.no.res))
low.lim.tot.hr.no.res<-exp(beta.tot.hr.no.res-(1.96*se.tot.hr.no.res))
hr.tot.no.res<-exp(beta.tot.hr.no.res)

pre.hr<-coxph(formula = surv.obj ~num.prev.hosp) 
pre.hr.res<-coxph(formula = surv.obj.res ~num.prev.hosp.res) 
pre.hr.no.res<-coxph(formula = surv.obj.no.res ~num.prev.hosp.no.res) 

se.pre.hr<-sqrt(pre.hr[[2]])
beta.pre.hr<-pre.hr[[1]]

up.lim.pre.hr<-exp(beta.pre.hr+(1.96*se.pre.hr))
low.lim.pre.hr<-exp(beta.pre.hr-(1.96*se.pre.hr))
hr.pre<-exp(beta.pre.hr)

se.pre.hr.res<-sqrt(pre.hr.res[[2]])
beta.pre.hr.res<-pre.hr.res[[1]]

up.lim.pre.hr.res<-exp(beta.pre.hr.res+(1.96*se.pre.hr.res))
low.lim.pre.hr.res<-exp(beta.pre.hr.res-(1.96*se.pre.hr.res))
hr.pre.res<-exp(beta.pre.hr.res)

se.pre.hr.no.res<-sqrt(pre.hr.no.res[[2]])
beta.pre.hr.no.res<-pre.hr.no.res[[1]]

up.lim.pre.hr.no.res<-exp(beta.pre.hr.no.res+(1.96*se.pre.hr.no.res))
low.lim.pre.hr.no.res<-exp(beta.pre.hr.no.res-(1.96*se.pre.hr.no.res))
hr.pre.no.res<-exp(beta.pre.hr.no.res)

eps.hr<-coxph(formula = surv.obj ~eps) 
eps.hr.res<-coxph(formula = surv.obj.res ~eps.res) 
eps.hr.no.res<-coxph(formula = surv.obj.no.res ~eps.no.res) 

se.eps.hr<-sqrt(eps.hr[[2]])
beta.eps.hr<-eps.hr[[1]]

up.lim.eps.hr<-exp(beta.eps.hr+(1.96*se.eps.hr))
low.lim.eps.hr<-exp(beta.eps.hr-(1.96*se.eps.hr))
hr.eps<-exp(beta.eps.hr)

se.eps.hr.res<-sqrt(eps.hr.res[[2]])
beta.eps.hr.res<-eps.hr.res[[1]]

up.lim.eps.hr.res<-exp(beta.eps.hr.res+(1.96*se.eps.hr.res))
low.lim.eps.hr.res<-exp(beta.eps.hr.res-(1.96*se.eps.hr.res))
hr.eps.res<-exp(beta.eps.hr.res)

se.eps.hr.no.res<-sqrt(eps.hr.no.res[[2]])
beta.eps.hr.no.res<-eps.hr.no.res[[1]]

up.lim.eps.hr.no.res<-exp(beta.eps.hr.no.res+(1.96*se.eps.hr.no.res))
low.lim.eps.hr.no.res<-exp(beta.eps.hr.no.res-(1.96*se.eps.hr.no.res))
hr.eps.no.res<-exp(beta.eps.hr.no.res)


#####SUMMARY TABLES # from here to end is reviewed and ok

colname.desc.cont<- c("Age (mean)", "Age (SD)", "BMI (mean)", "BMI (SD)","Age at diagnosis (mean)","Age at diagnosis (SD)","Duration of illness (mean)","Duration of illness (SD)", "CGI (mean)","CGI (SD)","Psychopathology total score (mean)","Psychopathology total score (SD)", "Psychopathology general score (mean)","Psychopathology general score (SD)","Psychopathology positive score (mean)","Psychopathology positive score (SD)","Psychopathology negative score (mean)","Psychopathology negative score (SD)","General functioning score (mean)","General functioning score (SD)", "Quality of life score (mean)","Quality of life score (SD)")

mean.age<-mean(age, na.rm=T)
sd.age<-sd(age,na.rm=T)
mean.BMI<-mean(BMI,na.rm=T)
sd.BMI<-sd(BMI,na.rm=T)
mean.agediagnosis<-mean(age.diag, na.rm=T)
sd.agediagnsosis<-sd(age.diag,na.rm=T)
mean.doi<-mean(doi,na.rm=T)
sd.doi<-sd(doi,na.rm=T)
mean.cgi<-mean(cgi,na.rm=T)
sd.cgi<-sd(cgi,na.rm=T)
mean.totps<-mean(panss.tot,na.rm=T)
sd.totps<-sd(panss.tot, na.rm=T)
mean.genps<- mean(panss.gen, na.rm=T)
sd.genps<-sd(panss.gen, na.rm=T)
mean.posps<-mean(panss.pos, na.rm=T)
sd.posps<-sd(panss.pos, na.rm=T)
mean.negps<-mean(panss.neg, na.rm=T)
sd.negps<-sd(panss.neg, na.rm=T)
mean.func<-NA
sd.functioning<-NA
mean.qol<-NA
sd.qol<-NA

desc.cont<-c(mean.age,sd.age,mean.BMI,sd.BMI,mean.agediagnosis,sd.agediagnsosis,mean.doi,sd.doi,mean.cgi,sd.cgi,mean.totps,sd.totps,mean.genps,sd.genps,mean.posps,sd.posps,mean.negps,sd.negps,mean.func,sd.functioning,mean.qol,sd.qol)

desc.cont.mat<-rbind(colname.desc.cont,desc.cont)

mean.age.res<-mean(age.res, na.rm=T)
sd.age.res<-sd(age.res,na.rm=T)
mean.BMI.res<-mean(BMI.res,na.rm=T)
sd.BMI.res<-sd(BMI.res,na.rm=T)
mean.agediagnosis.res<-mean(age.diag.res, na.rm=T)
sd.agediagnsosis.res<-sd(age.diag.res,na.rm=T)
mean.doi.res<-mean(doi.res,na.rm=T)
sd.doi.res<-sd(doi.res,na.rm=T)
mean.cgi.res<-mean(cgi.res,na.rm=T)
sd.cgi.res<-sd(cgi.res,na.rm=T)
mean.totps.res<-mean(panss.tot.res,na.rm=T)
sd.totps.res<-sd(panss.tot.res, na.rm=T)
mean.genps.res<- mean(panss.gen.res, na.rm=T)
sd.genps.res<-sd(panss.gen.res, na.rm=T)
mean.posps.res<-mean(panss.pos.res, na.rm=T)
sd.posps.res<-sd(panss.pos.res, na.rm=T)
mean.negps.res<-mean(panss.neg.res, na.rm=T)
sd.negps.res<-sd(panss.neg.res, na.rm=T)
mean.func.res<-NA
sd.func.res<-NA
mean.qol.res<-NA
sd.qol.res<-NA

desc.cont.res<-c(mean.age.res,sd.age.res,mean.BMI.res,sd.BMI.res,mean.agediagnosis.res,sd.agediagnsosis.res,mean.doi.res,sd.doi.res,mean.cgi.res,sd.cgi.res,mean.totps.res,sd.totps.res,mean.genps.res,sd.genps.res,mean.posps.res,sd.posps.res,mean.negps.res,sd.negps.res,mean.func.res,sd.func.res,mean.qol.res,sd.qol.res)

desc.cont.mat.res<-rbind(colname.desc.cont,desc.cont.res)

mean.age.no.res<-mean(age.no.res, na.rm=T)
sd.age.no.res<-sd(age.no.res,na.rm=T)
mean.BMI.no.res<-mean(BMI.no.res,na.rm=T)
sd.BMI.no.res<-sd(BMI.no.res,na.rm=T)
mean.agediagnosis.no.res<-mean(age.diag.no.res, na.rm=T)
sd.agediagnsosis.no.res<-sd(age.diag.no.res,na.rm=T)
mean.doi.no.res<-mean(doi.no.res,na.rm=T)
sd.doi.no.res<-sd(doi.no.res,na.rm=T)
mean.cgi.no.res<-mean(cgi.no.res,na.rm=T)
sd.cgi.no.res<-sd(cgi.no.res,na.rm=T)
mean.totps.no.res<-mean(panss.tot.no.res,na.rm=T)
sd.totps.no.res<-sd(panss.tot.no.res, na.rm=T)
mean.genps.no.res<- mean(panss.gen.no.res, na.rm=T)
sd.genps.no.res<-sd(panss.gen.no.res, na.rm=T)
mean.posps.no.res<-mean(panss.pos.no.res, na.rm=T)
sd.posps.no.res<-sd(panss.pos.no.res, na.rm=T)
mean.negps.no.res<-mean(panss.neg.no.res, na.rm=T)
sd.negps.no.res<-sd(panss.neg.no.res, na.rm=T)
mean.func.no.res<-NA
sd.func.no.res<-NA
mean.qol.no.res<-NA
sd.qol.no.res<-NA

desc.cont.no.res<-c(mean.age.no.res,sd.age.no.res,mean.BMI.no.res,sd.BMI.no.res,mean.agediagnosis.no.res,sd.agediagnsosis.no.res,mean.doi.no.res,sd.doi.no.res,mean.cgi.no.res,sd.cgi.no.res,mean.totps.no.res,sd.totps.no.res,mean.genps.no.res,sd.genps.no.res,mean.posps.no.res,sd.posps.no.res,mean.negps.no.res,sd.negps.no.res,mean.func.no.res,sd.func.no.res,mean.qol.no.res,sd.qol.no.res)

desc.cont.mat.no.res<-rbind(colname.desc.cont,desc.cont.no.res)


colname.desc.cat<- c("Male (n)","Male (%)", "US (n)", "US (%)", "Family history (n)", "Family history (%)", "Smoking (n)", "Smoking (%)", "Drug use (n)", "Drug use (%)","Days since last hospitalization (n)","Days since last hospitalization (%)", "Number of previous hospitalizations (n)","Number of previous hospitalizations (%)", "Tardive dyskinesia score (n)","Tardive dyskinesia score (%)","Akathisia score (n)","Akathisia score (%)", "Parkinsonism score (n)","Parkinsonism score (%)")

n.male<- length(sex[sex=="M"])
perc.male<-length(sex[sex=="M"])/length(sex)*100
n.us<- length(total.ids)
perc.us<-100
n.fhx<- NA
perc.fhx<-NA
n.smok<- length(nicotine[nicotine==1])
perc.smok<-length(nicotine[nicotine==1])/length(nicotine)*100
n.drug<- length(drugs[drugs==1])
perc.drug<-length(drugs[drugs==1])/length(drugs)*100
n.hosp.n<- length(num.prev.hosp[num.prev.hosp==1])
perc.hosp.n<-length(num.prev.hosp[num.prev.hosp==1])/length(num.prev.hosp)*100
n.hosp.d<-NA
perc.hosp.d<-NA
n.aims<- length(aims[aims==1])
perc.aims<-length(aims[aims==1])/length(aims)*100
n.bars<- length(bars[bars==1])
perc.bars<-length(bars[bars==1])/length(bars)*100
n.eps<- length(eps[eps==1])
perc.eps<-length(eps[eps==1])/length(eps)*100


desc.cat<-c(n.male,perc.male,n.us,perc.us,n.fhx,perc.fhx,n.smok,perc.smok,n.drug,perc.drug,n.hosp.n,perc.hosp.n,n.hosp.d,perc.hosp.d,n.aims,perc.aims,n.bars,perc.bars,n.eps,perc.eps)

desc.cat.mat<-rbind(colname.desc.cat,desc.cat)

n.male.res<- length(sex.res[sex.res=="M"])
perc.male.res<-length(sex.res[sex.res=="M"])/length(sex.res)*100
n.us.res<- length(response.ids)
perc.us.res<-100
n.fhx.res<- NA
perc.fhx.res<-NA
n.smok.res<- length(nicotine.res[nicotine.res==1])
perc.smok.res<-length(nicotine.res[nicotine.res==1])/length(nicotine.res)*100
n.drug.res<- length(drugs.res[drugs.res==1])
perc.drug.res<-length(drugs.res[drugs.res==1])/length(drugs.res)*100
n.hosp.n.res<- length(num.prev.hosp[num.prev.hosp.res==1])
perc.hosp.n.res<-length(num.prev.hosp[num.prev.hosp==1])/length(num.prev.hosp)*100
n.hosp.d.res<-NA
perc.hosp.d.res<-NA
n.aims.res<- length(aims.res[aims.res==1])
perc.aims.res<-length(aims.res[aims.res==1])/length(aims.res)*100
n.bars.res<- length(bars.res[bars.res==1])
perc.bars.res<-length(bars.res[bars.res==1])/length(bars.res)*100
n.eps.res<- length(eps.res[eps.res==1])
perc.eps.res<-length(eps.res[eps.res==1])/length(eps.res)*100

desc.cat.res<-c(n.male.res,perc.male.res,n.us.res,perc.us.res,n.fhx.res,perc.fhx.res,n.smok.res,perc.smok.res,n.drug.res,perc.drug.res,n.hosp.n.res,perc.hosp.n.res,n.hosp.d.res,perc.hosp.d.res,n.aims.res,perc.aims.res,n.bars.res,perc.bars.res,n.eps.res,perc.eps.res)

desc.cat.mat.res<-rbind(colname.desc.cat,desc.cat.res)

n.male.no.res<- length(sex.no.res[sex.no.res=="M"])
perc.male.no.res<-length(sex.no.res[sex.no.res=="M"])/length(sex.no.res)*100
n.us.no.res<- length(no.response.ids)
perc.us.no.res<-100
n.fhx.no.res<- NA
perc.fhx.no.res<-NA
n.smok.no.res<- length(nicotine.no.res[nicotine.no.res==1])
perc.smok.no.res<-length(nicotine.no.res[nicotine.no.res==1])/length(nicotine.no.res)*100
n.drug.no.res<- length(drugs.no.res[drugs.no.res==1])
perc.drug.no.res<-length(drugs.no.res[drugs.no.res==1])/length(drugs.no.res)*100
n.hosp.n.no.res<- length(num.prev.hosp[num.prev.hosp.no.res==1])
perc.hosp.n.no.res<-length(num.prev.hosp[num.prev.hosp==1])/length(num.prev.hosp)*100
n.hosp.d.no.res<-NA
perc.hosp.d.no.res<-NA
n.aims.no.res<- length(aims.no.res[aims.no.res==1])
perc.aims.no.res<-length(aims.no.res[aims.no.res==1])/length(aims.no.res)*100
n.bars.no.res<- length(bars.no.res[bars.no.res==1])
perc.bars.no.res<-length(bars.no.res[bars.no.res==1])/length(bars.no.res)*100
n.eps.no.res<- length(eps.no.res[eps.no.res==1])
perc.eps.no.res<-length(eps.no.res[eps.no.res==1])/length(eps.no.res)*100

desc.cat.no.res<-c(n.male.no.res,perc.male.no.res,n.us.no.res,perc.us.no.res,n.fhx.no.res,perc.fhx.no.res,n.smok.no.res,perc.smok.no.res,n.drug.no.res,perc.drug.no.res,n.hosp.n.no.res,perc.hosp.n.no.res,n.hosp.d.no.res,perc.hosp.d.no.res,n.aims.no.res,perc.aims.no.res,n.bars.no.res,perc.bars.no.res,n.eps.no.res,perc.eps.no.res)

desc.cat.mat.no.res<-rbind(colname.desc.cat,desc.cat.no.res)


colname.outc<-c("Total sample 'n'", "Relapse 'n'", "Relapse '%'", "Median time to relapse 'days'", "Events per 100 patient - years")

n.total<-length(total.ids)
n.relapse<-length(status[status==1])
perc.relapse<-length(status[status==1])/length(status)*100
median.time<-median(time.to.event, na.rm=T)
py.inc

outc<-c(n.total,n.relapse,perc.relapse,median.time,py.inc)

outc.mat<-rbind(colname.outc,outc)

n.total.res<-length(response.ids)
n.relapse.res<-length(status.res[status.res==1])
perc.relapse.res<-length(status.res[status.res==1])/length(status.res)*100
median.time.res<-median(time.to.event.res, na.rm=T)
py.inc.res

outc.res<-c(n.total.res,n.relapse.res,perc.relapse.res,median.time.res,py.inc.res)

outc.mat.res<-rbind(colname.outc,outc.res)

n.total.no.res<-length(no.response.ids)
n.relapse.no.res<-length(status.no.res[status.no.res==1])
perc.relapse.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100
median.time.no.res<-median(time.to.event.no.res, na.rm=T)
py.inc.no.res

outc.no.res<-c(n.total.no.res,n.relapse.no.res,perc.relapse.no.res,median.time.no.res,py.inc.no.res)

outc.mat.no.res<-rbind(colname.outc,outc.no.res)

colname.HR<-c("Male gender HR","Male gender Lower 95% CI","Male gender Upper 95% CI","Age HR", "Age Lower 95% CI","Age  Upper 95% CI","Proportion US HR", "Proportion US Lower 95% CI","Proportion US Upper 95% CI","BMI HR",  "BMI Lower 95% CI","BMI Upper 95% CI", "Age at diagnosis HR","Age at diagnosis Lower 95% CI","Age at diagnosis Upper 95% CI","Duration of illness HR","Duration of illness Lower 95% CI","Duration of illness Upper 95% CI","Time since last hospitalization HR","Time since last hospitalization Lower 95% CI","Time since last hospitalization Upper 95% CI","Number of previous hospitalizations HR","Number of previous hospitalizations Lower 95% CI","Number of previous hospitalizations Upper 95% CI","Family history HR","Family history Lower 95% CI","Family history Upper 95% CI","Smoking HR","Smoking Lower 95% CI","Smoking Upper 95% CI","Drug use HR","Drug use Lower 95% CI","Drug use Upper 95% CI","CGI HR","CGI Lower 95% CI","CGI Upper 95% CI","Psychopathology total score HR","Psychopathology total score Lower 95% CI","Psychopathology total score Upper 95% CI","Psychopathology general score HR","Psychopathology general score Lower 95% CI","Psychopathology general score Upper 95% CI","Psychopathology positive score HR","Psychopathology positive score Lower 95% CI","Psychopathology positive score Upper 95% CI","Psychopathology negative score HR","Psychopathology negative score Lower 95% CI","Psychopathology negative score Upper 95% CI","General functioning score HR",  "General functioning score Lower 95% CI","General functioning score Upper 95% CI", "Quality of life score HR",  "Quality of life score Lower 95% CI","Quality of life score Upper 95% CI","Tardive dyskinesia score HR","Tardive dyskinesia score Lower 95% CI","Tardive dyskinesia score Upper 95% CI","Akathisia score HR","Akathisia score Lower 95% CI","Akathisia score Upper 95% CI","Parkinsonism score HR","Parkinsonism score Lower 95% CI","Parkinsonism score Upper 95% CI")

hr<- cbind(
  hr.sex,low.lim.sex.hr,up.lim.sex.hr,
  hr.age,low.lim.age.hr,up.lim.age.hr,
  NA,NA,NA,
  hr.bmi,low.lim.bmi.hr,up.lim.bmi.hr,
  hr.dia,low.lim.dia.hr,up.lim.dia.hr,
  hr.doi,low.lim.doi.hr,up.lim.doi.hr,
  NA,NA,NA,
  hr.pre,low.lim.pre.hr,up.lim.pre.hr,
  NA,NA,NA,
  hr.nic,low.lim.nic.hr,up.lim.nic.hr,
  hr.dru,low.lim.dru.hr,up.lim.dru.hr,
  hr.cgi,low.lim.cgi.hr,up.lim.cgi.hr,
  hr.tot,low.lim.tot.hr,up.lim.tot.hr,
  hr.gen,low.lim.gen.hr,up.lim.gen.hr,
  hr.pos,low.lim.pos.hr,up.lim.pos.hr,
  hr.neg,low.lim.neg.hr,up.lim.neg.hr,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim,low.lim.aim.hr,up.lim.aim.hr,
  hr.bar,low.lim.bar.hr,up.lim.bar.hr,
  hr.eps,low.lim.eps.hr,up.lim.eps.hr)

hr.mat<-rbind(colname.HR,hr)


hr.res<- cbind(
  hr.sex.res,low.lim.sex.hr.res,up.lim.sex.hr.res,
  hr.age.res,low.lim.age.hr.res,up.lim.age.hr.res,
  NA,NA,NA,
  hr.bmi.res,low.lim.bmi.hr.res,up.lim.bmi.hr.res,
  hr.dia.res,low.lim.dia.hr.res,up.lim.dia.hr.res,
  hr.doi.res,low.lim.doi.hr.res,up.lim.doi.hr.res,
  NA,NA,NA,
  hr.pre.res,low.lim.pre.hr.res,up.lim.pre.hr.res,
  NA,NA,NA,
  hr.nic.res,low.lim.nic.hr.res,up.lim.nic.hr.res,
  hr.dru.res,low.lim.dru.hr.res,up.lim.dru.hr.res,
  hr.cgi.res,low.lim.cgi.hr.res,up.lim.cgi.hr.res,
  hr.tot.res,low.lim.tot.hr.res,up.lim.tot.hr.res,
  hr.gen.res,low.lim.gen.hr.res,up.lim.gen.hr.res,
  hr.pos.res,low.lim.pos.hr.res,up.lim.pos.hr.res,
  hr.neg.res,low.lim.neg.hr.res,up.lim.neg.hr.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim.res,low.lim.aim.hr.res,up.lim.aim.hr.res,
  hr.bar.res,low.lim.bar.hr.res,up.lim.bar.hr.res,
  hr.eps.res,low.lim.eps.hr.res,up.lim.eps.hr.res)

hr.mat.res<-rbind(colname.HR,hr.res)

hr.no.res<- cbind(
  hr.sex.no.res,low.lim.sex.hr.no.res,up.lim.sex.hr.no.res,
  hr.age.no.res,low.lim.age.hr.no.res,up.lim.age.hr.no.res,
  NA,NA,NA,
  hr.bmi.no.res,low.lim.bmi.hr.no.res,up.lim.bmi.hr.no.res,
  hr.dia.no.res,low.lim.dia.hr.no.res,up.lim.dia.hr.no.res,
  hr.doi.no.res,low.lim.doi.hr.no.res,up.lim.doi.hr.no.res,
  NA,NA,NA,
  hr.pre.no.res,low.lim.pre.hr.no.res,up.lim.pre.hr.no.res,
  NA,NA,NA,
  hr.nic.no.res,low.lim.nic.hr.no.res,up.lim.nic.hr.no.res,
  hr.dru.no.res,low.lim.dru.hr.no.res,up.lim.dru.hr.no.res,
  hr.cgi.no.res,low.lim.cgi.hr.no.res,up.lim.cgi.hr.no.res,
  hr.tot.no.res,low.lim.tot.hr.no.res,up.lim.tot.hr.no.res,
  hr.gen.no.res,low.lim.gen.hr.no.res,up.lim.gen.hr.no.res,
  hr.pos.no.res,low.lim.pos.hr.no.res,up.lim.pos.hr.no.res,
  hr.neg.no.res,low.lim.neg.hr.no.res,up.lim.neg.hr.no.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim.no.res,low.lim.aim.hr.no.res,up.lim.aim.hr.no.res,
  hr.bar.no.res,low.lim.bar.hr.no.res,up.lim.bar.hr.no.res,
  hr.eps.no.res,low.lim.eps.hr.no.res,up.lim.eps.hr.no.res)

hr.mat.no.res<-rbind(colname.HR,hr.no.res)

hr.int<-cbind(
  ci.int.sex[1],ci.int.sex[2],ci.int.sex[3],
  ci.int.age[1],ci.int.age[2],ci.int.age[3],
  NA,NA,NA,
  ci.int.BMI[1],ci.int.BMI[2],ci.int.BMI[3],
  ci.int.agediag[1],ci.int.agediag[2],ci.int.agediag[3],
  ci.int.doi[1],ci.int.doi[2],ci.int.doi[3],
  NA,NA,NA,
  ci.int.num.prev.hosp[1],ci.int.num.prev.hosp[2],ci.int.num.prev.hosp[3],
  NA,NA,NA,
  ci.int.nicotine[1],ci.int.nicotine[2],ci.int.nicotine[3],
  ci.int.drugs[1],ci.int.drugs[2],ci.int.drugs[3],
  ci.int.cgi[1],ci.int.cgi[2],ci.int.cgi[3],
  ci.int.panss.tot[1],ci.int.panss.tot[2],ci.int.panss.tot[3],
  ci.int.panss.gen[1],ci.int.panss.gen[2],ci.int.panss.gen[3],
  ci.int.panss.pos[1],ci.int.panss.pos[2],ci.int.panss.pos[3],
  ci.int.panss.neg[1],ci.int.panss.neg[2],ci.int.panss.neg[3],
  NA,NA,NA,
  NA,NA,NA,
  ci.int.aims[1],ci.int.aims[2],ci.int.aims[3],
  ci.int.bars[1],ci.int.bars[2],ci.int.bars[3],
  ci.int.eps[1],ci.int.eps[2],ci.int.eps[3])

hr.mat.int<-rbind(colname.HR,hr.int)

hr.int.seiyi<-cbind(
  sei.int.sex[1],sei.int.sex[2],
  sei.int.age[1],sei.int.age[2],
  NA,NA,
  sei.int.BMI[1],sei.int.BMI[2],
  sei.int.agediag[1],sei.int.agediag[2],
  sei.int.doi[1],sei.int.doi[2],
  NA,NA,
  sei.int.num.prev.hosp[1],sei.int.num.prev.hosp[2],
  NA,NA,
  sei.int.nicotine[1],sei.int.nicotine[2],
  sei.int.drugs[1],sei.int.drugs[2],
  sei.int.cgi[1],sei.int.cgi[2],
  sei.int.panss.tot[1],sei.int.panss.tot[2],
  sei.int.panss.gen[1],sei.int.panss.gen[2],
  sei.int.panss.pos[1],sei.int.panss.pos[2],
  sei.int.panss.neg[1],sei.int.panss.neg[2],
  NA,NA,
  NA,NA,
  sei.int.aims[1],sei.int.aims[2],
  sei.int.bars[1],sei.int.bars[2],
  sei.int.eps[1],sei.int.eps[2])

hr.nores.seiyi<-cbind(
  sei.sex[1],sei.sex[2],
  sei.age[1],sei.age[2],
  NA,NA,
  sei.BMI[1],sei.BMI[2],
  sei.agediag[1],sei.agediag[2],
  sei.doi[1],sei.doi[2],
  NA,NA,
  sei.num.prev.hosp[1],sei.num.prev.hosp[2],
  NA,NA,
  sei.nicotine[1],sei.nicotine[2],
  sei.drugs[1],sei.drugs[2],
  sei.cgi[1],sei.cgi[2],
  sei.panss.tot[1],sei.panss.tot[2],
  sei.panss.gen[1],sei.panss.gen[2],
  sei.panss.pos[1],sei.panss.pos[2],
  sei.panss.neg[1],sei.panss.neg[2],
  NA,NA,
  NA,NA,
  sei.aims[1],sei.aims[2],
  sei.bars[1],sei.bars[2],
  sei.eps[1],sei.eps[2])

xx<-study1.surv.fit
xx.res<-study1.surv.fit.res
xx.no.res<-study1.surv.fit.no.res

xx.t<-xx[[2]]/7
xx.p<-xx[[6]]

xx.t.res<-xx.res[[2]]/7
xx.p.res<-xx.res[[6]]

xx.t.no.res<-xx.no.res[[2]]/7
xx.p.no.res<-xx.no.res[[6]]

surv.mat<-cbind(xx.t,xx.p)  
surv.mat.res<-cbind(xx.t.res,xx.p.res)  
surv.mat.no.res<-cbind(xx.t.no.res,xx.p.no.res) 

write.table(surv.mat,file="/Users/joserubio/ACLAIMS_results/surv_mat_aclaims_H_wk_v2.csv",sep=",")
write.table(surv.mat.res,file="/Users/joserubio/ACLAIMS_results/surv_mat.res_aclaims_H_wk_v2.csv",sep=",")
write.table(surv.mat.no.res,file="/Users/joserubio/ACLAIMS_results/surv_mat.no.res_aclaims_H_wk_v2.csv",sep=",")

write.table(desc.cont.mat,file="/Users/joserubio/ACLAIMS_results/desc_cont_aclaims_H_v2.csv",sep=",")
write.table(desc.cont.mat.res,file="/Users/joserubio/ACLAIMS_results/desc_cont_res_aclaims_H_v2.csv",sep=",")
write.table(desc.cont.mat.no.res,file="/Users/joserubio/ACLAIMS_results/desc_cont_no.res_aclaims_H_v2.csv",sep=",")

write.table(desc.cat.mat,file="/Users/joserubio/ACLAIMS_results/desc_cat_aclaims_H_v2.csv",sep=",")
write.table(desc.cat.mat.res,file="/Users/joserubio/ACLAIMS_results/desc_cat.res_aclaims_H_v2.csv",sep=",")
write.table(desc.cat.mat.no.res,file="/Users/joserubio/ACLAIMS_results/desc_cat.no.res_aclaims_H_v2.csv",sep=",")

write.table(outc.mat,file="/Users/joserubio/ACLAIMS_results/outc_aclaims_H_v2.csv",sep=",")
write.table(outc.mat.res,file="/Users/joserubio/ACLAIMS_results/outc.res_aclaims_H_v2.csv",sep=",")
write.table(outc.mat.no.res,file="/Users/joserubio/ACLAIMS_results/outc.no.res_aclaims_H_v2.csv",sep=",")

write.table(hr.mat,file="/Users/joserubio/ACLAIMS_results/hr_aclaims_H_v2.csv",sep=",")
write.table(hr.mat.res,file="/Users/joserubio/ACLAIMS_results/hr.res_aclaims_H_v2.csv",sep=",")
write.table(hr.mat.no.res,file="/Users/joserubio/ACLAIMS_results/hr.no.res_aclaims_H_v2.csv",sep=",")

write.table(hr.mat.int,file="/Users/joserubio/ACLAIMS_results/hr.int_aclaims_H_v2.csv",sep=",")

write.table(hr.int.seiyi,file="/Users/joserubio/ACLAIMS_results/hr.int.seiyi_aclaims_H_v2.csv",sep=",")
write.table(hr.nores.seiyi,file="/Users/joserubio/ACLAIMS_results/hr.nores.seiyi_aclaims_H_v2.csv",sep=",")
