# Authored: Jose M Rubio M.D // jrubio13@northwell.edu
# Checked: George Schoretsanitis M.D.,PhD
# April 9th 2020

##COHORT: PROACTIVE
#################################
library(dplyr)
library(readr)

### a function to match and merge variables from two datasets

match.and.merge.func<-function(dat1.id, dat2.id, dat2.var){
  dat1.var<- array(,length(dat1.id))
  for(i in 1: length(dat1.id)){
    for(j in 1:length(dat2.id)){
      if(dat1.id[i]==dat2.id[j]){dat1.var[i]<-dat2.var[j]}}}
  return(dat1.var)}

##########IDENTIFY TOTAL DATASET
#Allocated to risperidone LAI
#FOLLOWED FOR SUFFICIENT TIME TO HAVE A THERAPEUTIC ANTIPSYCHOTIC PLASMA LEVEL (4 WEEKS)

relapse.dat<-read_csv("/Users/joserubio/PROACTIVE_data/bima_new_6_25_19.csv")

rel<-relapse.dat$RELAPSE
day<-relapse.dat$DAY
id.u<-unique(relapse.dat$subjectkey)

time.to<-array(0,length(id.u))
for(i in 1:length(id.u)){
  temp.rel<-rel[relapse.dat$subjectkey==id.u[i]]
  max.temp.rel<-max(temp.rel, na.rm=T)
  temp.day<-day[relapse.dat$subjectkey==id.u[i]]
  if(max.temp.rel==1){time.to[i]<-min(temp.day[temp.rel==1], na.rm=T)}}

for(i in 1:length(id.u)){
  temp.rel<-rel[relapse.dat$subjectkey==id.u[i]]
  max.temp.rel<-max(temp.rel, na.rm=T)
  temp.day<-day[relapse.dat$subjectkey==id.u[i]]
  if(max.temp.rel==0){time.to[i]<-max(temp.day, na.rm=T)}}

w4.ids<-id.u[time.to>28]

med.dat.p<-read.delim("/Users/joserubio/PROACTIVE_data/med_profile01.txt", header=TRUE, sep="\t")
med.dat<-med.dat.p[-1,]
med.vis.num<-as.numeric(as.character(med.dat$visnum))
med.dat.v1<-med.dat[med.vis.num==1,]

med.id<-as.character(med.dat.v1$subjectkey)
trtgrp<-as.numeric(as.character(med.dat.v1$trtgrp_p))

lai.id.prov<-med.id[trtgrp==1]
lai.id<-unique(lai.id.prov) 

total.ids<-intersect(lai.id, w4.ids) #ok

##########DENTIFY 'RESPONSE' DATASET (THESE ARE IN FACT REMITTERS, IN THIS TRIAL, GIVEN SPARCITY OF DATA, WE ARE ONLY ABLE TO USE "MILD OR LESS" PSX (BPRS) BY THE END OF THE STABILIZATION PERIOD [V7])

bprs.dat<-read.delim("/Users/joserubio/PROACTIVE_data/bprs01.txt", header=TRUE, sep="\t")
bprs.dat<-bprs.dat[-1,]
bprs.vis.num<-as.numeric(as.character(bprs.dat$visnum))
bprs.dat<-bprs.dat[bprs.vis.num==7,]

bprs.id<-as.character(bprs.dat$subjectkey)
bprs.id.u<-as.character(unique(bprs.dat$subjectkey))

bprs.res.id<-array(0,length(bprs.id.u))
for(i in 1:length(bprs.id.u)){
  pos.array<-c(bprs.dat$bprs_conc[bprs.id==bprs.id.u[i]],bprs.dat$bprs_hall[bprs.id==bprs.id.u[i]],bprs.dat$bprs_unus[bprs.id==bprs.id.u[i]],bprs.dat$bprs_susp[bprs.id==bprs.id.u[i]])
  max.pos<-max(pos.array, na.rm=T)
  if(max.pos<4){bprs.res.id[i]<-1}}

response.ids.pr<-bprs.id.u[bprs.res.id==1]
response.ids<-intersect(total.ids,response.ids.pr) #ok
no.response.ids<-setdiff(total.ids,response.ids)

########DEFINE STATUS PER DATASET (1=event; 0=censor)

relapse.dat<-read_csv("/Users/joserubio/PROACTIVE_data/bima_new_6_25_19.csv")

relapse.id.u<-unique(relapse.dat$subjectkey)

rel<-array(0,length(relapse.id.u))
for(i in 1:length(relapse.id.u)){
  temp.array<-relapse.dat$RELAPSE[relapse.dat$subjectkey==relapse.id.u[i]]
  rel.temp<-max(temp.array, na.rm=T)
  if(rel.temp==1){rel[i]<-1}
}

status<-match.and.merge.func(total.ids,relapse.id.u,rel) #ok
status.res<-match.and.merge.func(response.ids,relapse.id.u,rel)#ok
status.no.res<-match.and.merge.func(no.response.ids,relapse.id.u,rel)#ok

######DEFINE TIME TO EVENT PER DATASET

relapse.dat<-read_csv("/Users/joserubio/PROACTIVE_data/bima_new_6_25_19.csv") ### you have already done this before

rel<-relapse.dat$RELAPSE
day<-relapse.dat$DAY
id.u<-unique(relapse.dat$subjectkey)

time.to<-array(0,length(id.u))
for(i in 1:length(id.u)){
  temp.rel<-rel[relapse.dat$subjectkey==id.u[i]]
  max.temp.rel<-max(temp.rel, na.rm=T)
  temp.day<-day[relapse.dat$subjectkey==id.u[i]]
  if(max.temp.rel==1){time.to[i]<-min(temp.day[temp.rel==1], na.rm=T)}}

for(i in 1:length(id.u)){
  temp.rel<-rel[relapse.dat$subjectkey==id.u[i]]
  max.temp.rel<-max(temp.rel, na.rm=T)
  temp.day<-day[relapse.dat$subjectkey==id.u[i]]
  if(max.temp.rel==0){time.to[i]<-max(temp.day, na.rm=T)}}

time.to.event<-match.and.merge.func(total.ids,id.u,time.to) #ok
time.to.event.res<-match.and.merge.func(response.ids,id.u,time.to) #ok
time.to.event.no.res<-match.and.merge.func(no.response.ids,id.u,time.to) #ok

#SURVIVAL ANALYSIS

library(survival)
surv.obj <- Surv(time.to.event, status)
surv.obj.res <- Surv(time.to.event.res, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res, status.no.res)
survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)
study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)

##CALCULATE PERSON YEARS AND ABSOLUTE AND PERSON X YEAR INCIDENCE RATE

#person-year
per.year<-sum(time.to.event, na.rm=T)/365
per.year.res<-sum(time.to.event.res, na.rm=T)/365
per.year.no.res<-sum(time.to.event.no.res, na.rm=T)/365

#absolute incidence
abs.inc<-length(status[status==1])/length(status)*100 
abs.inc.res<-length(status.res[status.res==1])/length(status.res)*100
abs.inc.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100

#person-year incidence
py.inc<-length(status[status==1])/per.year*100
py.inc.res<-length(status.res[status.res==1])/per.year.res*100
py.inc.no.res<-length(status.no.res[status.no.res==1])/per.year.no.res*100

rem.stat<-array(0,length(total.ids))
for(i in 1: length(total.ids)){
  for(j in 1: length(response.ids)){
    if(total.ids[i]==response.ids[j]){
      rem.stat[i]<-1
    }
  }
}

#############COVARIATES

##SEX
dem.dat<-read.delim("/Users/joserubio/PROACTIVE_data/demogr01.txt", header=TRUE, sep="\t")

dem.dat<-dem.dat[-1,]
dem.id<-as.character(dem.dat$subjectkey)
dem.id.u<-as.character(unique(dem.dat$subjectkey))

sex<-as.character(dem.dat$gender)
sex[sex=="F"]<-0
sex[sex=="M"]<-1
sex.1<-as.numeric(sex)

sex<-match.and.merge.func(total.ids,dem.id.u,sex.1) 
sex.res<-match.and.merge.func(response.ids,dem.id.u,sex.1)
sex.no.res<-match.and.merge.func(no.response.ids,dem.id.u,sex.1)

##AGE

dem.dat<-read.delim("/Users/joserubio/PROACTIVE_data/demogr01.txt", header=TRUE, sep="\t")

dem.dat<-dem.dat[-1,]
dem.id<-as.character(dem.dat$subjectkey)
dem.id.u<-as.character(unique(dem.dat$subjectkey))

age.m<-as.numeric(as.character(dem.dat$interview_age))
age.y<-age.m/12

age<-match.and.merge.func(total.ids,dem.id.u,age.y) #6/28 
age.res<-match.and.merge.func(response.ids,dem.id.u,age.y) 
age.no.res<-match.and.merge.func(no.response.ids,dem.id.u,age.y) 
#REGION
region<-array(1,length(total.ids))
region.res<-array(1,length(response.ids))
region.no.res<-array(1,length(no.response.ids))
#BMI
vit.dat.t<-read.delim("/Users/joserubio/PROACTIVE_data/vitals01.txt", header=TRUE, sep="\t")
vit.dat.1<-vit.dat.t[-1,]
vis.num<-as.numeric(as.character(vit.dat.1$visnum))
vit.dat<-vit.dat.1[vis.num==1,]
vit.id.u<-unique(as.character(vit.dat$subjectkey))

bl.wt<-as.numeric(as.character(vit.dat$blwt))
bl.ht<-as.numeric(as.character(vit.dat$vtl007))

weight<-match.and.merge.func(total.ids,vit.id.u,bl.wt)
weight.res<-match.and.merge.func(response.ids,vit.id.u,bl.wt)
weight.no.res<-match.and.merge.func(no.response.ids,vit.id.u,bl.wt)
height<-match.and.merge.func(total.ids,vit.id.u,bl.ht)
height.res<-match.and.merge.func(response.ids,vit.id.u,bl.ht)
height.no.res<-match.and.merge.func(no.response.ids,vit.id.u,bl.ht)
BMI<-(weight/height^2)*703 #6/27
BMI.res<-(weight.res/height.res^2)*703 
BMI.no.res<-(weight.no.res/height.no.res^2)*703

##AIMS
aims.dat<-read.delim("/Users/joserubio/PROACTIVE_data/aims01.txt", header=TRUE, sep="\t")
aims.dat<-aims.dat[-1,]
aims.vis.num<-as.numeric(as.character(aims.dat$visnum))
aims.dat<-aims.dat[aims.vis.num==0,]
aims.id<-as.character(aims.dat$subjectkey)
aims.id.u<-as.character(unique(aims.dat$subjectkey))

aims.1<-as.numeric(as.character(aims.dat$aims_global8_date1))

aims.score<-array(,length(aims.id.u))
for(i in 1:length(aims.id.u)){
  aims.score[i]<-aims.1[aims.id==aims.id.u[i]]}
aims.score[aims.score<=2]<-0
aims.score[aims.score>2]<-1


aims <- match.and.merge.func(total.ids,aims.id.u, aims.score) 
aims.res <- match.and.merge.func(response.ids,aims.id.u, aims.score) 
aims.no.res <- match.and.merge.func(no.response.ids,aims.id.u, aims.score) 
#BARS

akath.dat<-read.delim("/Users/joserubio/PROACTIVE_data/bns01.txt", header=TRUE, sep="\t")
akath.dat<-akath.dat[-1,]
akath.vis.num<-as.numeric(as.character(akath.dat$visnum))
akath.dat<-akath.dat[akath.vis.num==0,]
akath.id<-as.character(akath.dat$subjectkey)
akath.id.u<-as.character(unique(aims.dat$subjectkey))

akg<-as.numeric(as.character(akath.dat$bnsa4))

barnes.score<-array(,length(akath.id.u))
for(i in 1:length(akath.id.u)){
  barnes.score[i]<-akg[akath.id==akath.id.u[i]]
}

barnes.score[barnes.score<=2]<-0
barnes.score[barnes.score>2]<-1

bars<-match.and.merge.func(total.ids,akath.id.u,barnes.score) 
bars.res<-match.and.merge.func(response.ids,akath.id.u,barnes.score) 
bars.no.res<-match.and.merge.func(no.response.ids,akath.id.u,barnes.score) 
##CGI
cgi.dat<-read.delim("/Users/joserubio/PROACTIVE_data/cgi01.txt", header=TRUE, sep="\t")

cgi.dat<-cgi.dat[-1,]
cgi.vis.num<-as.numeric(as.character(cgi.dat$visnum))
cgi.dat<-cgi.dat[cgi.vis.num==0,]
cgi.id<-as.character(cgi.dat$subjectkey)
cgi.id.u<-as.character(unique(cgi.dat$subjectkey))

cgi<-as.numeric(as.character(cgi.dat$cgi_si))

cgi.score<-array(,length(cgi.id.u))
for(i in 1:length(cgi.id.u)){
  cgi.score[i]<-cgi[cgi.id==cgi.id.u[i]]
}

cgi<-match.and.merge.func(total.ids,cgi.id.u,cgi.score) 
cgi.res<-match.and.merge.func(response.ids,cgi.id.u,cgi.score) 
cgi.no.res<-match.and.merge.func(no.response.ids,cgi.id.u,cgi.score) 

######AGE AT DIAGNOSIS
hx.dat.t<-read.delim("/Users/joserubio/PROACTIVE_data/psychistory01.txt", header=TRUE, sep="\t")

hx.dat<-hx.dat.t[-1,]
hx.id<-as.character(hx.dat$subjectkey)
hx.id.u<-unique(hx.id)

onset<-as.numeric(as.character(hx.dat$hpl_02))

age.diag<-match.and.merge.func(total.ids,hx.id.u,onset) 
age.diag.res<-match.and.merge.func(response.ids,hx.id.u,onset) 
age.diag.no.res<-match.and.merge.func(no.response.ids,hx.id.u,onset) 
#DOI

doi<-age-age.diag 
doi.res<-age.res-age.diag.res 
doi.no.res<-age.no.res-age.diag.no.res 
###TIME SINCE LAST HOSP (years)

t.last.hosp<-(as.numeric(as.character(hx.dat$hpl_06)))*30
t.last.hosp[t.last.hosp<365]<-0
t.last.hosp[t.last.hosp>=365]<-1

prev.hosp<-match.and.merge.func(total.ids,hx.id.u,t.last.hosp) 
prev.hosp.res<-match.and.merge.func(response.ids,hx.id.u,t.last.hosp) 
prev.hosp.no.res<-match.and.merge.func(no.response.ids,hx.id.u,t.last.hosp) 
##NUMBER HOSPITALIZATIONS
n.hosp.1<-as.numeric(as.character(hx.dat$hpl_04))

n.hosp.1[n.hosp.1<=2]<-0
n.hosp.1[n.hosp.1>2]<-1

n.hosp<-match.and.merge.func(total.ids,hx.id.u,n.hosp.1)
n.hosp.res<-match.and.merge.func(response.ids,hx.id.u,n.hosp.1)
n.hosp.no.res<-match.and.merge.func(no.response.ids,hx.id.u,n.hosp.1)
#SMOKING

sub.dat.t<-read.delim("/Users/joserubio/PROACTIVE_data/subuq01.txt", header=TRUE, sep="\t")
sub.dat<-sub.dat.t[-1,]
sub.id.u<-as.character(unique(sub.dat$subjectkey))

smoke<-as.numeric(as.character(sub.dat$smoker))

nicotine<-match.and.merge.func(total.ids,sub.id.u,smoke)
nicotine.res<-match.and.merge.func(response.ids,sub.id.u,smoke)  
nicotine.no.res<-match.and.merge.func(no.response.ids,sub.id.u,smoke)  
####CURRENT DRUG USE (CATEGORICAL)
scid.dat.t<-read.delim("/Users/joserubio/PROACTIVE_data/scid01.txt", header=TRUE, sep="\t")
scid.dat<-scid.dat.t[-1,]

scid.id<-as.character(scid.dat$subjectkey)
scid.id.u<-unique(scid.id)

alc<-as.numeric(as.character(scid.dat$sciddx_007))
bzd<-as.numeric(as.character(scid.dat$sciddx_009))
can<-as.numeric(as.character(scid.dat$sciddx_011))
sti<-as.numeric(as.character(scid.dat$sciddx_013))
opi<-as.numeric(as.character(scid.dat$sciddx_015))
coc<-as.numeric(as.character(scid.dat$sciddx_017))
hal<-as.numeric(as.character(scid.dat$sciddx_019))
pol<-as.numeric(as.character(scid.dat$sciddx_021))


current.drugs<-array(0,length(scid.id.u))
for(i in 1:length(scid.id.u)){
  alc.t<-alc[scid.id==scid.id.u[i]]
  bzd.t<-bzd[scid.id==scid.id.u[i]]
  can.t<-can[scid.id==scid.id.u[i]]
  sti.t<-sti[scid.id==scid.id.u[i]]
  opi.t<-opi[scid.id==scid.id.u[i]]
  coc.t<-coc[scid.id==scid.id.u[i]]
  hal.t<-hal[scid.id==scid.id.u[i]]
  pol.t<-pol[scid.id==scid.id.u[i]]
  temp.array<-c(alc.t,bzd.t,can.t,sti.t,opi.t,coc.t,hal.t,pol.t)
  temp.array[is.na(temp.array)]<-0
  max.temp<-max(temp.array,na.rm=T)
  if(max.temp==3){current.drugs[i]<-1}
}

drugs<-match.and.merge.func(total.ids,scid.id.u,current.drugs) 
drugs.res<-match.and.merge.func(response.ids,scid.id.u,current.drugs) 
drugs.no.res<-match.and.merge.func(no.response.ids,scid.id.u,current.drugs) 
###BPRS

bprs.dat<-read.delim("/Users/joserubio/PROACTIVE_data/bprs01.txt", header=TRUE, sep="\t")
bprs.dat<-bprs.dat[-1,]
bprs.vis.num<-as.numeric(as.character(bprs.dat$visnum))
bprs.dat<-bprs.dat[bprs.vis.num==0,]

bprs.tot<-as.numeric(as.character(bprs.dat$bprs_total))

bprs.id<-as.character(bprs.dat$subjectkey)
bprs.id.u<-as.character(unique(bprs.dat$subjectkey))

bprs.score<-array(,length(bprs.id.u))
for(i in 1:length(bprs.id.u)){
  bprs.score[i]<-bprs.tot[bprs.id==bprs.id.u[i]]
}

bprs<-match.and.merge.func(total.ids,bprs.id.u,bprs.score) 
bprs.res<-match.and.merge.func(response.ids,bprs.id.u,bprs.score) 
bprs.no.res<-match.and.merge.func(no.response.ids,bprs.id.u,bprs.score) 


sof.dat.t<-read.delim("/Users/joserubio/PROACTIVE_data/sof01.txt", header=TRUE, sep="\t")
sof.dat.1<-sof.dat.t[-1,]
sof.dat<-sof.dat.1[sof.dat.1$visnum==0,]
sof.id<-as.character(sof.dat$subjectkey)
sof.id.u<-unique(sof.id)

sof.score<-as.numeric(as.character(sof.dat$sof_t))

functioning<-match.and.merge.func(total.ids,sof.id.u,sof.score) 
functioning.res<-match.and.merge.func(response.ids,sof.id.u,sof.score)
functioning.no.res<-match.and.merge.func(no.response.ids,sof.id.u,sof.score)

#EPS
sas.dat.t<-read.delim("/Users/joserubio/PROACTIVE_data/sas01.txt", header=TRUE, sep="\t")
sas.dat<-sas.dat.t[-1,]
sas.vis.num<-as.numeric(as.character(sas.dat$visnum))
sas.dat<-sas.dat[sas.vis.num==0,]

sas.id<-as.character(sas.dat$subjectkey)
sas.id.u<-as.character(unique(sas.dat$subjectkey))

sas.mean<-(as.numeric(as.character(sas.dat$sas_x)))-1

sas.score<-array(,length(sas.id.u))
for(i in 1:length(sas.id.u)){
  sas.score[i]<-sas.mean[sas.id==sas.id.u[i]]
}

sas.score[sas.score<0.65]<-0
sas.score[sas.score>0.64]<-1

eps<-match.and.merge.func(total.ids,sas.id.u,sas.score) 
eps.res<-match.and.merge.func(response.ids,sas.id.u,sas.score)
eps.no.res<-match.and.merge.func(no.response.ids,sas.id.u,sas.score)



##COX REGRESSION

coxph(formula = surv.obj ~sex )
coxph(formula = surv.obj.res ~sex.res )
coxph(formula = surv.obj.no.res ~sex.no.res )
coxph(formula = surv.obj ~age )
coxph(formula = surv.obj.res ~age.res )
coxph(formula = surv.obj.no.res ~age.no.res )
coxph(formula = surv.obj ~region)
coxph(formula = surv.obj.res ~region.res)
coxph(formula = surv.obj.no.res ~region.no.res)

coxph(formula = surv.obj ~BMI)
coxph(formula = surv.obj.res ~BMI.res)
coxph(formula = surv.obj.no.res ~BMI.no.res)

coxph(formula = surv.obj ~aims )
coxph(formula = surv.obj.res ~aims.res )
coxph(formula = surv.obj.no.res ~aims.no.res )

coxph(formula = surv.obj ~bars)
coxph(formula = surv.obj.res ~bars.res )
coxph(formula = surv.obj.no.res ~bars.no.res )

coxph(formula = surv.obj ~cgi )
coxph(formula = surv.obj.res ~cgi.res )
coxph(formula = surv.obj.no.res ~cgi.no.res )

coxph(formula = surv.obj ~age.diag )
coxph(formula = surv.obj.res ~age.diag.res )
coxph(formula = surv.obj.no.res ~age.diag.no.res )

coxph(formula = surv.obj ~doi)
coxph(formula = surv.obj.res ~doi.res)
coxph(formula = surv.obj.no.res ~doi.no.res)

coxph(formula = surv.obj ~drugs )
coxph(formula = surv.obj.res ~drugs.res )
coxph(formula = surv.obj.no.res ~drugs.no.res )

coxph(formula = surv.obj ~nicotine )
coxph(formula = surv.obj.res ~nicotine.res )
coxph(formula = surv.obj.no.res ~nicotine.no.res )

coxph(formula = surv.obj ~bprs )
coxph(formula = surv.obj.res ~bprs.res) 
coxph(formula = surv.obj.no.res ~bprs.no.res) 

coxph(formula = surv.obj ~prev.hosp) 
coxph(formula = surv.obj.res ~prev.hosp.res) 
coxph(formula = surv.obj.no.res ~prev.hosp.no.res) 

coxph(formula = surv.obj ~n.hosp) 
coxph(formula = surv.obj.res ~n.hosp.res) 
coxph(formula = surv.obj.no.res ~n.hosp.no.res) 

coxph(formula = surv.obj ~functioning) 
coxph(formula = surv.obj.res ~functioning.res) 
coxph(formula = surv.obj.no.res ~functioning.no.res) 

coxph(formula = surv.obj ~eps)
coxph(formula = surv.obj.res ~eps.res )
coxph(formula = surv.obj.no.res ~eps.no.res )

#HR and 95%CI for interaction terms
ci.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex ))[8])[c(3,9,12)]
ci.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age ))[8])[c(3,9,12)]
ci.int.region<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region ))[8])[c(3,9,12)]
ci.int.BMI<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[8])[c(3,9,12)]
ci.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims ))[8])[c(3,9,12)]
ci.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars ))[8])[c(3,9,12)]
ci.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi ))[8])[c(3,9,12)]
ci.int.agediag<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age.diag))[8])[c(3,9,12)]
ci.int.doi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*doi ))[8])[c(3,9,12)]
ci.int.drugs<-unlist(summary(coxph(formula = surv.obj ~rem.stat*drugs ))[8])[c(3,9,12)]
ci.int.nicotine<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine ))[8])[c(3,9,12)]
ci.int.bprs<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bprs ))[8])[c(3,9,12)]
ci.int.prev.hosp<-unlist(summary(coxph(formula = surv.obj ~rem.stat*prev.hosp ))[8])[c(3,9,12)]
ci.int.n.hosp<-unlist(summary(coxph(formula = surv.obj ~rem.stat*n.hosp ))[8])[c(3,9,12)]
ci.int.functioning<-unlist(summary(coxph(formula = surv.obj ~rem.stat*functioning ))[8])[c(3,9,12)]
ci.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps ))[8])[c(3,9,12)]

#LogHR and LogSE for interaction terms
sei.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex ))[7])[c(3,9)]
sei.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age ))[7])[c(3,9)]
sei.int.region<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region ))[7])[c(3,9)]
sei.int.BMI<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[7])[c(3,9)]
sei.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims ))[7])[c(3,9)]
sei.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars ))[7])[c(3,9)]
sei.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi ))[7])[c(3,9)]
sei.int.agediag<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age.diag))[7])[c(3,9)]
sei.int.doi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*doi ))[7])[c(3,9)]
sei.int.drugs<-unlist(summary(coxph(formula = surv.obj ~rem.stat*drugs ))[7])[c(3,9)]
sei.int.nicotine<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine ))[7])[c(3,9)]
sei.int.bprs<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bprs ))[7])[c(3,9)]
sei.int.prev.hosp<-unlist(summary(coxph(formula = surv.obj ~rem.stat*prev.hosp ))[7])[c(3,9)]
sei.int.n.hosp<-unlist(summary(coxph(formula = surv.obj ~rem.stat*n.hosp ))[7])[c(3,9)]
sei.int.functioning<-unlist(summary(coxph(formula = surv.obj ~rem.stat*functioning ))[7])[c(3,9)]
sei.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps ))[7])[c(3,9)]

#LogHR and LogSE for Cox for no.remission.ids
sei.sex<-unlist(summary(coxph(formula = surv.obj.no.res ~sex.no.res ))[7])[c(3,9)]

sei.sex<-unlist(summary(coxph(formula = surv.obj.no.res~sex.no.res))[7])[c(1,3)]
sei.age<-unlist(summary(coxph(formula = surv.obj.no.res ~age.no.res ))[7])[c(1,3)]
sei.region<-unlist(summary(coxph(formula = surv.obj.no.res ~region.no.res ))[7])[c(1,3)]
sei.BMI<-unlist(summary(coxph(formula = surv.obj.no.res ~BMI.no.res))[7])[c(1,3)]
sei.aims<-unlist(summary(coxph(formula = surv.obj.no.res ~aims.no.res ))[7])[c(1,3)]
sei.bars<-unlist(summary(coxph(formula = surv.obj.no.res ~bars.no.res ))[7])[c(1,3)]
sei.cgi<-unlist(summary(coxph(formula = surv.obj.no.res ~cgi.no.res ))[7])[c(1,3)]
sei.agediag<-unlist(summary(coxph(formula = surv.obj.no.res ~age.diag.no.res))[7])[c(1,3)]
sei.doi<-unlist(summary(coxph(formula = surv.obj.no.res ~doi.no.res ))[7])[c(1,3)]
sei.drugs<-unlist(summary(coxph(formula = surv.obj.no.res~drugs.no.res ))[7])[c(1,3)]
sei.nicotine<-unlist(summary(coxph(formula = surv.obj.no.res ~nicotine.no.res ))[7])[c(1,3)]
sei.bprs<-unlist(summary(coxph(formula = surv.obj.no.res ~bprs.no.res ))[7])[c(1,3)]
sei.prev.hosp<-unlist(summary(coxph(formula = surv.obj.no.res ~prev.hosp.no.res ))[7])[c(1,3)]
sei.n.hosp<-unlist(summary(coxph(formula = surv.obj.no.res ~n.hosp.no.res ))[7])[c(1,3)]
sei.functioning<-unlist(summary(coxph(formula = surv.obj.no.res~functioning.no.res ))[7])[c(1,3)]
sei.eps<-unlist(summary(coxph(formula = surv.obj.no.res ~eps.no.res ))[7])[c(1,3)]

######CALCULATE HR AND 95%CI

sex.hr<-coxph(formula = surv.obj ~sex )
sex.hr.res<-coxph(formula = surv.obj.res ~sex.res )

se.sex.hr<-sqrt(sex.hr[[2]])
beta.sex.hr<-sex.hr[[1]]

up.lim.sex.hr<-exp(beta.sex.hr+(1.96*se.sex.hr))
low.lim.sex.hr<-exp(beta.sex.hr-(1.96*se.sex.hr))
hr.sex<-exp(beta.sex.hr)

se.sex.hr.res<-sqrt(sex.hr.res[[2]])
beta.sex.hr.res<-sex.hr.res[[1]]

up.lim.sex.hr.res<-exp(beta.sex.hr.res+(1.96*se.sex.hr.res))
low.lim.sex.hr.res<-exp(beta.sex.hr.res-(1.96*se.sex.hr.res))
hr.sex.res<-exp(beta.sex.hr.res)

age.hr<-coxph(formula = surv.obj ~age )
age.hr.res<-coxph(formula = surv.obj.res ~age.res )

se.age.hr<-sqrt(age.hr[[2]])
beta.age.hr<-age.hr[[1]]

up.lim.age.hr<-exp(beta.age.hr+(1.96*se.age.hr))
low.lim.age.hr<-exp(beta.age.hr-(1.96*se.age.hr))
hr.age<-exp(beta.age.hr)

se.age.hr.res<-sqrt(age.hr.res[[2]])
beta.age.hr.res<-age.hr.res[[1]]

up.lim.age.hr.res<-exp(beta.age.hr.res+(1.96*se.age.hr.res))
low.lim.age.hr.res<-exp(beta.age.hr.res-(1.96*se.age.hr.res))
hr.age.res<-exp(beta.age.hr.res)


reg.hr<-coxph(formula = surv.obj ~region)
reg.hr.res<-coxph(formula = surv.obj.res ~region.res)

se.reg.hr<-sqrt(reg.hr[[2]])
beta.reg.hr<-reg.hr[[1]]


up.lim.reg.hr<-exp(beta.reg.hr+(1.96*se.reg.hr))
low.lim.reg.hr<-exp(beta.reg.hr-(1.96*se.reg.hr))
hr.reg<-exp(beta.reg.hr)

se.reg.hr.res<-sqrt(reg.hr.res[[2]])
beta.reg.hr.res<-reg.hr.res[[1]]

up.lim.reg.hr.res<-exp(beta.reg.hr.res+(1.96*se.reg.hr.res))
low.lim.reg.hr.res<-exp(beta.reg.hr.res-(1.96*se.reg.hr.res))
hr.reg.res<-exp(beta.reg.hr.res)


bmi.hr<-coxph(formula = surv.obj ~BMI)
bmi.hr.res<-coxph(formula = surv.obj.res ~BMI.res)

se.bmi.hr<-sqrt(bmi.hr[[2]])
beta.bmi.hr<-bmi.hr[[1]]

up.lim.bmi.hr<-exp(beta.bmi.hr+(1.96*se.bmi.hr))
low.lim.bmi.hr<-exp(beta.bmi.hr-(1.96*se.bmi.hr))
hr.bmi<-exp(beta.bmi.hr)

se.bmi.hr.res<-sqrt(bmi.hr.res[[2]])
beta.bmi.hr.res<-bmi.hr.res[[1]]

up.lim.bmi.hr.res<-exp(beta.bmi.hr.res+(1.96*se.bmi.hr.res))
low.lim.bmi.hr.res<-exp(beta.bmi.hr.res-(1.96*se.bmi.hr.res))
hr.bmi.res<-exp(beta.bmi.hr.res)

aim.hr<-coxph(formula = surv.obj ~aims )
aim.hr.res<-coxph(formula = surv.obj.res ~aims.res )

se.aim.hr<-sqrt(aim.hr[[2]])
beta.aim.hr<-aim.hr[[1]]

up.lim.aim.hr<-exp(beta.aim.hr+(1.96*se.aim.hr))
low.lim.aim.hr<-exp(beta.aim.hr-(1.96*se.aim.hr))
hr.aim<-exp(beta.aim.hr)

se.aim.hr.res<-sqrt(aim.hr.res[[2]])
beta.aim.hr.res<-aim.hr.res[[1]]

up.lim.aim.hr.res<-exp(beta.aim.hr.res+(1.96*se.aim.hr.res))
low.lim.aim.hr.res<-exp(beta.aim.hr.res-(1.96*se.aim.hr.res))
hr.aim.res<-exp(beta.aim.hr.res)


bar.hr<-coxph(formula = surv.obj ~bars)
bar.hr.res<-coxph(formula = surv.obj.res ~bars.res )

se.bar.hr<-sqrt(bar.hr[[2]])
beta.bar.hr<-bar.hr[[1]]

up.lim.bar.hr<-exp(beta.bar.hr+(1.96*se.bar.hr))
low.lim.bar.hr<-exp(beta.bar.hr-(1.96*se.bar.hr))
hr.bar<-exp(beta.bar.hr)

se.bar.hr.res<-sqrt(bar.hr.res[[2]])
beta.bar.hr.res<-bar.hr.res[[1]]

up.lim.bar.hr.res<-exp(beta.bar.hr.res+(1.96*se.bar.hr.res))
low.lim.bar.hr.res<-exp(beta.bar.hr.res-(1.96*se.bar.hr.res))
hr.bar.res<-exp(beta.bar.hr.res)

cgi.hr<-coxph(formula = surv.obj ~cgi )
cgi.hr.res<-coxph(formula = surv.obj.res ~cgi.res )

se.cgi.hr<-sqrt(cgi.hr[[2]])
beta.cgi.hr<-cgi.hr[[1]]

up.lim.cgi.hr<-exp(beta.cgi.hr+(1.96*se.cgi.hr))
low.lim.cgi.hr<-exp(beta.cgi.hr-(1.96*se.cgi.hr))
hr.cgi<-exp(beta.cgi.hr)

se.cgi.hr.res<-sqrt(cgi.hr.res[[2]])
beta.cgi.hr.res<-cgi.hr.res[[1]]

up.lim.cgi.hr.res<-exp(beta.cgi.hr.res+(1.96*se.cgi.hr.res))
low.lim.cgi.hr.res<-exp(beta.cgi.hr.res-(1.96*se.cgi.hr.res))
hr.cgi.res<-exp(beta.cgi.hr.res)

dia.hr<-coxph(formula = surv.obj ~age.diag )
dia.hr.res<-coxph(formula = surv.obj.res ~age.diag.res )

se.dia.hr<-sqrt(dia.hr[[2]])
beta.dia.hr<-dia.hr[[1]]

up.lim.dia.hr<-exp(beta.dia.hr+(1.96*se.dia.hr))
low.lim.dia.hr<-exp(beta.dia.hr-(1.96*se.dia.hr))
hr.dia<-exp(beta.dia.hr)

se.dia.hr.res<-sqrt(dia.hr.res[[2]])
beta.dia.hr.res<-dia.hr.res[[1]]

up.lim.dia.hr.res<-exp(beta.dia.hr.res+(1.96*se.dia.hr.res))
low.lim.dia.hr.res<-exp(beta.dia.hr.res-(1.96*se.dia.hr.res))
hr.dia.res<-exp(beta.dia.hr.res)

doi.hr<-coxph(formula = surv.obj ~doi)
doi.hr.res<-coxph(formula = surv.obj.res ~doi.res)

se.doi.hr<-sqrt(doi.hr[[2]])
beta.doi.hr<-doi.hr[[1]]

up.lim.doi.hr<-exp(beta.doi.hr+(1.96*se.doi.hr))
low.lim.doi.hr<-exp(beta.doi.hr-(1.96*se.doi.hr))
hr.doi<-exp(beta.doi.hr)

se.doi.hr.res<-sqrt(doi.hr.res[[2]])
beta.doi.hr.res<-doi.hr.res[[1]]

up.lim.doi.hr.res<-exp(beta.doi.hr.res+(1.96*se.doi.hr.res))
low.lim.doi.hr.res<-exp(beta.doi.hr.res-(1.96*se.doi.hr.res))
hr.doi.res<-exp(beta.doi.hr.res)

dru.hr<-coxph(formula = surv.obj ~drugs )
dru.hr.res<-coxph(formula = surv.obj.res ~drugs.res )

se.dru.hr<-sqrt(dru.hr[[2]])
beta.dru.hr<-dru.hr[[1]]

up.lim.dru.hr<-exp(beta.dru.hr+(1.96*se.dru.hr))
low.lim.dru.hr<-exp(beta.dru.hr-(1.96*se.dru.hr))
hr.dru<-exp(beta.dru.hr)

se.dru.hr.res<-sqrt(dru.hr.res[[2]])
beta.dru.hr.res<-dru.hr.res[[1]]

up.lim.dru.hr.res<-exp(beta.dru.hr.res+(1.96*se.dru.hr.res))
low.lim.dru.hr.res<-exp(beta.dru.hr.res-(1.96*se.dru.hr.res))
hr.dru.res<-exp(beta.dru.hr.res)

nic.hr<-coxph(formula = surv.obj ~nicotine )
nic.hr.res<-coxph(formula = surv.obj.res ~nicotine.res )

se.nic.hr<-sqrt(nic.hr[[2]])
beta.nic.hr<-nic.hr[[1]]

up.lim.nic.hr<-exp(beta.nic.hr+(1.96*se.nic.hr))
low.lim.nic.hr<-exp(beta.nic.hr-(1.96*se.nic.hr))
hr.nic<-exp(beta.nic.hr)

se.nic.hr.res<-sqrt(nic.hr.res[[2]])
beta.nic.hr.res<-nic.hr.res[[1]]

up.lim.nic.hr.res<-exp(beta.nic.hr.res+(1.96*se.nic.hr.res))
low.lim.nic.hr.res<-exp(beta.nic.hr.res-(1.96*se.nic.hr.res))
hr.nic.res<-exp(beta.nic.hr.res)

bpr.hr<-coxph(formula = surv.obj ~bprs )
bpr.hr.res<-coxph(formula = surv.obj.res ~bprs.res) 

se.bpr.hr<-sqrt(bpr.hr[[2]])
beta.bpr.hr<-bpr.hr[[1]]

up.lim.bpr.hr<-exp(beta.bpr.hr+(1.96*se.bpr.hr))
low.lim.bpr.hr<-exp(beta.bpr.hr-(1.96*se.bpr.hr))
hr.bpr<-exp(beta.bpr.hr)

se.bpr.hr.res<-sqrt(bpr.hr.res[[2]])
beta.bpr.hr.res<-bpr.hr.res[[1]]

up.lim.bpr.hr.res<-exp(beta.bpr.hr.res+(1.96*se.bpr.hr.res))
low.lim.bpr.hr.res<-exp(beta.bpr.hr.res-(1.96*se.bpr.hr.res))
hr.bpr.res<-exp(beta.bpr.hr.res)


pre.hr<-coxph(formula = surv.obj ~prev.hosp) 
pre.hr.res<-coxph(formula = surv.obj.res ~prev.hosp.res) 

se.pre.hr<-sqrt(pre.hr[[2]])
beta.pre.hr<-pre.hr[[1]]

up.lim.pre.hr<-exp(beta.pre.hr+(1.96*se.pre.hr))
low.lim.pre.hr<-exp(beta.pre.hr-(1.96*se.pre.hr))
hr.pre<-exp(beta.pre.hr)

se.pre.hr.res<-sqrt(pre.hr.res[[2]])
beta.pre.hr.res<-pre.hr.res[[1]]

up.lim.pre.hr.res<-exp(beta.pre.hr.res+(1.96*se.pre.hr.res))
low.lim.pre.hr.res<-exp(beta.pre.hr.res-(1.96*se.pre.hr.res))
hr.pre.res<-exp(beta.pre.hr.res)


hos.hr<-coxph(formula = surv.obj ~n.hosp) 
hos.hr.res<-coxph(formula = surv.obj.res ~n.hosp.res) 

se.hos.hr<-sqrt(hos.hr[[2]])
beta.hos.hr<-hos.hr[[1]]

up.lim.hos.hr<-exp(beta.hos.hr+(1.96*se.hos.hr))
low.lim.hos.hr<-exp(beta.hos.hr-(1.96*se.hos.hr))
hr.hos<-exp(beta.hos.hr)

se.hos.hr.res<-sqrt(hos.hr.res[[2]])
beta.hos.hr.res<-hos.hr.res[[1]]

up.lim.hos.hr.res<-exp(beta.hos.hr.res+(1.96*se.hos.hr.res))
low.lim.hos.hr.res<-exp(beta.hos.hr.res-(1.96*se.hos.hr.res))
hr.hos.res<-exp(beta.hos.hr.res)


fun.hr<-coxph(formula = surv.obj ~functioning) 
fun.hr.res<-coxph(formula = surv.obj.res ~functioning.res) 

se.fun.hr<-sqrt(fun.hr[[2]])
beta.fun.hr<-fun.hr[[1]]

up.lim.fun.hr<-exp(beta.fun.hr+(1.96*se.fun.hr))
low.lim.fun.hr<-exp(beta.fun.hr-(1.96*se.fun.hr))
hr.fun<-exp(beta.fun.hr)

se.fun.hr.res<-sqrt(fun.hr.res[[2]])
beta.fun.hr.res<-fun.hr.res[[1]]

up.lim.fun.hr.res<-exp(beta.fun.hr.res+(1.96*se.fun.hr.res))
low.lim.fun.hr.res<-exp(beta.fun.hr.res-(1.96*se.fun.hr.res))
hr.fun.res<-exp(beta.fun.hr.res)


eps.hr<-coxph(formula = surv.obj ~eps) 
eps.hr.res<-coxph(formula = surv.obj.res ~eps.res) 

se.eps.hr<-sqrt(eps.hr[[2]])
beta.eps.hr<-eps.hr[[1]]

up.lim.eps.hr<-exp(beta.eps.hr+(1.96*se.eps.hr))
low.lim.eps.hr<-exp(beta.eps.hr-(1.96*se.eps.hr))
hr.eps<-exp(beta.eps.hr)

se.eps.hr.res<-sqrt(eps.hr.res[[2]])
beta.eps.hr.res<-eps.hr.res[[1]]

up.lim.eps.hr.res<-exp(beta.eps.hr.res+(1.96*se.eps.hr.res))
low.lim.eps.hr.res<-exp(beta.eps.hr.res-(1.96*se.eps.hr.res))
hr.eps.res<-exp(beta.eps.hr.res)

#####SUMMARY TABLES # 

colname.desc.cont<- c("Age (mean)", "Age (SD)", "BMI (mean)", "BMI (SD)","Age at diagnosis (mean)","Age at diagnosis (SD)","Duration of illness (mean)","Duration of illness (SD)", "CGI (mean)","CGI (SD)","Psychopathology total score (mean)","Psychopathology total score (SD)", "Psychopathology general score (mean)","Psychopathology general score (SD)","Psychopathology positive score (mean)","Psychopathology positive score (SD)","Psychopathology negative score (mean)","Psychopathology negative score (SD)","General functioning score (mean)","General functioning score (SD)", "Quality of life score (mean)","Quality of life score (SD)")


mean.age<-mean(age, na.rm=T)
sd.age<-sd(age,na.rm=T)
mean.BMI<-mean(BMI,na.rm=T)
sd.BMI<-sd(BMI,na.rm=T)
mean.agediagnosis<-mean(age.diag, na.rm=T)
sd.agediagnsosis<-sd(age.diag,na.rm=T)
mean.doi<-mean(doi,na.rm=T)
sd.doi<-sd(doi,na.rm=T)
mean.cgi<-mean(cgi,na.rm=T)
sd.cgi<-sd(cgi,na.rm=T)
mean.totps<-mean(bprs,na.rm=T)
sd.totps<-sd(bprs, na.rm=T)
mean.genps<- NA
sd.genps<-NA
mean.posps<-NA
sd.posps<-NA
mean.negps<-NA
sd.negps<-NA
mean.func<-mean(functioning,na.rm=T)
sd.functioning<-sd(functioning, na.rm=T)
mean.qol<-NA
sd.qol<-NA

desc.cont<-c(mean.age,sd.age,mean.BMI,sd.BMI,mean.agediagnosis,sd.agediagnsosis,mean.doi,sd.doi,mean.cgi,sd.cgi,mean.totps,sd.totps,mean.genps,sd.genps,mean.posps,sd.posps,mean.negps,sd.negps,mean.func,sd.functioning,mean.qol,sd.qol)

desc.cont.mat<-rbind(colname.desc.cont,desc.cont)

mean.age.res<-mean(age.res, na.rm=T)
sd.age.res<-sd(age.res,na.rm=T)
mean.BMI.res<-mean(BMI.res,na.rm=T)
sd.BMI.res<-sd(BMI.res,na.rm=T)
mean.agediagnosis.res<-mean(age.diag.res, na.rm=T)
sd.agediagnsosis.res<-sd(age.diag.res,na.rm=T)
mean.doi.res<-mean(doi.res,na.rm=T)
sd.doi.res<-sd(doi.res,na.rm=T)
mean.cgi.res<-mean(cgi,na.rm=T)
sd.cgi.res<-sd(cgi,na.rm=T)
mean.totps.res<-mean(bprs,na.rm=T)
sd.totps.res<-sd(bprs, na.rm=T)
mean.genps.res<- NA
sd.genps.res<-NA
mean.posps.res<-NA
sd.posps.res<-NA
mean.negps.res<-NA
sd.negps.res<-NA
mean.func.res<-mean(functioning.res,na.rm=T)
sd.func.res<-sd(functioning.res, na.rm=T)
mean.qol.res<-NA
sd.qol.res<-NA

desc.cont.res<-c(mean.age.res,sd.age.res,mean.BMI.res,sd.BMI.res,mean.agediagnosis.res,sd.agediagnsosis.res,mean.doi.res,sd.doi.res,mean.cgi.res,sd.cgi.res,mean.totps.res,sd.totps.res,mean.genps.res,sd.genps.res,mean.posps.res,sd.posps.res,mean.negps.res,sd.negps.res,mean.func.res,sd.func.res,mean.qol.res,sd.qol.res)

desc.cont.mat.res<-rbind(colname.desc.cont,desc.cont.res)

mean.age.no.res<-mean(age.no.res, na.rm=T)
sd.age.no.res<-sd(age.no.res,na.rm=T)
mean.BMI.no.res<-mean(BMI.no.res,na.rm=T)
sd.BMI.no.res<-sd(BMI.no.res,na.rm=T)
mean.agediagnosis.no.res<-mean(age.diag.no.res, na.rm=T)
sd.agediagnsosis.no.res<-sd(age.diag.no.res,na.rm=T)
mean.doi.no.res<-mean(doi.no.res,na.rm=T)
sd.doi.no.res<-sd(doi.no.res,na.rm=T)
mean.cgi.no.res<-mean(cgi,na.rm=T)
sd.cgi.no.res<-sd(cgi,na.rm=T)
mean.totps.no.res<-mean(bprs,na.rm=T)
sd.totps.no.res<-sd(bprs, na.rm=T)
mean.genps.no.res<- NA
sd.genps.no.res<-NA
mean.posps.no.res<-NA
sd.posps.no.res<-NA
mean.negps.no.res<-NA
sd.negps.no.res<-NA
mean.func.no.res<-mean(functioning.no.res,na.rm=T)
sd.func.no.res<-sd(functioning.no.res, na.rm=T)
mean.qol.no.res<-NA
sd.qol.no.res<-NA

desc.cont.no.res<-c(mean.age.no.res,sd.age.no.res,mean.BMI.no.res,sd.BMI.no.res,mean.agediagnosis.no.res,sd.agediagnsosis.no.res,mean.doi.no.res,sd.doi.no.res,mean.cgi.no.res,sd.cgi.no.res,mean.totps.no.res,sd.totps.no.res,mean.genps.no.res,sd.genps.no.res,mean.posps.no.res,sd.posps.no.res,mean.negps.no.res,sd.negps.no.res,mean.func.no.res,sd.func.no.res,mean.qol.no.res,sd.qol.no.res)

desc.cont.mat.no.res<-rbind(colname.desc.cont,desc.cont.no.res)


colname.desc.cat<- c("Male (n)","Male (%)", "US (n)", "US (%)", "Family history (n)", "Family history (%)", "Smoking (n)", "Smoking (%)", "Drug use (n)", "Drug use (%)","Days since last hospitalization (n)","Days since last hospitalization (%)", "Number of previous hospitalizations (n)","Number of previous hospitalizations (%)", "Tardive dyskinesia score (n)","Tardive dyskinesia score (%)","Akathisia score (n)","Akathisia score (%)", "Parkinsonism score (n)","Parkinsonism score (%)")

n.male<- length(sex[sex==1])
perc.male<-length(sex[sex==1])/length(sex)*100
n.us<- length(total.ids)
perc.us<-100
n.fhx<- NA
perc.fhx<-NA
n.smok<- length(nicotine[nicotine==1])
perc.smok<-length(nicotine[nicotine==1])/length(nicotine)*100
n.drug<- length(drugs[drugs==1])
perc.drug<-length(drugs[drugs==1])/length(drugs)*100
n.hosp.n<- length(n.hosp[n.hosp==1])
perc.hosp.n<-length(n.hosp[n.hosp==1])/length(n.hosp)*100
n.hosp.d<-length(prev.hosp[prev.hosp==1])
perc.hosp.d<-length(prev.hosp[prev.hosp==1])/length(prev.hosp)*100
n.aims<- length(aims[aims==1])
perc.aims<-length(aims[aims==1])/length(aims)*100
n.bars<- length(bars[bars==1])
perc.bars<-length(bars[bars==1])/length(bars)*100
n.eps<- length(eps[eps==1])
perc.eps<-length(eps[eps==1])/length(eps)*100

desc.cat<-c(n.male,perc.male,n.us,perc.us,n.fhx,perc.fhx,n.smok,perc.smok,n.drug,perc.drug,n.hosp.n,perc.hosp.n,n.hosp.d,perc.hosp.d,n.aims,perc.aims,n.bars,perc.bars,n.eps,perc.eps)

desc.cat.mat<-rbind(colname.desc.cat,desc.cat)

n.male.res<- length(sex.res[sex.res==1])
perc.male.res<-length(sex.res[sex.res==1])/length(sex.res)*100
n.us.res<- length(response.ids)
perc.us.res<-100
n.fhx.res<- NA
perc.fhx.res<-NA
n.smok.res<- length(nicotine.res[nicotine.res==1])
perc.smok.res<-length(nicotine.res[nicotine.res==1])/length(nicotine.res)*100
n.drug.res<- length(drugs.res[drugs.res==1])
perc.drug.res<-length(drugs.res[drugs.res==1])/length(drugs.res)*100
n.hosp.n.res<- length(n.hosp.res[n.hosp.res==1])
perc.hosp.n.res<-length(n.hosp.res[n.hosp.res==1])/length(n.hosp.res)*100
n.hosp.d.res<-length(prev.hosp.res[prev.hosp.res==1])
perc.hosp.d.res<-length(prev.hosp.res[prev.hosp.res==1])/length(prev.hosp.res)*100
n.aims.res<- length(aims.res[aims.res==1])
perc.aims.res<-length(aims.res[aims.res==1])/length(aims.res)*100
n.bars.res<- length(bars.res[bars.res==1])
perc.bars.res<-length(bars.res[bars.res==1])/length(bars.res)*100
n.eps.res<- length(eps.res[eps.res==1])
perc.eps.res<-length(eps.res[eps.res==1])/length(eps.res)*100

desc.cat.res<-c(n.male.res,perc.male.res,n.us.res,perc.us.res,n.fhx.res,perc.fhx.res,n.smok.res,perc.smok.res,n.drug.res,perc.drug.res,n.hosp.n.res,perc.hosp.n.res,n.hosp.d.res,perc.hosp.d.res,n.aims.res,perc.aims.res,n.bars.res,perc.bars.res,n.eps.res,perc.eps.res)

desc.cat.mat.res<-rbind(colname.desc.cat,desc.cat.res)


n.male.no.res<- length(sex.no.res[sex.no.res==1])
perc.male.no.res<-length(sex.no.res[sex.no.res==1])/length(sex.no.res)*100
n.us.no.res<- length(no.response.ids)
perc.us.no.res<-100
n.fhx.no.res<- NA
perc.fhx.no.res<-NA
n.smok.no.res<- length(nicotine.no.res[nicotine.no.res==1])
perc.smok.no.res<-length(nicotine.no.res[nicotine.no.res==1])/length(nicotine.no.res)*100
n.drug.no.res<- length(drugs.no.res[drugs.no.res==1])
perc.drug.no.res<-length(drugs.no.res[drugs.no.res==1])/length(drugs.no.res)*100
n.hosp.n.no.res<- length(n.hosp.no.res[n.hosp.no.res==1])
perc.hosp.n.no.res<-length(n.hosp.no.res[n.hosp.no.res==1])/length(n.hosp.no.res)*100
n.hosp.d.no.res<-length(prev.hosp.no.res[prev.hosp.no.res==1])
perc.hosp.d.no.res<-length(prev.hosp.no.res[prev.hosp.no.res==1])/length(prev.hosp.no.res)*100
n.aims.no.res<- length(aims.no.res[aims.no.res==1])
perc.aims.no.res<-length(aims.no.res[aims.no.res==1])/length(aims.no.res)*100
n.bars.no.res<- length(bars.no.res[bars.no.res==1])
perc.bars.no.res<-length(bars.no.res[bars.no.res==1])/length(bars.no.res)*100
n.eps.no.res<- length(eps.no.res[eps.no.res==1])
perc.eps.no.res<-length(eps.no.res[eps.no.res==1])/length(eps.no.res)*100

desc.cat.no.res<-c(n.male.no.res,perc.male.no.res,n.us.no.res,perc.us.no.res,n.fhx.no.res,perc.fhx.no.res,n.smok.no.res,perc.smok.no.res,n.drug.no.res,perc.drug.no.res,n.hosp.n.no.res,perc.hosp.n.no.res,n.hosp.d.no.res,perc.hosp.d.no.res,n.aims.no.res,perc.aims.no.res,n.bars.no.res,perc.bars.no.res,n.eps.no.res,perc.eps.no.res)

desc.cat.mat.no.res<-rbind(colname.desc.cat,desc.cat.no.res)


colname.outc<-c("Total sample 'n'", "Relapse 'n'", "Relapse '%'", "Median time to relapse 'days'", "Events per 100 patient - years")

n.total<-length(total.ids)
n.relapse<-length(status[status==1])
perc.relapse<-length(status[status==1])/length(status)*100
median.time<-median(time.to.event, na.rm=T)
py.inc

outc<-c(n.total,n.relapse,perc.relapse,median.time,py.inc)

outc.mat<-rbind(colname.outc,outc)

n.total.res<-length(response.ids)
n.relapse.res<-length(status.res[status.res==1])
perc.relapse.res<-length(status.res[status.res==1])/length(status.res)*100
median.time.res<-median(time.to.event.res, na.rm=T)
py.inc.res

outc.res<-c(n.total.res,n.relapse.res,perc.relapse.res,median.time.res,py.inc.res)

outc.mat.res<-rbind(colname.outc,outc.res)


n.total.no.res<-length(no.response.ids)
n.relapse.no.res<-length(status.no.res[status.no.res==1])
perc.relapse.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100
median.time.no.res<-median(time.to.event.no.res, na.rm=T)
py.inc.no.res

outc.no.res<-c(n.total.no.res,n.relapse.no.res,perc.relapse.no.res,median.time.no.res,py.inc.no.res)

outc.mat.no.res<-rbind(colname.outc,outc.no.res)


colname.HR<-c("Male gender HR","Male gender Lower 95% CI","Male gender Upper 95% CI","Age HR", "Age Lower 95% CI","Age	Upper 95% CI","Proportion US HR",	"Proportion US Lower 95% CI","Proportion US Upper 95% CI","BMI HR",  "BMI Lower 95% CI","BMI Upper 95% CI", "Age at diagnosis HR","Age at diagnosis Lower 95% CI","Age at diagnosis Upper 95% CI","Duration of illness HR","Duration of illness Lower 95% CI","Duration of illness Upper 95% CI","Time since last hospitalization HR","Time since last hospitalization Lower 95% CI","Time since last hospitalization Upper 95% CI","Number of previous hospitalizations HR","Number of previous hospitalizations Lower 95% CI","Number of previous hospitalizations Upper 95% CI","Family history HR","Family history Lower 95% CI","Family history Upper 95% CI","Smoking HR","Smoking Lower 95% CI","Smoking Upper 95% CI","Drug use HR","Drug use Lower 95% CI","Drug use Upper 95% CI","CGI HR","CGI Lower 95% CI","CGI Upper 95% CI","Psychopathology total score HR","Psychopathology total score Lower 95% CI","Psychopathology total score Upper 95% CI","Psychopathology general score HR","Psychopathology general score Lower 95% CI","Psychopathology general score Upper 95% CI","Psychopathology positive score HR","Psychopathology positive score Lower 95% CI","Psychopathology positive score Upper 95% CI","Psychopathology negative score HR","Psychopathology negative score Lower 95% CI","Psychopathology negative score Upper 95% CI","General functioning score HR",  "General functioning score Lower 95% CI","General functioning score Upper 95% CI", "Quality of life score HR",  "Quality of life score Lower 95% CI","Quality of life score Upper 95% CI","Tardive dyskinesia score HR","Tardive dyskinesia score Lower 95% CI","Tardive dyskinesia score Upper 95% CI","Akathisia score HR","Akathisia score Lower 95% CI","Akathisia score Upper 95% CI","Parkinsonism score HR","Parkinsonism score Lower 95% CI","Parkinsonism score Upper 95% CI")

hr<- cbind(hr.sex,low.lim.sex.hr,up.lim.sex.hr,hr.age,low.lim.age.hr,up.lim.age.hr,NA,NA,NA,hr.bmi,low.lim.bmi.hr,up.lim.bmi.hr,hr.dia,low.lim.dia.hr,up.lim.dia.hr,hr.doi,low.lim.doi.hr,up.lim.doi.hr,NA,NA,NA,hr.pre,low.lim.pre.hr,up.lim.pre.hr,NA,NA,NA,hr.nic,low.lim.nic.hr,up.lim.nic.hr,hr.dru,low.lim.dru.hr,up.lim.dru.hr,hr.cgi,low.lim.cgi.hr,up.lim.cgi.hr,hr.bpr,low.lim.bpr.hr,up.lim.bpr.hr,NA,NA,NA,NA,NA,NA,NA,NA,NA,hr.fun,low.lim.fun.hr,up.lim.fun.hr,NA,NA,NA,hr.aim,low.lim.aim.hr,up.lim.aim.hr,hr.bar,low.lim.bar.hr,up.lim.bar.hr,hr.eps,low.lim.eps.hr,up.lim.eps.hr)

hr.mat<-rbind(colname.HR,hr)

hr.res<- cbind(hr.sex.res,low.lim.sex.hr.res,up.lim.sex.hr.res,hr.age.res,low.lim.age.hr.res,up.lim.age.hr.res,NA,NA,NA,hr.bmi.res,low.lim.bmi.hr.res,up.lim.bmi.hr.res,hr.dia.res,low.lim.dia.hr.res,up.lim.dia.hr.res,hr.doi.res,low.lim.doi.hr.res,up.lim.doi.hr.res,NA,NA,NA,hr.pre.res,low.lim.pre.hr.res,up.lim.pre.hr.res,NA,NA,NA,hr.nic.res,low.lim.nic.hr.res,up.lim.nic.hr.res,hr.dru.res,low.lim.dru.hr.res,up.lim.dru.hr.res,hr.cgi.res,low.lim.cgi.hr.res,up.lim.cgi.hr.res,hr.bpr.res,low.lim.bpr.hr.res,up.lim.bpr.hr.res,NA,NA,NA,NA,NA,NA,NA,NA,NA,hr.fun.res,low.lim.fun.hr.res,up.lim.fun.hr.res,NA,NA,NA,hr.aim.res,low.lim.aim.hr.res,up.lim.aim.hr.res,hr.bar.res,low.lim.bar.hr.res,up.lim.bar.hr.res,hr.eps.res,low.lim.eps.hr.res,up.lim.eps.hr.res)

hr.mat.res<-rbind(colname.HR,hr.res)


hr.int<-cbind(
  ci.int.sex[1],ci.int.sex[2],ci.int.sex[3],
  ci.int.age[1],ci.int.age[2],ci.int.age[3],
  NA,NA,NA,
  ci.int.BMI[1],ci.int.BMI[2],ci.int.BMI[3],
  ci.int.agediag[1],ci.int.agediag[2],ci.int.agediag[3],
  ci.int.doi[1],ci.int.doi[2],ci.int.doi[3],
  NA,NA,NA,
  ci.int.prev.hosp[1],ci.int.prev.hosp[2],ci.int.prev.hosp[3],
  NA,NA,NA,
  ci.int.nicotine[1],ci.int.nicotine[2],ci.int.nicotine[3],
  ci.int.drugs[1],ci.int.drugs[2],ci.int.drugs[3],
  ci.int.cgi[1],ci.int.cgi[2],ci.int.cgi[3],
  ci.int.bprs[1],ci.int.bprs[2],ci.int.bprs[3],
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  ci.int.functioning[1],ci.int.functioning[2],ci.int.functioning[3],
  NA,NA,NA,
  ci.int.aims[1],ci.int.aims[2],ci.int.aims[3],
  ci.int.bars[1],ci.int.bars[2],ci.int.bars[3],
  ci.int.eps[1],ci.int.eps[2],ci.int.eps[3])

hr.mat.int<-rbind(colname.HR,hr.int)

hr.int.seiyi<-cbind(
  sei.int.sex[1],sei.int.sex[2],
  sei.int.age[1],sei.int.age[2],
  NA,NA,
  sei.int.BMI[1],sei.int.BMI[2],
  sei.int.agediag[1],sei.int.agediag[2],
  sei.int.doi[1],sei.int.doi[2],
  NA,NA,
  sei.int.prev.hosp[1],sei.int.prev.hosp[2],
  NA,NA,
  sei.int.nicotine[1],sei.int.nicotine[2],
  sei.int.drugs[1],sei.int.drugs[2],
  sei.int.cgi[1],sei.int.cgi[2],
  sei.int.bprs[1],sei.int.bprs[2],
  NA,NA,
  NA,NA,
  NA,NA,
  sei.int.functioning[1],sei.int.functioning[2],
  NA,NA,
  sei.int.aims[1],sei.int.aims[2],
  sei.int.bars[1],sei.int.bars[2],
  sei.int.eps[1],sei.int.eps[2])

hr.nores.seiyi<-cbind(
  sei.sex[1],sei.sex[2],
  sei.age[1],sei.age[2],
  NA,NA,
  sei.BMI[1],sei.BMI[2],
  sei.agediag[1],sei.agediag[2],
  sei.doi[1],sei.doi[2],
  NA,NA,
  sei.prev.hosp[1],sei.prev.hosp[2],
  NA,NA,
  sei.nicotine[1],sei.nicotine[2],
  sei.drugs[1],sei.drugs[2],
  sei.cgi[1],sei.cgi[2],
  sei.bprs[1],sei.bprs[2],
  NA,NA,
  NA,NA,
  NA,NA,
  sei.functioning[1],sei.functioning[2],
  NA,NA,
  sei.aims[1],sei.aims[2],
  sei.bars[1],sei.bars[2],
  sei.eps[1],sei.eps[2])


xx<-study1.surv.fit
xx.res<-study1.surv.fit.res
xx.no.res<-study1.surv.fit.no.res

xx.t<-xx[[2]]/7
xx.p<-xx[[6]]

xx.t.res<-xx.res[[2]]/7
xx.p.res<-xx.res[[6]]

xx.t.no.res<-xx.no.res[[2]]/7
xx.p.no.res<-xx.no.res[[6]]

surv.mat<-cbind(xx.t,xx.p)  
surv.mat.res<-cbind(xx.t.res,xx.p.res)  
surv.mat.no.res<-cbind(xx.t.no.res,xx.p.no.res) 

write.table(surv.mat,file="/Users/joserubio/PROACTIVE_results/surv_mat_proactive_wk_v2.csv",sep=",")


write.table(surv.mat,file="/Users/joserubio/PROACTIVE_results/surv_mat_proactive_wk_v2.csv",sep=",")
write.table(surv.mat.res,file="/Users/joserubio/PROACTIVE_results/surv_mat.res_proactive_wk_v2.csv",sep=",")
write.table(surv.mat.no.res,file="/Users/joserubio/PROACTIVE_results/surv_mat.no.res_proactive_wk_v2.csv",sep=",")

write.table(desc.cont.mat,file="/Users/joserubio/PROACTIVE_results/desc_cont_proactive_v2.csv",sep=",")
write.table(desc.cont.mat.res,file="/Users/joserubio/PROACTIVE_results/desc_cont_res_proactive_v2.csv",sep=",")
write.table(desc.cont.mat.no.res,file="/Users/joserubio/PROACTIVE_results/desc_cont_no.res_proactive_v2.csv",sep=",")

write.table(desc.cat.mat,file="/Users/joserubio/PROACTIVE_results/desc_cat_proactive_v2.csv",sep=",")
write.table(desc.cat.mat.res,file="/Users/joserubio/PROACTIVE_results/desc_cat.res_proactive_v2.csv",sep=",")
write.table(desc.cat.mat.no.res,file="/Users/joserubio/PROACTIVE_results/desc_cat.no.res_proactive_v2.csv",sep=",")

write.table(outc.mat,file="/Users/joserubio/PROACTIVE_results/outc_proactive_v2.csv",sep=",")
write.table(outc.mat.res,file="/Users/joserubio/PROACTIVE_results/outc.res_proactive_v2.csv",sep=",")
write.table(outc.mat.no.res,file="/Users/joserubio/PROACTIVE_results/outc.no.res_proactive_v2.csv",sep=",")

write.table(hr.mat,file="/Users/joserubio/PROACTIVE_results/hr_proactive_v2.csv",sep=",")
write.table(hr.mat.res,file="/Users/joserubio/PROACTIVE_results/hr.res_proactive_v2.csv",sep=",")


write.table(hr.mat.int,file="/Users/joserubio/PROACTIVE_results/hr.int_proactive_v2.csv",sep=",")

write.table(hr.int.seiyi,file="/Users/joserubio/PROACTIVE_results/hr.int.seiyi_proactive_v2.csv",sep=",")
write.table(hr.nores.seiyi,file="/Users/joserubio/PROACTIVE_results/hr.nores.seiyi_proactive_v2.csv",sep=",")

#code to calculate the relapse criteria met
# crtieria not specified in available data

#code to compare functioning between relapsers and non-relapsers
sof.dat<-sof.dat.t[-1,]
recur<-intersect(total.ids[status==1],sof.dat$subjectkey[visit>0])
norecur<-intersect(total.ids[status==0],sof.dat$subjectkey[visit>0])
visit<-as.numeric(as.character(sof.dat$visnum)) 
score<-as.numeric(as.character(sof.dat$sof_t))
subject<-as.character(sof.dat$subjectkey)

func.bl.rel<-array(,length(recur))
for(i in seq_along(recur)){
  func.bl.rel[i]<-functioning[total.ids==recur[i]]
}

func.bl.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
  func.bl.norel[i]<-functioning[total.ids==norecur[i]]
}

func.end.rel<-array(,length(recur))
for(i in seq_along(recur)){
  temp.visit<-visit[subject==recur[i]]
  max.temp.visit<-max(temp.visit,rm.na=T)
  func.end.rel[i]<-score[visit==max.temp.visit & subject==recur[i]]}

func.end.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
  temp.visit<-visit[subject==norecur[i]]
  max.temp.visit<-max(temp.visit,rm.na=T)
  func.end.norel[i]<-score[visit==max.temp.visit & subject==norecur[i]]}


delta.func.rel<-func.end.rel-func.bl.rel
delta.func.norel<-func.end.norel - func.bl.norel

t.test(delta.func.rel,delta.func.norel)

mean(delta.func.rel,na.rm=T)
sd(delta.func.rel,na.rm=T)
mean(delta.func.norel,na.rm=T)
sd(delta.func.norel,na.rm=T)

##PSR
sof.dat<-sof.dat.t[-1,]
recur<-intersect(response.ids[status.res==1],sof.dat$subjectkey[visit>0])
norecur<-intersect(response.ids[status.res==0],sof.dat$subjectkey[visit>0])
visit<-as.numeric(as.character(sof.dat$visnum))
score<-as.numeric(as.character(sof.dat$sof_t))
subject<-as.character(sof.dat$subjectkey)

func.bl.rel<-array(,length(recur))
for(i in seq_along(recur)){
    func.bl.rel[i]<-functioning[total.ids==recur[i]]
}

func.bl.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
    func.bl.norel[i]<-functioning[total.ids==norecur[i]]
}

func.end.rel<-array(,length(recur))
for(i in seq_along(recur)){
    temp.visit<-visit[subject==recur[i]]
    max.temp.visit<-max(temp.visit,rm.na=T)
    func.end.rel[i]<-score[visit==max.temp.visit & subject==recur[i]]}

func.end.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
    temp.visit<-visit[subject==norecur[i]]
    max.temp.visit<-max(temp.visit,rm.na=T)
    func.end.norel[i]<-score[visit==max.temp.visit & subject==norecur[i]]}


delta.func.rel<-func.end.rel-func.bl.rel
delta.func.norel<-func.end.norel - func.bl.norel

t.test(delta.func.rel,delta.func.norel)

mean(delta.func.rel,na.rm=T)
sd(delta.func.rel,na.rm=T)
mean(delta.func.norel,na.rm=T)
sd(delta.func.norel,na.rm=T)

##Non-PSR
sof.dat<-sof.dat.t[-1,]
recur<-intersect(no.response.ids[status.no.res==1],sof.dat$subjectkey[visit>0])
norecur<-intersect(no.response.ids[status.no.res==0],sof.dat$subjectkey[visit>0])
visit<-as.numeric(as.character(sof.dat$visnum))
score<-as.numeric(as.character(sof.dat$sof_t))
subject<-as.character(sof.dat$subjectkey)

func.bl.rel<-array(,length(recur))
for(i in seq_along(recur)){
    func.bl.rel[i]<-functioning[total.ids==recur[i]]
}

func.bl.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
    func.bl.norel[i]<-functioning[total.ids==norecur[i]]
}

func.end.rel<-array(,length(recur))
for(i in seq_along(recur)){
    temp.visit<-visit[subject==recur[i]]
    max.temp.visit<-max(temp.visit,rm.na=T)
    func.end.rel[i]<-score[visit==max.temp.visit & subject==recur[i]]}

func.end.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
    temp.visit<-visit[subject==norecur[i]]
    max.temp.visit<-max(temp.visit,rm.na=T)
    func.end.norel[i]<-score[visit==max.temp.visit & subject==norecur[i]]}


delta.func.rel<-func.end.rel-func.bl.rel
delta.func.norel<-func.end.norel - func.bl.norel

t.test(delta.func.rel,delta.func.norel)

mean(delta.func.rel,na.rm=T)
sd(delta.func.rel,na.rm=T)
mean(delta.func.norel,na.rm=T)
sd(delta.func.norel,na.rm=T)
