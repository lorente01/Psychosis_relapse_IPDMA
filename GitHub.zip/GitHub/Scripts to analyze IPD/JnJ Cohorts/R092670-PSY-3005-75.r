# Authored: Jose M Rubio M.D // jrubio13@northwell.edu
# Checked: George Schoretsanitis M.D.,PhD
# April 7th 2020

###COHORT JnJ-R092670-PSY-3005-75
#################################
### a function to match and merge variables from two datasets

match.and.merge.func <- function(dat1.id, dat2.id, dat2.var){
  dat1.var <- array(,length(dat1.id)) 
  for(i in 1:length(dat1.id)){
    for(j in 1:length(dat2.id)){
      if(dat1.id[i] == dat2.id[j]){ dat1.var[i] <- dat2.var[j] }}}
  return(dat1.var)                                       }

##########IDENTIFY TOTAL DATASET
#ALLOCATED TO PP 75 

random.dat <- read.table("X:/Data/JnJ-R092670-PSY-3005-csv/Data/random.csv", header = TRUE, sep = ",")
dose.char <- as.character(random.dat$RADOSE)
ids.50 <- random.dat$DSUBJID[dose.char== "75 MG"]
ids.50.u <- unique(ids.50)

#FOLLOWED FOR SUFFICIENT TIME TO HAVE A THERAPEUTIC PLASMA LEVEL (>1 WEEK FOR PP)

visit.dat <- read.table("X:/Data/JnJ-R092670-PSY-3005-csv/Data/visit.csv", header = TRUE, sep = ",")
visit.dat.id.u <- unique(visit.dat$DSUBJID) 

exclude.ind <- array(0, length(visit.dat.id.u)) 

for(i in 1:length(visit.dat.id.u)){
  visitdy.temp <- visit.dat$VISITDY[visit.dat$DSUBJID == visit.dat.id.u[i]]        
  visitdy.temp.max <- max(visitdy.temp, na.rm = T)
  if(visitdy.temp.max <= 8){ exclude.ind[i] <- 1 } }

leadin.ids<-visit.dat.id.u[exclude.ind==0]

total.ids<-intersect(ids.50.u,leadin.ids)

##########IDENTIFY 'REMISSION' DATASET 
##IF PTS STABLE UPON ENTRY  XXX --> FIRST 2 VISITS WITH LESS THAN MILD ON POSITIVE SYMPTOMS) [THESE WILL BE LABELLED AS .RES, ALTHOUGH IN FACT ARE REMITTERS]
##IF PTS NOT STABLE UPON ENTRY --> FIRST 2 VISITS AFTER WEEK 6 WITH LESS THAN MILD ON POSITIVE SYMPTOMS) [THESE WILL BE LABELLED AS .RES, ALTHOUGH IN FACT ARE REMITTERS]

panss.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/panss.csv", header = TRUE, sep = ",")


panss.dat.res5 <- panss.dat[panss.dat$VISITNUM==3,]
panss.grp.char <- as.character(panss.dat.res5$PAGROUP)
panss.dat.res5 <- panss.dat.res5[panss.grp.char=="010 POSITIVE SUBSCALE",]
panss.id.u.rs5<-unique(panss.dat.res5$DSUBJID)

panss.res.id5<-array(0,length(panss.id.u.rs5))

for(i in 1:length(panss.id.u.rs5)){
  temp.array1<-panss.dat.res5$PASCOREC[panss.dat.res5$DSUBJID==panss.id.u.rs5[i]]
  max.sc.rs<-max(temp.array1, na.rm=TRUE)
  if(max.sc.rs<4){panss.res.id5[i]<-1}
}

response.ids5<-panss.id.u.rs5[panss.res.id5==1]

panss.dat.res9 <- panss.dat[panss.dat$VISITNUM==5,]
panss.grp.char <- as.character(panss.dat.res9$PAGROUP)
panss.dat.res9 <- panss.dat.res9[panss.grp.char=="010 POSITIVE SUBSCALE",]
panss.id.u.rs9<-unique(panss.dat.res9$DSUBJID)

panss.res.id9<-array(0,length(panss.id.u.rs9))

for(i in 1:length(panss.id.u.rs9)){
  temp.array1<-panss.dat.res9$PASCOREC[panss.dat.res9$DSUBJID==panss.id.u.rs9[i]]
  temp.array1[is.na(temp.array1)]<-4
  max.sc.rs<-max(temp.array1, na.rm=TRUE)
  if(max.sc.rs<4){panss.res.id9[i]<-1}
}

response.ids9<-panss.id.u.rs9[panss.res.id9==1]

response.ids.temp<-intersect(response.ids5,response.ids9)
response.ids<-intersect(response.ids.temp,total.ids)# ok

no.response.ids<-setdiff(total.ids,response.ids)

########DEFINE STATUS PER DATASET (1=event; 0=censor)
#these are all individuals for each dataset for whom there was a withdrawal for "LACK OF EFFICACY" ==98

disposit.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/disposit.csv", header = TRUE, sep = ",")

reason<-disposit.dat$DSREASC
disposit.ids.u<-unique(disposit.dat$DSUBJID)

status.tot<-array(0,length(disposit.ids.u))

for(i in 1:length(disposit.ids.u)){
  temp.reason<-reason[disposit.dat$DSUBJID==disposit.ids.u[i]]
  temp.reason[is.na(temp.reason)]<-0
  if(temp.reason==98){status.tot[i]<-1}
}

#now status per dataset

status<-array(0,length(total.ids))
for(i in 1:length(total.ids)){
  for (j in 1:length(disposit.ids.u)){
    if(total.ids[i]==disposit.ids.u[j]){status[i]<-status.tot[j]}}}

status.res<-array(0,length(response.ids))
for(i in 1:length(response.ids)){
  for (j in 1:length(disposit.ids.u)){
    if(response.ids[i]==disposit.ids.u[j]){status.res[i]<-status.tot[j]}}}# OK

status.no.res<-array(0,length(no.response.ids))
for(i in 1:length(no.response.ids)){
  for (j in 1:length(disposit.ids.u)){
    if(no.response.ids[i]==disposit.ids.u[j]){status.no.res[i]<-status.tot[j]}}}# OK

######DEFINE TIME TO EVENT PER DATASET 

disposit.dat <- read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/disposit.csv", header = TRUE, sep = ",")
disposit.ids.u<-unique(disposit.dat$DSUBJID)
time.to.all<-disposit.dat$DSACTDY

time.to.event<-match.and.merge.func(total.ids,disposit.ids.u,time.to.all)
time.to.event.res<-match.and.merge.func(response.ids,disposit.ids.u,time.to.all)#6/17 OK
time.to.event.no.res<-match.and.merge.func(no.response.ids,disposit.ids.u,time.to.all)#6/17 OK

rem.stat<-array(0,length(total.ids))
for(i in 1:length(total.ids)){
  for(j in 1:length(response.ids)){
    if(total.ids[i]==response.ids[j]){
      rem.stat[i]<-1}
  }
}

##CALCULATE PERSON YEARS AND ABSOLUTE AND PERSON X YEAR INCIDENCE RATE
#person-year
per.year<-sum(time.to.event, na.rm=T)/365
per.year.res<-sum(time.to.event.res, na.rm=T)/365
per.year.no.res<-sum(time.to.event.no.res, na.rm=T)/365

#absolute incidence
abs.inc<-length(status[status==1])/length(status)*100 
abs.inc.res<-length(status.res[status.res==1])/length(status.res)*100
abs.inc.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100

#person-year incidence

py.inc<-length(status[status==1])/per.year*100
py.inc.res<-length(status.res[status.res==1])/per.year.res*100 # OK
py.inc.no.res<-length(status.no.res[status.no.res==1])/per.year.no.res*100 # OK

#SURVIVAL ANALYSIS

library(survival)
surv.obj <- Surv(time.to.event, status)
surv.obj.res <- Surv(time.to.event.res, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res, status.no.res)

survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)

study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)

#############COVARIATES
demog.dat <- read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/demog.csv", header = TRUE, sep = ",")

sex.1<-demog.dat$SEXC
sex.1[sex.1==2]<-0

sex  <- match.and.merge.func(total.ids, demog.dat$DSUBJID, sex.1) # ok
sex.res <- match.and.merge.func(response.ids, demog.dat$DSUBJID, sex.1)
sex.no.res <- match.and.merge.func(no.response.ids, demog.dat$DSUBJID, sex.1)

age  <- match.and.merge.func(total.ids, demog.dat$DSUBJID, demog.dat$AGE) # ok
age.no.res <- match.and.merge.func(no.response.ids, demog.dat$DSUBJID, demog.dat$AGE)
age.res <- match.and.merge.func(response.ids, demog.dat$DSUBJID, demog.dat$AGE)

country<-as.character(demog.dat$DCOUNTRY)
demog.ids.u<-unique(demog.dat$DSUBJID)
us<-array(0,length(demog.ids.u))
for(i in 1:length(demog.ids.u)){
  temp.country<-country[demog.dat$DSUBJID==demog.ids.u[i]]
  if(temp.country=="North America"){us[i]<-1}}

region <- match.and.merge.func(total.ids, demog.dat$DSUBJID, us) # ok
region.no.res <- match.and.merge.func(no.response.ids, demog.dat$DSUBJID, us)
region.res <- match.and.merge.func(response.ids, demog.dat$DSUBJID, us)


vital.dat <- read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/vital.csv", header = TRUE, sep = ",")  
vspos <- as.character(vital.dat$VSPOS)
vital.dat.bas <- vital.dat[(vital.dat$VISITNUM == 1)&(vspos == "SUPINE")&(vital.dat$VSSEQ==1),]  	 
ids.vs.u<-unique(vital.dat.bas$DSUBJID)
vswunit <- as.character(vital.dat.bas$VSWTUNIT)
vshunit <- as.character(vital.dat.bas$VSHTUNIT)

weight.kg<-array(,length(ids.vs.u))
for(i in 1:length(ids.vs.u)){
  if(vswunit[vital.dat.bas$DSUBJID==ids.vs.u[i]]=="lb"){weight.kg[i]<-vital.dat.bas$VSWEIGHT[vital.dat.bas$DSUBJID==ids.vs.u[i]]*0.4535}
  if(vswunit[vital.dat.bas$DSUBJID==ids.vs.u[i]]=="kg"){weight.kg[i]<-vital.dat.bas$VSWEIGHT[vital.dat.bas$DSUBJID==ids.vs.u[i]]}
}
height.cm<-array(,length(ids.vs.u))
for(i in 1:length(ids.vs.u)){
  if(vshunit[vital.dat.bas$DSUBJID==ids.vs.u[i]]=="in"){height.cm[i]<-vital.dat.bas$VSHEIGHT[vital.dat.bas$DSUBJID==ids.vs.u[i]]*2.54}
  if(vshunit[vital.dat.bas$DSUBJID==ids.vs.u[i]]=="cm"){height.cm[i]<-vital.dat.bas$VSHEIGHT[vital.dat.bas$DSUBJID==ids.vs.u[i]]}
}							                               						

weight <- match.and.merge.func(total.ids, ids.vs.u, weight.kg) #  ok
weight.res <- match.and.merge.func(response.ids, ids.vs.u, weight.kg)
weight.no.res <- match.and.merge.func(no.response.ids, ids.vs.u, weight.kg)

height <- match.and.merge.func(total.ids, ids.vs.u, height.cm) # ok
height.no.res <- match.and.merge.func(no.response.ids, ids.vs.u, height.cm)
height.res <- match.and.merge.func(response.ids, ids.vs.u, height.cm)


BMI<-weight/(height/100)^2  #ok
BMI.res<-weight.res/(height.res/100)^2  # ok
BMI.no.res<-weight.no.res/(height.no.res/100)^2 

aims.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/aims.csv", header = TRUE, sep = ",")

ad1 <- aims.dat[(aims.dat$VISITNUM==1 &  aims.dat$AIITEM=="008 SEVERITY OF ABNORMAL MOVEMENTS"),] 
ad1.ids.u <- unique(ad1$DSUBJID) 
aiscorec.sum <- array(,length(ad1.ids.u)) 
for (i in 1:length(ad1.ids.u)){
  aiscorec.sum[i] <- ad1$AISCOREC[ad1$DSUBJID==ad1.ids.u[i]]}
aiscorec.sum[aiscorec.sum<=1]<-0
aiscorec.sum[aiscorec.sum>1]<-1

aims <- match.and.merge.func(total.ids, ad1.ids.u, aiscorec.sum) # ok
aims.res <- match.and.merge.func(response.ids, ad1.ids.u, aiscorec.sum) # ok
aims.no.res <- match.and.merge.func(no.response.ids, ad1.ids.u, aiscorec.sum) # ok

bars.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/bars.csv", header = TRUE, sep = ",")
ba1<-bars.dat[(bars.dat$VISITNUM==3 & bars.dat$BAITEM=="003 GLOBAL CLINICAL RATING OF AKATHISIA"),]
ba1.ids.u <- unique(ba1$DSUBJID)
bascorec.sum <-array(,length(ba1.ids.u))	

for (i in 1:length(ba1.ids.u)){
  bascorec.sum[i]<-ba1$BASCOREC[ba1$DSUBJID==ba1.ids.u[i]]}
bascorec.sum[bascorec.sum<=1]<-0
bascorec.sum[bascorec.sum>1]<-1

bars<- match.and.merge.func(total.ids, ba1.ids.u,bascorec.sum) #ok   
bars.no.res<- match.and.merge.func(no.response.ids, ba1.ids.u,bascorec.sum) # ok  
bars.res<- match.and.merge.func(response.ids, ba1.ids.u,bascorec.sum) # ok 

cgi.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/cgi.csv", header = TRUE, sep = ",")
cgi1 <- cgi.dat[cgi.dat$VISITNUM==3,] #here we create cgi1 which contains only row w visit 3 (equivalent to day 1) from cgi.dat
cgi.ids.u <- unique(cgi1$DSUBJID) 
cgi.bl <- array(,length(cgi.ids.u))
for (i in 1:length(cgi.ids.u)){
  cgi.bl[i] <- cgi1$CGSEVC[cgi1$DSUBJID==cgi.ids.u[i]]
}  

cgi <- match.and.merge.func(total.ids, cgi.ids.u, cgi.bl) # ok
cgi.res <- match.and.merge.func(response.ids, cgi.ids.u, cgi.bl) # ok
cgi.no.res <- match.and.merge.func(no.response.ids, cgi.ids.u, cgi.bl) # ok

diagnos.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/diagnos.csv", header = TRUE, sep = ",")
diag.ids.u<-unique(diagnos.dat$DSUBJID)
age1<-as.numeric(as.character(diagnos.dat$DGAGE))

age.diag <- match.and.merge.func(total.ids, diag.ids.u, age1)# ok
age.diag.no.res <- match.and.merge.func(no.response.ids, diag.ids.u, age1)# ok
age.diag.res <- match.and.merge.func(response.ids, diag.ids.u, age1)# ok

doi<-age-age.diag # ok
doi.no.res<-age.no.res-age.diag.no.res # ok
doi.res<-age.res-age.diag.res # ok

habit.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/habit.csv", header = TRUE, sep = ",")
habit.dat.bas<-habit.dat[habit.dat$VISITNUM==1,]
habit.dat.ids<-unique(habit.dat.bas$DSUBJID)
habit.dat.smoke<-as.character(habit.dat.bas$HASMOCU)
habit.dat.smoke[habit.dat.smoke=="NO"]<-0
habit.dat.smoke[habit.dat.smoke=="YES"]<-1
habit.dat.smoke<-as.numeric(habit.dat.smoke)

nicotine <- match.and.merge.func(total.ids, habit.dat.ids, habit.dat.smoke) #ok
nicotine.res <- match.and.merge.func(response.ids, habit.dat.ids, habit.dat.smoke) # ok
nicotine.no.res <- match.and.merge.func(no.response.ids, habit.dat.ids, habit.dat.smoke) # ok

panss.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/panss.csv", header = TRUE, sep = ",")

panss.dat.bas <- panss.dat[panss.dat$VISITNUM == 1,]
panss.id.u<-unique(panss.dat.bas$DSUBJID)
panss.grp.char <- as.character(panss.dat.bas$PAGROUP)
panss.gen1<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array1<-panss.dat.bas$PASCOREC[(panss.dat.bas$DSUBJID==panss.id.u[i])&(panss.grp.char=="030 GENERAL PSYCHOPATHOLOGY SUBSCALE")]
  panss.gen1[i]<-sum(temp.array1,na.rm=T)
}

panss.gen <- match.and.merge.func(total.ids, panss.id.u, panss.gen1)# ok
panss.gen.res <- match.and.merge.func(response.ids, panss.id.u, panss.gen1)# ok
panss.gen.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.gen1)# ok

panss.neg1<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array1<-panss.dat.bas$PASCOREC[(panss.dat.bas$DSUBJID==panss.id.u[i])&(panss.grp.char=="020 NEGATIVE SUBSCALE")]
  panss.neg1[i]<-sum(temp.array1,na.rm=T)
}

panss.neg <- match.and.merge.func(total.ids, panss.id.u, panss.neg1)# ok
panss.neg.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.neg1)#ok
panss.neg.res <- match.and.merge.func(response.ids, panss.id.u, panss.neg1)#ok

panss.pos1<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array1<-panss.dat.bas$PASCOREC[(panss.dat.bas$DSUBJID==panss.id.u[i])&(panss.grp.char=="010 POSITIVE SUBSCALE")]
  panss.pos1[i]<-sum(temp.array1,na.rm=T)
}

panss.pos<- match.and.merge.func(total.ids, panss.id.u, panss.pos1)#ok
panss.pos.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.pos1)#ok
panss.pos.res <- match.and.merge.func(response.ids, panss.id.u, panss.pos1)#ok


panss.tot<-panss.gen+panss.pos+panss.neg #ok
panss.tot.no.res<-panss.gen.no.res+panss.pos.no.res+panss.neg.no.res #ok
panss.tot.res<-panss.gen.res+panss.pos.res+panss.neg.res #ok

psyhist.dat<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/psyhist.csv", header = TRUE, sep = ",")

hosp.id.u<-unique(psyhist.dat$DSUBJID)

hosp.last.d<-array(,length(hosp.id.u))
for(i in 1:length(hosp.id.u)){
  temp.array<-psyhist.dat$PYENDY[psyhist.dat$DSUBJID==hosp.id.u[i]]
  hosp.last.d[i]<-max(temp.array)
}
hosp.last.d[hosp.last.d>-365]<-1
hosp.last.d[hosp.last.d<(-364)]<-0
hosp.last.d[is.na(hosp.last.d)]<-0

last.hosp <- match.and.merge.func(total.ids, hosp.id.u, hosp.last.d) #ok
last.hosp.res <- match.and.merge.func(response.ids, hosp.id.u, hosp.last.d) #ok
last.hosp.no.res <- match.and.merge.func(no.response.ids, hosp.id.u, hosp.last.d) #ok

sars.dats<-read.csv("X:/Data/JnJ-R092670-PSY-3005-csv/Data/sars.csv", header = TRUE, sep = ",")
sars.dat <-sars.dats[sars.dats$VISITNUM==1,]
sarids.u <- unique(sars.dat$DSUBJID)
eps.temp <- array(,length(sarids.u))
for (i in 1:length(sarids.u)){
  temp.array<-sars.dat$SRSCOREC[sars.dat$DSUBJID==sarids.u[i]]
  eps.temp[i]<- sum(temp.array, na.rm = T)/10}

eps.temp[eps.temp<0.65]<-0
eps.temp[eps.temp>0.64]<-1

eps <- match.and.merge.func(total.ids, sarids.u, eps.temp)#ok
eps.no.res <- match.and.merge.func(no.response.ids, sarids.u, eps.temp)#ok
eps.res <- match.and.merge.func(response.ids, sarids.u, eps.temp)#ok


##COX REGRESSION

coxph(formula = surv.obj ~sex )
coxph(formula = surv.obj.res ~sex.res )
coxph(formula = surv.obj.no.res ~sex.no.res )
coxph(formula = surv.obj ~age )
coxph(formula = surv.obj.no.res ~age.no.res )
coxph(formula = surv.obj.res ~age.res )
coxph(formula = surv.obj ~region)
coxph(formula = surv.obj.res ~region.res)
coxph(formula = surv.obj.no.res ~region.no.res)
coxph(formula = surv.obj ~BMI)
coxph(formula = surv.obj.no.res ~BMI.no.res)
coxph(formula = surv.obj.res ~BMI.res)
coxph(formula = surv.obj ~aims )
coxph(formula = surv.obj.res ~aims.res )
coxph(formula = surv.obj.no.res ~aims.no.res )
coxph(formula = surv.obj ~bars)
coxph(formula = surv.obj.no.res ~bars.no.res )	 
coxph(formula = surv.obj.res ~bars.res )
coxph(formula = surv.obj ~cgi )
coxph(formula = surv.obj.res ~cgi.res )
coxph(formula = surv.obj.no.res ~cgi.no.res )	 
coxph(formula = surv.obj ~age.diag )
coxph(formula = surv.obj.no.res ~age.diag.no.res )
coxph(formula = surv.obj.res ~age.diag.res )
coxph(formula = surv.obj ~doi)
coxph(formula = surv.obj.res ~doi.res)
coxph(formula = surv.obj.no.res ~doi.no.res)	 
coxph(formula = surv.obj ~nicotine )
coxph(formula = surv.obj.no.res ~nicotine.no.res )
coxph(formula = surv.obj.res ~nicotine.res )	 
coxph(formula = surv.obj ~panss.gen )
coxph(formula = surv.obj.res ~panss.gen.res) 
coxph(formula = surv.obj.no.res ~panss.gen.no.res)  
coxph(formula = surv.obj ~panss.neg) 
coxph(formula = surv.obj.no.res ~panss.neg.no.res) 
coxph(formula = surv.obj.res ~panss.neg.res)
coxph(formula = surv.obj ~panss.pos) 
coxph(formula = surv.obj.res ~panss.pos.res) 
coxph(formula = surv.obj.no.res ~panss.pos.no.res)
coxph(formula = surv.obj ~panss.tot)
coxph(formula = surv.obj.no.res ~panss.tot.no.res)
coxph(formula = surv.obj.res ~panss.tot.res)	 
coxph(formula = surv.obj ~last.hosp) 
coxph(formula = surv.obj.res ~last.hosp.res) 
coxph(formula = surv.obj.no.res ~last.hosp.no.res)	 
coxph(formula = surv.obj ~eps) 
coxph(formula = surv.obj.no.res ~eps.no.res) 
coxph(formula = surv.obj.res ~eps.res) 

ci.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex))[8])[c(3,9,12)]
ci.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age))[8])[c(3,9,12)]
ci.int.reg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region))[8])[c(3,9,12)]
ci.int.bmi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[8])[c(3,9,12)]
ci.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims))[8])[c(3,9,12)]
ci.int.age.diag<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age.diag))[8])[c(3,9,12)]
ci.int.doi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*doi))[8])[c(3,9,12)]
ci.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars))[8])[c(3,9,12)]
ci.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi))[8])[c(3,9,12)]
ci.int.nicotine<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine))[8])[c(3,9,12)]
ci.int.panss.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot))[8])[c(3,9,12)]
ci.int.panss.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen))[8])[c(3,9,12)]
ci.int.panss.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos))[8])[c(3,9,12)]
ci.int.panss.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg))[8])[c(3,9,12)]
ci.int.last.hosp<-unlist(summary(coxph(formula = surv.obj ~rem.stat*last.hosp))[8])[c(3,9,12)]
ci.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps))[8])[c(3,9,12)]

#logHR and logSE for interaction terms
sei.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex))[7])[c(3,9)]
sei.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age))[7])[c(3,9)]
sei.int.reg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region))[7])[c(3,9)]
sei.int.bmi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[7])[c(3,9)]
sei.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims))[7])[c(3,9)]
sei.int.age.diag<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age.diag))[7])[c(3,9)]
sei.int.doi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*doi))[7])[c(3,9)]
sei.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars))[7])[c(3,9)]
sei.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi))[7])[c(3,9)]
sei.int.nicotine<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine))[7])[c(3,9)]
sei.int.panss.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot))[7])[c(3,9)]
sei.int.panss.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen))[7])[c(3,9)]
sei.int.panss.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos))[7])[c(3,9)]
sei.int.panss.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg))[7])[c(3,9)]
sei.int.last.hosp<-unlist(summary(coxph(formula = surv.obj ~rem.stat*last.hosp))[7])[c(3,9)]
sei.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps))[7])[c(3,9)]

#logHR and logSE for Cox of no.remission.ids (total.ids and remission.ids, had already been calculated from CIs on previous run of analyses)
sei.sex<-unlist(summary(coxph(formula = surv.obj.no.res ~sex.no.res))[7])[c(1,3)]
sei.age<-unlist(summary(coxph(formula = surv.obj.no.res ~age.no.res))[7])[c(1,3)]
sei.reg<-unlist(summary(coxph(formula = surv.obj.no.res ~region.no.res))[7])[c(1,3)]
sei.bmi<-unlist(summary(coxph(formula = surv.obj.no.res ~BMI.no.res))[7])[c(1,3)]
sei.aims<-unlist(summary(coxph(formula = surv.obj.no.res ~aims.no.res))[7])[c(1,3)]
sei.age.diag<-unlist(summary(coxph(formula = surv.obj.no.res ~age.diag.no.res))[7])[c(1,3)]
sei.doi<-unlist(summary(coxph(formula = surv.obj.no.res ~doi.no.res))[7])[c(1,3)]
sei.bars<-unlist(summary(coxph(formula = surv.obj.no.res ~bars.no.res))[7])[c(1,3)]
sei.cgi<-unlist(summary(coxph(formula = surv.obj.no.res ~cgi.no.res))[7])[c(1,3)]
sei.nicotine<-unlist(summary(coxph(formula = surv.obj.no.res ~nicotine.no.res))[7])[c(1,3)]
sei.panss.tot<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.tot.no.res))[7])[c(1,3)]
sei.panss.gen<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.gen.no.res))[7])[c(1,3)]
sei.panss.pos<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.pos.no.res))[7])[c(1,3)]
sei.panss.neg<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.neg.no.res))[7])[c(1,3)]
sei.last.hosp<-unlist(summary(coxph(formula = surv.obj.no.res ~last.hosp.no.res))[7])[c(1,3)]
sei.eps<-unlist(summary(coxph(formula = surv.obj.no.res ~eps.no.res))[7])[c(1,3)]

######CALCULATE HR AND 95%CI

sex.hr<-coxph(formula = surv.obj ~sex )
sex.hr.res<-coxph(formula = surv.obj.res ~sex.res )
sex.hr.no.res<-coxph(formula = surv.obj.no.res ~sex.no.res )

se.sex.hr<-sqrt(sex.hr[[2]])
beta.sex.hr<-sex.hr[[1]]

up.lim.sex.hr<-exp(beta.sex.hr+(1.96*se.sex.hr))
low.lim.sex.hr<-exp(beta.sex.hr-(1.96*se.sex.hr))
hr.sex<-exp(beta.sex.hr)

se.sex.hr.no.res<-sqrt(sex.hr.no.res[[2]])
beta.sex.hr.no.res<-sex.hr.no.res[[1]]

up.lim.sex.hr.no.res<-exp(beta.sex.hr.no.res+(1.96*se.sex.hr.no.res))
low.lim.sex.hr.no.res<-exp(beta.sex.hr.no.res-(1.96*se.sex.hr.no.res))
hr.sex.no.res<-exp(beta.sex.hr.no.res)

se.sex.hr.res<-sqrt(sex.hr.res[[2]])
beta.sex.hr.res<-sex.hr.res[[1]]

up.lim.sex.hr.res<-exp(beta.sex.hr.res+(1.96*se.sex.hr.res))
low.lim.sex.hr.res<-exp(beta.sex.hr.res-(1.96*se.sex.hr.res))
hr.sex.res<-exp(beta.sex.hr.res)

age.hr<-coxph(formula = surv.obj ~age )
age.hr.res<-coxph(formula = surv.obj.res ~age.res )
age.hr.no.res<-coxph(formula = surv.obj.no.res ~age.no.res )

se.age.hr<-sqrt(age.hr[[2]])
beta.age.hr<-age.hr[[1]]

up.lim.age.hr<-exp(beta.age.hr+(1.96*se.age.hr))
low.lim.age.hr<-exp(beta.age.hr-(1.96*se.age.hr))
hr.age<-exp(beta.age.hr)

se.age.hr.no.res<-sqrt(age.hr.no.res[[2]])
beta.age.hr.no.res<-age.hr.no.res[[1]]

up.lim.age.hr.no.res<-exp(beta.age.hr.no.res+(1.96*se.age.hr.no.res))
low.lim.age.hr.no.res<-exp(beta.age.hr.no.res-(1.96*se.age.hr.no.res))
hr.age.no.res<-exp(beta.age.hr.no.res)

se.age.hr.res<-sqrt(age.hr.res[[2]])
beta.age.hr.res<-age.hr.res[[1]]

up.lim.age.hr.res<-exp(beta.age.hr.res+(1.96*se.age.hr.res))
low.lim.age.hr.res<-exp(beta.age.hr.res-(1.96*se.age.hr.res))
hr.age.res<-exp(beta.age.hr.res)

reg.hr<-coxph(formula = surv.obj ~region)
reg.hr.res<-coxph(formula = surv.obj.res ~region.res)
reg.hr.no.res<-coxph(formula = surv.obj.no.res ~region.no.res)

se.reg.hr<-sqrt(reg.hr[[2]])
beta.reg.hr<-reg.hr[[1]]

up.lim.reg.hr<-exp(beta.reg.hr+(1.96*se.reg.hr))
low.lim.reg.hr<-exp(beta.reg.hr-(1.96*se.reg.hr))
hr.reg<-exp(beta.reg.hr)

se.reg.hr.no.res<-sqrt(reg.hr.no.res[[2]])
beta.reg.hr.no.res<-reg.hr.no.res[[1]]

up.lim.reg.hr.no.res<-exp(beta.reg.hr.no.res+(1.96*se.reg.hr.no.res))
low.lim.reg.hr.no.res<-exp(beta.reg.hr.no.res-(1.96*se.reg.hr.no.res))
hr.reg.no.res<-exp(beta.reg.hr.no.res)

se.reg.hr.res<-sqrt(reg.hr.res[[2]])
beta.reg.hr.res<-reg.hr.res[[1]]

up.lim.reg.hr.res<-exp(beta.reg.hr.res+(1.96*se.reg.hr.res))
low.lim.reg.hr.res<-exp(beta.reg.hr.res-(1.96*se.reg.hr.res))
hr.reg.res<-exp(beta.reg.hr.res)

bmi.hr<-coxph(formula = surv.obj ~BMI)
bmi.hr.res<-coxph(formula = surv.obj.res ~BMI.res)
bmi.hr.no.res<-coxph(formula = surv.obj.no.res ~BMI.no.res)

se.bmi.hr<-sqrt(bmi.hr[[2]])
beta.bmi.hr<-bmi.hr[[1]]

up.lim.bmi.hr<-exp(beta.bmi.hr+(1.96*se.bmi.hr))
low.lim.bmi.hr<-exp(beta.bmi.hr-(1.96*se.bmi.hr))
hr.bmi<-exp(beta.bmi.hr)

se.bmi.hr.no.res<-sqrt(bmi.hr.no.res[[2]])
beta.bmi.hr.no.res<-bmi.hr.no.res[[1]]

up.lim.bmi.hr.no.res<-exp(beta.bmi.hr.no.res+(1.96*se.bmi.hr.no.res))
low.lim.bmi.hr.no.res<-exp(beta.bmi.hr.no.res-(1.96*se.bmi.hr.no.res))
hr.bmi.no.res<-exp(beta.bmi.hr.no.res)

se.bmi.hr.res<-sqrt(bmi.hr.res[[2]])
beta.bmi.hr.res<-bmi.hr.res[[1]]

up.lim.bmi.hr.res<-exp(beta.bmi.hr.res+(1.96*se.bmi.hr.res))
low.lim.bmi.hr.res<-exp(beta.bmi.hr.res-(1.96*se.bmi.hr.res))
hr.bmi.res<-exp(beta.bmi.hr.res)

aim.hr<-coxph(formula = surv.obj ~aims )
aim.hr.res<-coxph(formula = surv.obj.res ~aims.res )
aim.hr.no.res<-coxph(formula = surv.obj.no.res ~aims.no.res )

se.aim.hr<-sqrt(aim.hr[[2]])
beta.aim.hr<-aim.hr[[1]]

up.lim.aim.hr<-exp(beta.aim.hr+(1.96*se.aim.hr))
low.lim.aim.hr<-exp(beta.aim.hr-(1.96*se.aim.hr))
hr.aim<-exp(beta.aim.hr)

se.aim.hr.no.res<-sqrt(aim.hr.no.res[[2]])
beta.aim.hr.no.res<-aim.hr.no.res[[1]]

up.lim.aim.hr.no.res<-exp(beta.aim.hr.no.res+(1.96*se.aim.hr.no.res))
low.lim.aim.hr.no.res<-exp(beta.aim.hr.no.res-(1.96*se.aim.hr.no.res))
hr.aim.no.res<-exp(beta.aim.hr.no.res)

se.aim.hr.res<-sqrt(aim.hr.res[[2]])
beta.aim.hr.res<-aim.hr.res[[1]]

up.lim.aim.hr.res<-exp(beta.aim.hr.res+(1.96*se.aim.hr.res))
low.lim.aim.hr.res<-exp(beta.aim.hr.res-(1.96*se.aim.hr.res))
hr.aim.res<-exp(beta.aim.hr.res)

bar.hr<-coxph(formula = surv.obj ~bars)
bar.hr.res<-coxph(formula = surv.obj.res ~bars.res )
bar.hr.no.res<-coxph(formula = surv.obj.no.res ~bars.no.res ) 

se.bar.hr<-sqrt(bar.hr[[2]])
beta.bar.hr<-bar.hr[[1]]

up.lim.bar.hr<-exp(beta.bar.hr+(1.96*se.bar.hr))
low.lim.bar.hr<-exp(beta.bar.hr-(1.96*se.bar.hr))
hr.bar<-exp(beta.bar.hr)

se.bar.hr.no.res<-sqrt(bar.hr.no.res[[2]])
beta.bar.hr.no.res<-bar.hr.no.res[[1]]

up.lim.bar.hr.no.res<-exp(beta.bar.hr.no.res+(1.96*se.bar.hr.no.res))
low.lim.bar.hr.no.res<-exp(beta.bar.hr.no.res-(1.96*se.bar.hr.no.res))
hr.bar.no.res<-exp(beta.bar.hr.no.res)

se.bar.hr.res<-sqrt(bar.hr.res[[2]])
beta.bar.hr.res<-bar.hr.res[[1]]

up.lim.bar.hr.res<-exp(beta.bar.hr.res+(1.96*se.bar.hr.res))
low.lim.bar.hr.res<-exp(beta.bar.hr.res-(1.96*se.bar.hr.res))
hr.bar.res<-exp(beta.bar.hr.res)

cgi.hr<-coxph(formula = surv.obj ~cgi )
cgi.hr.res<-coxph(formula = surv.obj.res ~cgi.res )
cgi.hr.no.res<-coxph(formula = surv.obj.no.res ~cgi.no.res )

se.cgi.hr<-sqrt(cgi.hr[[2]])
beta.cgi.hr<-cgi.hr[[1]]

up.lim.cgi.hr<-exp(beta.cgi.hr+(1.96*se.cgi.hr))
low.lim.cgi.hr<-exp(beta.cgi.hr-(1.96*se.cgi.hr))
hr.cgi<-exp(beta.cgi.hr)

se.cgi.hr.no.res<-sqrt(cgi.hr.no.res[[2]])
beta.cgi.hr.no.res<-cgi.hr.no.res[[1]]

up.lim.cgi.hr.no.res<-exp(beta.cgi.hr.no.res+(1.96*se.cgi.hr.no.res))
low.lim.cgi.hr.no.res<-exp(beta.cgi.hr.no.res-(1.96*se.cgi.hr.no.res))
hr.cgi.no.res<-exp(beta.cgi.hr.no.res)

se.cgi.hr.res<-sqrt(cgi.hr.res[[2]])
beta.cgi.hr.res<-cgi.hr.res[[1]]

up.lim.cgi.hr.res<-exp(beta.cgi.hr.res+(1.96*se.cgi.hr.res))
low.lim.cgi.hr.res<-exp(beta.cgi.hr.res-(1.96*se.cgi.hr.res))
hr.cgi.res<-exp(beta.cgi.hr.res)

dia.hr<-coxph(formula = surv.obj ~age.diag )
dia.hr.res<-coxph(formula = surv.obj.res ~age.diag.res )
dia.hr.no.res<-coxph(formula = surv.obj.no.res ~age.diag.no.res )

se.dia.hr<-sqrt(dia.hr[[2]])
beta.dia.hr<-dia.hr[[1]]

up.lim.dia.hr<-exp(beta.dia.hr+(1.96*se.dia.hr))
low.lim.dia.hr<-exp(beta.dia.hr-(1.96*se.dia.hr))
hr.dia<-exp(beta.dia.hr)

se.dia.hr.no.res<-sqrt(dia.hr.no.res[[2]])
beta.dia.hr.no.res<-dia.hr.no.res[[1]]

up.lim.dia.hr.no.res<-exp(beta.dia.hr.no.res+(1.96*se.dia.hr.no.res))
low.lim.dia.hr.no.res<-exp(beta.dia.hr.no.res-(1.96*se.dia.hr.no.res))
hr.dia.no.res<-exp(beta.dia.hr.no.res)

se.dia.hr.res<-sqrt(dia.hr.res[[2]])
beta.dia.hr.res<-dia.hr.res[[1]]

up.lim.dia.hr.res<-exp(beta.dia.hr.res+(1.96*se.dia.hr.res))
low.lim.dia.hr.res<-exp(beta.dia.hr.res-(1.96*se.dia.hr.res))
hr.dia.res<-exp(beta.dia.hr.res)

doi.hr<-coxph(formula = surv.obj ~doi)
doi.hr.res<-coxph(formula = surv.obj.res ~doi.res)
doi.hr.no.res<-coxph(formula = surv.obj.no.res ~doi.no.res)

se.doi.hr<-sqrt(doi.hr[[2]])
beta.doi.hr<-doi.hr[[1]]

up.lim.doi.hr<-exp(beta.doi.hr+(1.96*se.doi.hr))
low.lim.doi.hr<-exp(beta.doi.hr-(1.96*se.doi.hr))
hr.doi<-exp(beta.doi.hr)

se.doi.hr.no.res<-sqrt(doi.hr.no.res[[2]])
beta.doi.hr.no.res<-doi.hr.no.res[[1]]

up.lim.doi.hr.no.res<-exp(beta.doi.hr.no.res+(1.96*se.doi.hr.no.res))
low.lim.doi.hr.no.res<-exp(beta.doi.hr.no.res-(1.96*se.doi.hr.no.res))
hr.doi.no.res<-exp(beta.doi.hr.no.res)

se.doi.hr.res<-sqrt(doi.hr.res[[2]])
beta.doi.hr.res<-doi.hr.res[[1]]

up.lim.doi.hr.res<-exp(beta.doi.hr.res+(1.96*se.doi.hr.res))
low.lim.doi.hr.res<-exp(beta.doi.hr.res-(1.96*se.doi.hr.res))
hr.doi.res<-exp(beta.doi.hr.res)

nic.hr<-coxph(formula = surv.obj ~nicotine )
nic.hr.res<-coxph(formula = surv.obj.res ~nicotine.res )
nic.hr.no.res<-coxph(formula = surv.obj.no.res ~nicotine.no.res )

se.nic.hr<-sqrt(nic.hr[[2]])
beta.nic.hr<-nic.hr[[1]]

up.lim.nic.hr<-exp(beta.nic.hr+(1.96*se.nic.hr))
low.lim.nic.hr<-exp(beta.nic.hr-(1.96*se.nic.hr))
hr.nic<-exp(beta.nic.hr)

se.nic.hr.no.res<-sqrt(nic.hr.no.res[[2]])
beta.nic.hr.no.res<-nic.hr.no.res[[1]]

up.lim.nic.hr.no.res<-exp(beta.nic.hr.no.res+(1.96*se.nic.hr.no.res))
low.lim.nic.hr.no.res<-exp(beta.nic.hr.no.res-(1.96*se.nic.hr.no.res))
hr.nic.no.res<-exp(beta.nic.hr.no.res)	

se.nic.hr.res<-sqrt(nic.hr.res[[2]])
beta.nic.hr.res<-nic.hr.res[[1]]

up.lim.nic.hr.res<-exp(beta.nic.hr.res+(1.96*se.nic.hr.res))
low.lim.nic.hr.res<-exp(beta.nic.hr.res-(1.96*se.nic.hr.res))
hr.nic.res<-exp(beta.nic.hr.res) 

gen.hr<-coxph(formula = surv.obj ~panss.gen )
gen.hr.res<-coxph(formula = surv.obj.res ~panss.gen.res) 
gen.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.gen.no.res)

se.gen.hr<-sqrt(gen.hr[[2]])
beta.gen.hr<-gen.hr[[1]]

up.lim.gen.hr<-exp(beta.gen.hr+(1.96*se.gen.hr))
low.lim.gen.hr<-exp(beta.gen.hr-(1.96*se.gen.hr))
hr.gen<-exp(beta.gen.hr)

se.gen.hr.no.res<-sqrt(gen.hr.no.res[[2]])
beta.gen.hr.no.res<-gen.hr.no.res[[1]]

up.lim.gen.hr.no.res<-exp(beta.gen.hr.no.res+(1.96*se.gen.hr.no.res))
low.lim.gen.hr.no.res<-exp(beta.gen.hr.no.res-(1.96*se.gen.hr.no.res))
hr.gen.no.res<-exp(beta.gen.hr.no.res)

se.gen.hr.res<-sqrt(gen.hr.res[[2]])
beta.gen.hr.res<-gen.hr.res[[1]]

up.lim.gen.hr.res<-exp(beta.gen.hr.res+(1.96*se.gen.hr.res))
low.lim.gen.hr.res<-exp(beta.gen.hr.res-(1.96*se.gen.hr.res))
hr.gen.res<-exp(beta.gen.hr.res)

neg.hr<-coxph(formula = surv.obj ~panss.neg) 
neg.hr.res<-coxph(formula = surv.obj.res ~panss.neg.res) 
neg.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.neg.no.res) 

se.neg.hr<-sqrt(neg.hr[[2]])
beta.neg.hr<-neg.hr[[1]]

up.lim.neg.hr<-exp(beta.neg.hr+(1.96*se.neg.hr))
low.lim.neg.hr<-exp(beta.neg.hr-(1.96*se.neg.hr))
hr.neg<-exp(beta.neg.hr)

se.neg.hr.no.res<-sqrt(neg.hr.no.res[[2]])
beta.neg.hr.no.res<-neg.hr.no.res[[1]]

up.lim.neg.hr.no.res<-exp(beta.neg.hr.no.res+(1.96*se.neg.hr.no.res))
low.lim.neg.hr.no.res<-exp(beta.neg.hr.no.res-(1.96*se.neg.hr.no.res))
hr.neg.no.res<-exp(beta.neg.hr.no.res)

se.neg.hr.res<-sqrt(neg.hr.res[[2]])
beta.neg.hr.res<-neg.hr.res[[1]]

up.lim.neg.hr.res<-exp(beta.neg.hr.res+(1.96*se.neg.hr.res))
low.lim.neg.hr.res<-exp(beta.neg.hr.res-(1.96*se.neg.hr.res))
hr.neg.res<-exp(beta.neg.hr.res)

pos.hr<-coxph(formula = surv.obj ~panss.pos) 
pos.hr.res<-coxph(formula = surv.obj.res ~panss.pos.res) 
pos.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.pos.no.res) 

se.pos.hr<-sqrt(pos.hr[[2]])
beta.pos.hr<-pos.hr[[1]]

up.lim.pos.hr<-exp(beta.pos.hr+(1.96*se.pos.hr))
low.lim.pos.hr<-exp(beta.pos.hr-(1.96*se.pos.hr))
hr.pos<-exp(beta.pos.hr)

se.pos.hr.no.res<-sqrt(pos.hr.no.res[[2]])
beta.pos.hr.no.res<-pos.hr.no.res[[1]]

up.lim.pos.hr.no.res<-exp(beta.pos.hr.no.res+(1.96*se.pos.hr.no.res))
low.lim.pos.hr.no.res<-exp(beta.pos.hr.no.res-(1.96*se.pos.hr.no.res))
hr.pos.no.res<-exp(beta.pos.hr.no.res)

se.pos.hr.res<-sqrt(pos.hr.res[[2]])
beta.pos.hr.res<-pos.hr.res[[1]]

up.lim.pos.hr.res<-exp(beta.pos.hr.res+(1.96*se.pos.hr.res))
low.lim.pos.hr.res<-exp(beta.pos.hr.res-(1.96*se.pos.hr.res))
hr.pos.res<-exp(beta.pos.hr.res)

tot.hr<-coxph(formula = surv.obj ~panss.tot)
tot.hr.res<-coxph(formula = surv.obj.res ~panss.tot.res)
tot.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.tot.no.res)

se.tot.hr<-sqrt(tot.hr[[2]])
beta.tot.hr<-tot.hr[[1]]

up.lim.tot.hr<-exp(beta.tot.hr+(1.96*se.tot.hr))
low.lim.tot.hr<-exp(beta.tot.hr-(1.96*se.tot.hr))
hr.tot<-exp(beta.tot.hr)

se.tot.hr.no.res<-sqrt(tot.hr.no.res[[2]])
beta.tot.hr.no.res<-tot.hr.no.res[[1]]

up.lim.tot.hr.no.res<-exp(beta.tot.hr.no.res+(1.96*se.tot.hr.no.res))
low.lim.tot.hr.no.res<-exp(beta.tot.hr.no.res-(1.96*se.tot.hr.no.res))
hr.tot.no.res<-exp(beta.tot.hr.no.res)

se.tot.hr.res<-sqrt(tot.hr.res[[2]])
beta.tot.hr.res<-tot.hr.res[[1]]

up.lim.tot.hr.res<-exp(beta.tot.hr.res+(1.96*se.tot.hr.res))
low.lim.tot.hr.res<-exp(beta.tot.hr.res-(1.96*se.tot.hr.res))
hr.tot.res<-exp(beta.tot.hr.res)

las.hr<-coxph(formula = surv.obj ~last.hosp) 
las.hr.res<-coxph(formula = surv.obj.res ~last.hosp.res) 
las.hr.no.res<-coxph(formula = surv.obj.no.res ~last.hosp.no.res) 

se.las.hr<-sqrt(las.hr[[2]])
beta.las.hr<-las.hr[[1]]

up.lim.las.hr<-exp(beta.las.hr+(1.96*se.las.hr))
low.lim.las.hr<-exp(beta.las.hr-(1.96*se.las.hr))
hr.las<-exp(beta.las.hr)

se.las.hr.no.res<-sqrt(las.hr.no.res[[2]])
beta.las.hr.no.res<-las.hr.no.res[[1]]

up.lim.las.hr.no.res<-exp(beta.las.hr.no.res+(1.96*se.las.hr.no.res))
low.lim.las.hr.no.res<-exp(beta.las.hr.no.res-(1.96*se.las.hr.no.res))
hr.las.no.res<-exp(beta.las.hr.no.res)

se.las.hr.res<-sqrt(las.hr.res[[2]])
beta.las.hr.res<-las.hr.res[[1]]

up.lim.las.hr.res<-exp(beta.las.hr.res+(1.96*se.las.hr.res))
low.lim.las.hr.res<-exp(beta.las.hr.res-(1.96*se.las.hr.res))
hr.las.res<-exp(beta.las.hr.res)

eps.hr<-coxph(formula = surv.obj ~eps) 
eps.hr.res<-coxph(formula = surv.obj.res ~eps.res) 
eps.hr.no.res<-coxph(formula = surv.obj.no.res ~eps.no.res) 

se.eps.hr<-sqrt(eps.hr[[2]])
beta.eps.hr<-eps.hr[[1]]

up.lim.eps.hr<-exp(beta.eps.hr+(1.96*se.eps.hr))
low.lim.eps.hr<-exp(beta.eps.hr-(1.96*se.eps.hr))
hr.eps<-exp(beta.eps.hr)

se.eps.hr.no.res<-sqrt(eps.hr.no.res[[2]])
beta.eps.hr.no.res<-eps.hr.no.res[[1]]

up.lim.eps.hr.no.res<-exp(beta.eps.hr.no.res+(1.96*se.eps.hr.no.res))
low.lim.eps.hr.no.res<-exp(beta.eps.hr.no.res-(1.96*se.eps.hr.no.res))
hr.eps.no.res<-exp(beta.eps.hr.no.res)

se.eps.hr.res<-sqrt(eps.hr.res[[2]])
beta.eps.hr.res<-eps.hr.res[[1]]

up.lim.eps.hr.res<-exp(beta.eps.hr.res+(1.96*se.eps.hr.res))
low.lim.eps.hr.res<-exp(beta.eps.hr.res-(1.96*se.eps.hr.res))
hr.eps.res<-exp(beta.eps.hr.res)

#####SUMMARY TABLES

colname.desc.cont<- c("Age (mean)", "Age (SD)", "BMI (mean)", "BMI (SD)","Age at diagnosis (mean)","Age at diagnosis (SD)","Duration of illness (mean)","Duration of illness (SD)", "CGI (mean)","CGI (SD)","Psychopathology total score (mean)","Psychopathology total score (SD)", "Psychopathology general score (mean)","Psychopathology general score (SD)","Psychopathology positive score (mean)","Psychopathology positive score (SD)","Psychopathology negative score (mean)","Psychopathology negative score (SD)","General functioning score (mean)","General functioning score (SD)", "Quality of life score (mean)","Quality of life score (SD)")

mean.age<-mean(age, na.rm=T)
sd.age<-sd(age,na.rm=T)
mean.BMI<-mean(BMI,na.rm=T)
sd.BMI<-sd(BMI,na.rm=T)
mean.agediagnosis<-mean(age.diag, na.rm=T)
sd.agediagnsosis<-sd(age.diag,na.rm=T)
mean.doi<-mean(doi,na.rm=T)
sd.doi<-sd(doi,na.rm=T)
mean.cgi<-mean(cgi,na.rm=T)
sd.cgi<-sd(cgi,na.rm=T)
mean.totps<-mean(panss.tot,na.rm=T)
sd.totps<-sd(panss.tot, na.rm=T)
mean.genps<- mean(panss.gen, na.rm=T)
sd.genps<-sd(panss.gen, na.rm=T)
mean.posps<-mean(panss.pos, na.rm=T)
sd.posps<-sd(panss.pos, na.rm=T)
mean.negps<-mean(panss.neg, na.rm=T)
sd.negps<-sd(panss.neg, na.rm=T)
mean.func<-NA
sd.functioning<-NA
mean.qol<-NA
sd.qol<-NA

desc.cont<-c(mean.age,sd.age,mean.BMI,sd.BMI,mean.agediagnosis,sd.agediagnsosis,mean.doi,sd.doi,mean.cgi,sd.cgi,mean.totps,sd.totps,mean.genps,sd.genps,mean.posps,sd.posps,mean.negps,sd.negps,mean.func,sd.functioning,mean.qol,sd.qol)

desc.cont.mat<-rbind(colname.desc.cont,desc.cont)

mean.age.res<-mean(age.res, na.rm=T)
sd.age.res<-sd(age.res,na.rm=T)
mean.BMI.res<-mean(BMI.res,na.rm=T)
sd.BMI.res<-sd(BMI.res,na.rm=T)
mean.agediagnosis.res<-mean(age.diag.res, na.rm=T)
sd.agediagnsosis.res<-sd(age.diag.res,na.rm=T)
mean.doi.res<-mean(doi.res,na.rm=T)
sd.doi.res<-sd(doi.res,na.rm=T)
mean.cgi.res<-mean(cgi.res,na.rm=T)
sd.cgi.res<-sd(cgi.res,na.rm=T)
mean.totps.res<-mean(panss.tot.res,na.rm=T)
sd.totps.res<-sd(panss.tot.res, na.rm=T)
mean.genps.res<- mean(panss.gen.res, na.rm=T)
sd.genps.res<-sd(panss.gen.res, na.rm=T)
mean.posps.res<-mean(panss.pos.res, na.rm=T)
sd.posps.res<-sd(panss.pos.res, na.rm=T)
mean.negps.res<-mean(panss.neg.res, na.rm=T)
sd.negps.res<-sd(panss.neg.res, na.rm=T)
mean.func.res<-NA
sd.func.res<-NA
mean.qol.res<-NA
sd.qol.res<-NA

desc.cont.res<-c(mean.age.res,sd.age.res,mean.BMI.res,sd.BMI.res,mean.agediagnosis.res,sd.agediagnsosis.res,mean.doi.res,sd.doi.res,mean.cgi.res,sd.cgi.res,mean.totps.res,sd.totps.res,mean.genps.res,sd.genps.res,mean.posps.res,sd.posps.res,mean.negps.res,sd.negps.res,mean.func.res,sd.func.res,mean.qol.res,sd.qol.res)

desc.cont.mat.res<-rbind(colname.desc.cont,desc.cont.res)

mean.age.no.res<-mean(age.no.res, na.rm=T)
sd.age.no.res<-sd(age.no.res,na.rm=T)
mean.BMI.no.res<-mean(BMI.no.res,na.rm=T)
sd.BMI.no.res<-sd(BMI.no.res,na.rm=T)
mean.agediagnosis.no.res<-mean(age.diag.no.res, na.rm=T)
sd.agediagnsosis.no.res<-sd(age.diag.no.res,na.rm=T)
mean.doi.no.res<-mean(doi.no.res,na.rm=T)
sd.doi.no.res<-sd(doi.no.res,na.rm=T)
mean.cgi.no.res<-mean(cgi.no.res,na.rm=T)
sd.cgi.no.res<-sd(cgi.no.res,na.rm=T)
mean.totps.no.res<-mean(panss.tot.no.res,na.rm=T)
sd.totps.no.res<-sd(panss.tot.no.res, na.rm=T)
mean.genps.no.res<- mean(panss.gen.no.res, na.rm=T)
sd.genps.no.res<-sd(panss.gen.no.res, na.rm=T)
mean.posps.no.res<-mean(panss.pos.no.res, na.rm=T)
sd.posps.no.res<-sd(panss.pos.no.res, na.rm=T)
mean.negps.no.res<-mean(panss.neg.no.res, na.rm=T)
sd.negps.no.res<-sd(panss.neg.no.res, na.rm=T)
mean.func.no.res<-NA
sd.func.no.res<-NA
mean.qol.no.res<-NA
sd.qol.no.res<-NA

desc.cont.no.res<-c(mean.age.no.res,sd.age.no.res,mean.BMI.no.res,sd.BMI.no.res,mean.agediagnosis.no.res,sd.agediagnsosis.no.res,mean.doi.no.res,sd.doi.no.res,mean.cgi.no.res,sd.cgi.no.res,mean.totps.no.res,sd.totps.no.res,mean.genps.no.res,sd.genps.no.res,mean.posps.no.res,sd.posps.no.res,mean.negps.no.res,sd.negps.no.res,mean.func.no.res,sd.func.no.res,mean.qol.no.res,sd.qol.no.res)

desc.cont.mat.no.res<-rbind(colname.desc.cont,desc.cont.no.res)


colname.desc.cat<- c("Male (n)","Male (%)", "US (n)", "US (%)", "Family history (n)", "Family history (%)", "Smoking (n)", "Smoking (%)", "Drug use (n)", "Drug use (%)",">=3 prior hospitalizations(n)",">=3 prior hospitalizations (%)","Hospitalized in previous year (n)","Hospitalized in previous year (%)",">Moderate TD (n)",">Moderate TD (%)",">Moderate akathisia (n)",">Moderate akathisia (%)",">Moderate EPS (n)",">Moderate EPS (%)")

n.male<- length(sex[sex==1])
perc.male<-length(sex[sex==1])/length(sex)*100
n.us<- length(region[region==1])
perc.us<-length(region[region==1])/length(region)*100
n.fhx<- NA
perc.fhx<-NA
n.smok<- length(nicotine[nicotine==1])
perc.smok<-length(nicotine[nicotine==1])/length(nicotine)*100
n.drug<- NA
perc.drug<-NA
n.hosp.n<-NA
perc.hosp.n<-NA
n.hosp.t<-length(last.hosp[last.hosp==1])
perc.hosp.t<-length(last.hosp[last.hosp==1])/length(last.hosp)*100
n.td<-length(aims[aims==1])
perc.td<-length(aims[aims==1])/length(aims)*100
n.aka<-length(bars[bars==1])
perc.aka<-length(bars[bars==1])/length(bars)*100
n.eps<-length(eps[eps==1])
perc.eps<-length(eps[eps==1])/length(eps)*100

desc.cat<-c(n.male,perc.male,n.us,perc.us,n.fhx,perc.fhx,n.smok,perc.smok,n.drug,perc.drug,n.hosp.n,perc.hosp.n,n.hosp.t,perc.hosp.t,n.td,perc.td,n.aka,perc.aka,n.eps,perc.eps)

desc.cat.mat<-rbind(colname.desc.cat,desc.cat)

n.male.res<- length(sex.res[sex.res==1])
perc.male.res<-length(sex.res[sex.res==1])/length(sex.res)*100
n.us.res<- length(region.res[region.res==1])
perc.us.res<-length(region.res[region.res==1])/length(region.res)*100
n.fhx.res<- NA
perc.fhx.res<-NA
n.smok.res<- length(nicotine.res[nicotine.res==1])
perc.smok.res<-length(nicotine.res[nicotine.res==1])/length(nicotine.res)*100
n.drug.res<- NA
perc.drug.res<-NA
n.hosp.n.res<-NA
perc.hosp.n.res<-NA
n.hosp.t.res<-length(last.hosp.res[last.hosp.res==1])
perc.hosp.t.res<-length(last.hosp.res[last.hosp.res==1])/length(last.hosp.res)*100
n.td.res<-length(aims.res[aims.res==1])
perc.td.res<-length(aims.res[aims.res==1])/length(aims.res)*100
n.aka.res<-length(bars.res[bars.res==1])
perc.aka.res<-length(bars.res[bars.res==1])/length(bars.res)*100
n.eps.res<-length(eps.res[eps.res==1])
perc.eps.res<-length(eps.res[eps.res==1])/length(eps.res)*100

desc.cat.res<-c(n.male.res,perc.male.res,n.us.res,perc.us.res,n.fhx.res,perc.fhx.res,n.smok.res,perc.smok.res,n.drug.res,perc.drug.res,n.hosp.n.res,perc.hosp.n.res,n.hosp.t.res,perc.hosp.t.res,n.td.res,perc.td.res,n.aka.res,perc.aka.res,n.eps.res,perc.eps.res)

desc.cat.mat.res<-rbind(colname.desc.cat,desc.cat.res)

n.male.no.res<- length(sex.no.res[sex.no.res==1])
perc.male.no.res<-length(sex.no.res[sex.no.res==1])/length(sex.no.res)*100
n.us.no.res<- length(region.no.res[region.no.res==1])
perc.us.no.res<-length(region.no.res[region.no.res==1])/length(region.no.res)*100
n.fhx.no.res<- NA
perc.fhx.no.res<-NA
n.smok.no.res<- length(nicotine.no.res[nicotine.no.res==1])
perc.smok.no.res<-length(nicotine.no.res[nicotine.no.res==1])/length(nicotine.no.res)*100
n.drug.no.res<- NA
perc.drug.no.res<-NA
n.hosp.n.no.res<-NA
perc.hosp.n.no.res<-NA
n.hosp.t.no.res<-length(last.hosp.no.res[last.hosp.no.res==1])
perc.hosp.t.no.res<-length(last.hosp.no.res[last.hosp.no.res==1])/length(last.hosp.no.res)*100
n.td.no.res<-length(aims.no.res[aims.no.res==1])
perc.td.no.res<-length(aims.no.res[aims.no.res==1])/length(aims.no.res)*100
n.aka.no.res<-length(bars.no.res[bars.no.res==1])
perc.aka.no.res<-length(bars.no.res[bars.no.res==1])/length(bars.no.res)*100
n.eps.no.res<-length(eps.no.res[eps.no.res==1])
perc.eps.no.res<-length(eps.no.res[eps.no.res==1])/length(eps.no.res)*100

desc.cat.no.res<-c(n.male.no.res,perc.male.no.res,n.us.no.res,perc.us.no.res,n.fhx.no.res,perc.fhx.no.res,n.smok.no.res,perc.smok.no.res,n.drug.no.res,perc.drug.no.res,n.hosp.n.no.res,perc.hosp.n.no.res,n.hosp.t.no.res,perc.hosp.t.no.res,n.td.no.res,perc.td.no.res,n.aka.no.res,perc.aka.no.res,n.eps.no.res,perc.eps.no.res)

desc.cat.mat.no.res<-rbind(colname.desc.cat,desc.cat.no.res)


colname.outc<-c("Total sample 'n'", "Relapse 'n'", "Relapse '%'", "Median time to relapse 'days'", "Events per 100 patient - years")

n.total<-length(total.ids)
n.relapse<-length(status[status==1])
perc.relapse<-length(status[status==1])/length(status)*100
median.time<-median(time.to.event, na.rm=T)
py.inc

outc<-c(n.total,n.relapse,perc.relapse,median.time,py.inc)

outc.mat<-rbind(colname.outc,outc)

n.total.res<-length(response.ids)
n.relapse.res<-length(status.res[status.res==1])
perc.relapse.res<-length(status.res[status.res==1])/length(status.res)*100
median.time.res<-median(time.to.event.res, na.rm=T)
py.inc.res

outc.res<-c(n.total.res,n.relapse.res,perc.relapse.res,median.time.res,py.inc.res)

outc.mat.res<-rbind(colname.outc,outc.res)

n.total.no.res<-length(no.response.ids)
n.relapse.no.res<-length(status.no.res[status.no.res==1])
perc.relapse.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100
median.time.no.res<-median(time.to.event.no.res, na.rm=T)
py.inc.no.res

outc.no.res<-c(n.total.no.res,n.relapse.no.res,perc.relapse.no.res,median.time.no.res,py.inc.no.res)

outc.mat.no.res<-rbind(colname.outc,outc.no.res)


colname.HR<-c("Male gender HR","Male gender Lower 95% CI","Male gender Upper 95% CI","Age HR", "Age Lower 95% CI","Age	Upper 95% CI","Proportion US HR",
              "Proportion US Lower 95% CI","Proportion US Upper 95% CI","BMI HR",  "BMI Lower 95% CI","BMI Upper 95% CI", "Age at diagnosis HR",
              "Age at diagnosis Lower 95% CI","Age at diagnosis Upper 95% CI","Duration of illness HR","Duration of illness Lower 95% CI","Duration of illness Upper 95% CI",
              "Time since last hospitalization HR","Time since last hospitalization Lower 95% CI","Time since last hospitalization Upper 95% CI",
              "Number of previous hospitalizations HR","Number of previous hospitalizations Lower 95% CI","Number of previous hospitalizations Upper 95% CI",
              "Family history HR","Family history Lower 95% CI","Family history Upper 95% CI","Smoking HR","Smoking Lower 95% CI","Smoking Upper 95% CI",
              "Drug use HR","Drug use Lower 95% CI","Drug use Upper 95% CI","CGI HR","CGI Lower 95% CI","CGI Upper 95% CI","Psychopathology total score HR",
              "Psychopathology total score Lower 95% CI","Psychopathology total score Upper 95% CI","Psychopathology general score HR",
              "Psychopathology general score Lower 95% CI","Psychopathology general score Upper 95% CI","Psychopathology positive score HR",
              "Psychopathology positive score Lower 95% CI","Psychopathology positive score Upper 95% CI","Psychopathology negative score HR",
              "Psychopathology negative score Lower 95% CI","Psychopathology negative score Upper 95% CI","General functioning score HR", 
              "General functioning score Lower 95% CI","General functioning score Upper 95% CI", "Quality of life score HR",  "Quality of life score Lower 95% CI","Quality of life score Upper 95% CI","Tardive dyskinesia score HR","Tardive dyskinesia score Lower 95% CI","Tardive dyskinesia score Upper 95% CI","Akathisia score HR","Akathisia score Lower 95% CI","Akathisia score Upper 95% CI","Parkinsonism score HR","Parkinsonism score Lower 95% CI","Parkinsonism score Upper 95% CI")

hr<- cbind(
  hr.sex,low.lim.sex.hr,up.lim.sex.hr,
  hr.age,low.lim.age.hr,up.lim.age.hr,
  hr.reg,low.lim.reg.hr,up.lim.reg.hr,
  hr.bmi,low.lim.bmi.hr,up.lim.bmi.hr,
  hr.dia,low.lim.dia.hr,up.lim.dia.hr,
  hr.doi,low.lim.doi.hr,up.lim.doi.hr,
  hr.las,low.lim.las.hr,up.lim.las.hr,
  NA,NA,NA,
  NA,NA,NA,
  hr.nic,low.lim.nic.hr,up.lim.nic.hr,
  NA,NA,NA,
  hr.cgi,low.lim.cgi.hr,up.lim.cgi.hr,
  hr.tot,low.lim.tot.hr,up.lim.tot.hr,
  hr.gen,low.lim.gen.hr,up.lim.gen.hr,
  hr.pos,low.lim.pos.hr,up.lim.pos.hr,
  hr.neg,low.lim.neg.hr,up.lim.neg.hr,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim,low.lim.aim.hr,up.lim.aim.hr,
  hr.bar,low.lim.bar.hr,up.lim.bar.hr,
  hr.eps,low.lim.eps.hr,up.lim.eps.hr)

hr.mat<-rbind(colname.HR,hr)

hr.res<- cbind(
  hr.sex.res,low.lim.sex.hr.res,up.lim.sex.hr.res,
  hr.age.res,low.lim.age.hr.res,up.lim.age.hr.res,
  hr.reg.res,low.lim.reg.hr.res,up.lim.reg.hr.res,
  hr.bmi.res,low.lim.bmi.hr.res,up.lim.bmi.hr.res,
  hr.dia.res,low.lim.dia.hr.res,up.lim.dia.hr.res,
  hr.doi.res,low.lim.doi.hr.res,up.lim.doi.hr.res,
  hr.las.res,low.lim.las.hr.res,up.lim.las.hr.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.nic.res,low.lim.nic.hr.res,up.lim.nic.hr.res,
  NA,NA,NA,
  hr.cgi.res,low.lim.cgi.hr.res,up.lim.cgi.hr.res,
  hr.tot.res,low.lim.tot.hr.res,up.lim.tot.hr.res,
  hr.gen.res,low.lim.gen.hr.res,up.lim.gen.hr.res,
  hr.pos.res,low.lim.pos.hr.res,up.lim.pos.hr.res,
  hr.neg.res,low.lim.neg.hr.res,up.lim.neg.hr.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim.res,low.lim.aim.hr.res,up.lim.aim.hr.res,
  hr.bar.res,low.lim.bar.hr.res,up.lim.bar.hr.res,
  hr.eps.res,low.lim.eps.hr.res,up.lim.eps.hr.res)

hr.mat.res<-rbind(colname.HR,hr.res)

hr.no.res<- cbind(
  hr.sex.no.res,low.lim.sex.hr.no.res,up.lim.sex.hr.no.res,
  hr.age.no.res,low.lim.age.hr.no.res,up.lim.age.hr.no.res,
  hr.reg.no.res,low.lim.reg.hr.no.res,up.lim.reg.hr.no.res,
  hr.bmi.no.res,low.lim.bmi.hr.no.res,up.lim.bmi.hr.no.res,
  hr.dia.no.res,low.lim.dia.hr.no.res,up.lim.dia.hr.no.res,
  hr.doi.no.res,low.lim.doi.hr.no.res,up.lim.doi.hr.no.res,
  hr.las.no.res,low.lim.las.hr.no.res,up.lim.las.hr.no.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.nic.no.res,low.lim.nic.hr.no.res,up.lim.nic.hr.no.res,
  NA,NA,NA,
  hr.cgi.no.res,low.lim.cgi.hr.no.res,up.lim.cgi.hr.no.res,
  hr.tot.no.res,low.lim.tot.hr.no.res,up.lim.tot.hr.no.res,
  hr.gen.no.res,low.lim.gen.hr.no.res,up.lim.gen.hr.no.res,
  hr.pos.no.res,low.lim.pos.hr.no.res,up.lim.pos.hr.no.res,
  hr.neg.no.res,low.lim.neg.hr.no.res,up.lim.neg.hr.no.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim.no.res,low.lim.aim.hr.no.res,up.lim.aim.hr.no.res,
  hr.bar.no.res,low.lim.bar.hr.no.res,up.lim.bar.hr.no.res,
  hr.eps.no.res,low.lim.eps.hr.no.res,up.lim.eps.hr.no.res)

hr.mat.no.res<-rbind(colname.HR,hr.no.res)

hr.int<- cbind(
  ci.int.sex[1],ci.int.sex[2],ci.int.sex[3],
  ci.int.age[1],ci.int.age[2],ci.int.age[3],
  ci.int.reg[1],ci.int.reg[2],ci.int.reg[3],
  ci.int.bmi[1],ci.int.bmi[2],ci.int.bmi[3],
  ci.int.age.diag[1],ci.int.age.diag[2],ci.int.age.diag[3],
  ci.int.doi[1],ci.int.doi[2],ci.int.doi[3],
  ci.int.last.hosp[1],ci.int.last.hosp[2],ci.int.last.hosp[3],
  NA,NA,NA,
  NA,NA,NA,
  ci.int.nicotine[1],ci.int.nicotine[2],ci.int.nicotine[3],
  NA,NA,NA,
  ci.int.cgi[1],ci.int.cgi[2],ci.int.cgi[3],
  ci.int.panss.tot[1],ci.int.panss.tot[2],ci.int.panss.tot[3],
  ci.int.panss.gen[1],ci.int.panss.gen[2],ci.int.panss.gen[3],
  ci.int.panss.pos[1],ci.int.panss.pos[2],ci.int.panss.pos[3],
  ci.int.panss.neg[1],ci.int.panss.neg[2],ci.int.panss.neg[3],
  NA,NA,NA,
  NA,NA,NA,
  ci.int.aims[1],ci.int.aims[2],ci.int.aims[3],
  ci.int.bars[1],ci.int.bars[2],ci.int.bars[3],
  ci.int.eps[1],ci.int.eps[2],ci.int.eps[3])

hr.int.mat<-rbind(colname.HR,hr.int)

hr.int.seiyi<-cbind(
  sei.int.sex[1],sei.int.sex[2],
  sei.int.age[1],sei.int.age[2],
  sei.int.reg[1],sei.int.reg[2],
  sei.int.bmi[1],sei.int.bmi[2],
  sei.int.age.diag[1],sei.int.age.diag[2],
  sei.int.doi[1],sei.int.doi[2],
  sei.int.last.hosp[1],sei.int.last.hosp[2],
  NA,NA,
  NA,NA,
  sei.int.nicotine[1],sei.int.nicotine[2],
  NA,NA,
  sei.int.cgi[1],sei.int.cgi[2],
  sei.int.panss.tot[1],sei.int.panss.tot[2],
  sei.int.panss.gen[1],sei.int.panss.gen[2],
  sei.int.panss.pos[1],sei.int.panss.pos[2],
  sei.int.panss.neg[1],sei.int.panss.neg[2],
  NA,NA,
  NA,NA,
  sei.int.aims[1],sei.int.aims[2],
  sei.int.bars[1],sei.int.bars[2],
  sei.int.eps[1],sei.int.eps[2])

hr.nores.seiyi<-cbind(
  sei.sex[1],sei.sex[2],
  sei.age[1],sei.age[2],
  sei.reg[1],sei.reg[2],
  sei.bmi[1],sei.bmi[2],
  sei.age.diag[1],sei.age.diag[2],
  sei.doi[1],sei.doi[2],
  sei.last.hosp[1],sei.last.hosp[2],
  NA,NA,
  NA,NA,
  sei.nicotine[1],sei.nicotine[2],
  NA,NA,NA,
  sei.cgi[1],sei.cgi[2],
  sei.panss.tot[1],sei.panss.tot[2],
  sei.panss.gen[1],sei.panss.gen[2],
  sei.panss.pos[1],sei.panss.pos[2],
  sei.panss.neg[1],sei.panss.neg[2],
  NA,NA,
  NA,NA,
  sei.aims[1],sei.aims[2],
  sei.bars[1],sei.bars[2],
  sei.eps[1],sei.eps[2])

surv.obj <- Surv(time.to.event/7, status)
surv.obj.res <- Surv(time.to.event.res/7, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res/7, status.no.res)

survfit(surv.obj~1)
survfit(surv.obj.no.res~1)
survfit(surv.obj.res~1)

study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)

xx<-study1.surv.fit
xx.no.res<-study1.surv.fit.no.res
xx.res<-study1.surv.fit.res

xx.t<-xx[[2]]
xx.p<-xx[[6]]

xx.t.res<-xx.res[[2]]
xx.p.res<-xx.res[[6]]

xx.t.no.res<-xx.no.res[[2]]
xx.p.no.res<-xx.no.res[[6]]

surv.mat<-cbind(xx.t,xx.p)
surv.mat.res<-cbind(xx.t.res,xx.p.res)
surv.mat.no.res<-cbind(xx.t.no.res,xx.p.no.res)

write.table(surv.mat,file="X:/Workspace/Results/surv_3005-75_V2.csv",sep=",")
write.table(surv.mat.res,file="X:/Workspace/Results/surv_3005-75_res_V2.csv",sep=",")
write.table(surv.mat.no.res,file="X:/Workspace/Results/surv_3005-75_no.res_V2.csv",sep=",")

write.table(desc.cont.mat,file="X:/Workspace/Results/desc_cont_3005-75_V2.csv",sep=",")
write.table(desc.cont.mat.res,file="X:/Workspace/Results/desc_cont_3005-75_res_V2.csv",sep=",")
write.table(desc.cont.mat.no.res,file="X:/Workspace/Results/desc_cont_3005-75_no.res_V2.csv",sep=",")

write.table(desc.cat.mat,file="X:/Workspace/Results/desc_cat_3005-75_V2.csv",sep=",")
write.table(desc.cat.mat.res,file="X:/Workspace/Results/desc_cat_3005-75_res_V2.csv",sep=",")
write.table(desc.cat.mat.no.res,file="X:/Workspace/Results/desc_cat_3005-75_no.res_V2.csv",sep=",")

write.table(outc.mat,file="X:/Workspace/Results/outc_3005-75_V2.csv",sep=",")
write.table(outc.mat.res,file="X:/Workspace/Results/outc_3005-75_res_V2.csv",sep=",")
write.table(outc.mat.no.res,file="X:/Workspace/Results/outc_3005-75_no.res_V2.csv",sep=",")

write.table(hr.mat,file="X:/Workspace/Results/hr_3005-75_V2.csv",sep=",")
write.table(hr.mat.res,file="X:/Workspace/Results/hr_3005-75_res_V2.csv",sep=",")
write.table(hr.mat.no.res,file="X:/Workspace/Results/hr_3005-75_no.res_V2.csv",sep=",")
write.table(hr.int.mat,file="X:/Workspace/Results/hr.int_3005-75_v2.csv",sep=",")

write.table(hr.int.seiyi,file="X:/Workspace/Results/hr.int.seiyi_3005-75_v2.csv",sep=",")
write.table(hr.nores.seiyi,file="X:/Workspace/Results/hr.nores.seiyi_3005-75_v2.csv",sep=",")

#code to calculate the relapse criteria met
#All relapses were for "lack of efficacy"

#code to compare functioning between relapsers and non-relapsers
#No functioning data
