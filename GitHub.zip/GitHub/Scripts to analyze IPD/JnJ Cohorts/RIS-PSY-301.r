##RIS-PSY-301
# Authored: Jose M Rubio M.D // jrubio13@northwell.edu
# Checked: George Schoretsanitis M.D.,PhD
# April 7th 2020

###COHORT JnJ-RIS-PSY-301
#################################
### a function to match and merge variables from two datasets

match.and.merge.func <- function(dat1.id, dat2.id, dat2.var){
  dat1.var <- array(,length(dat1.id)) 
  for(i in 1:length(dat1.id)){
    for(j in 1:length(dat2.id)){
      if(dat1.id[i] == dat2.id[j]){ dat1.var[i] <- dat2.var[j] }}}
  return(dat1.var)                                       }

##########IDENTIFY TOTAL DATASET
#FOLLOWED FOR SUFFICIENT TIME TO HAVE A THERAPEUTIC PLASMA LEVEL (>4 WEEKs FOR RIS)

visit.dat <- read.table("X:/Data/JnJ-RIS-PSY-301-csv/Data/visittot.csv", header = TRUE, sep = ",")
visit.dat.id.u <- unique(visit.dat$DCRFID) 

exclude.ind <- array(0, length(visit.dat.id.u)) 

for(i in 1:length(visit.dat.id.u)){
  visitdy.temp <- visit.dat$VISIT_DY[visit.dat$DCRFID == visit.dat.id.u[i]] 
  visitdy.temp.max <- max(visitdy.temp, na.rm = T)
  if(visitdy.temp.max <= 28){ exclude.ind[i] <- 1 } }

visit.ids<-visit.dat.id.u[exclude.ind==0]

#patients were followed after relapse, so we need to exclude those whose relapse occurred prior to d84.
#this info in relapse.dat 

relapse.dat<-read.csv("X:/Data/JnJ-RIS-PSY-301-csv/Data/relapsetot.csv", header = TRUE, sep = ",")
relapse.id.u<-unique(relapse.dat$DCRFID)
time.rel<-relapse.dat$RELAPSE_DY

excl.rel<-array(0,length(relapse.id.u))
for(i in 1:length(relapse.id.u)){
  visitdy.temp <- time.rel[relapse.dat$DCRFID == relapse.id.u[i]]
  visitdy.temp[is.na(visitdy.temp)]<-99
  visitdy.temp.min <- min(visitdy.temp, na.rm = T)
  if(visitdy.temp.min <= 28){ excl.rel[i] <- 1 } }
rel.ids<-relapse.id.u[excl.rel==0]

total.ids<-intersect(visit.ids,rel.ids)

##########IDENTIFY 'REMISSION' DATASET 
##IF PTS STABLE UPON ENTRY --> FIRST 2 VISITS WITH LESS THAN MILD ON POSITIVE SYMPTOMS) [THESE WILL BE LABELLED AS .RES, ALTHOUGH IN FACT ARE REMITTERS]
##IF PTS NOT STABLE UPON ENTRY xxx--> FIRST 2 VISITS AFTER WEEK 6 WITH LESS THAN MILD ON POSITIVE SYMPTOMS) [THESE WILL BE LABELLED AS .RES, ALTHOUGH IN FACT ARE REMITTERS]

panss.dat<-read.csv("X:/Data/JnJ-RIS-PSY-301-csv/Data/pansstot.csv", header = TRUE, sep = ",")
visit<-as.character(panss.dat$VISITID)

panss.dat.res7 <- panss.dat[visit=="Visit 6",]
ids.u.7<-unique(panss.dat.res7$DCRFID)

panss.res.id7<-array(0,length(ids.u.7))

for(i in 1:length(ids.u.7)){
  temp.array1<-c(panss.dat.res7$P1,panss.dat.res7$P2,panss.dat.res7$P3,panss.dat.res7$P4,panss.dat.res7$P5,panss.dat.res7$P6,panss.dat.res7$P7)[panss.dat.res7$DCRFID==ids.u.7[i]]
  max.sc.rs<-max(temp.array1, na.rm=TRUE)
  if(max.sc.rs<4){panss.res.id7[i]<-1}} #6/21

response.ids7<-ids.u.7[panss.res.id7==1]

panss.dat.res8 <- panss.dat[visit=="Visit 7",]
ids.u.8<-unique(panss.dat.res8$DCRFID)

panss.res.id8<-array(0,length(ids.u.8))

for(i in 1:length(ids.u.8)){
  temp.array1<-c(panss.dat.res8$P1,panss.dat.res8$P2,panss.dat.res8$P3,panss.dat.res8$P4,panss.dat.res8$P5,panss.dat.res8$P6,panss.dat.res8$P7)[panss.dat.res8$DCRFID==ids.u.8[i]]
  max.sc.rs<-max(temp.array1, na.rm=TRUE)
  if(max.sc.rs<4){panss.res.id8[i]<-1}} #ok

response.ids8<-ids.u.8[panss.res.id8==1]

response.ids.temp<-intersect(response.ids7,response.ids8)
response.ids<-intersect(response.ids.temp,total.ids) #ok
no.response.ids<-setdiff(total.ids,response.ids) 


########DEFINE STATUS PER DATASET (1=event; 0=censor)
relapse.dat<-read.csv("X:/Data/JnJ-RIS-PSY-301-csv/Data/relapsetot.csv", header = TRUE, sep = ",")
relapse.temp<-as.character(relapse.dat$RELAPSE)
relapse.temp[relapse.temp=="Yes"]<-1
relapse.temp[relapse.temp=="No"]<-0
relapse<-as.numeric(relapse.temp)
relapse.id.u<-unique(relapse.dat$DCRFID)

status.t<-array(0,length(relapse.id.u))
for(i in 1:length(relapse.id.u)){
  temp<-relapse[relapse.dat$DCRFID==relapse.id.u[i]]
  rel<-max(temp, na.rm=T)
  if(rel==1){status.t[i]<-1}}

status<-match.and.merge.func(total.ids, relapse.id.u,status.t) #ok

status.res<-match.and.merge.func(response.ids,relapse.id.u,status.t) #ok

status.no.res<-match.and.merge.func(no.response.ids,relapse.id.u,status.t) #ok

######DEFINE TIME TO EVENT PER DATASET 
#take the value from the relapse.dat if there was relapse, if it was 0 then take it from visit.dat

relapse.dat<-read.csv("X:/Data/JnJ-RIS-PSY-301-csv/Data/relapsetot.csv", header = TRUE, sep = ",")
relapse.id.u<-unique(relapse.dat$DCRFID)
time.rel<-relapse.dat$RELAPSE_DY

time.to<-array(,length(relapse.id.u))
for(i in 1:length(relapse.id.u)){
  temp<-time.rel[relapse.dat$DCRFID==relapse.id.u[i]]
  temp[is.na(temp)]<-0
  rel<-max(temp, na.rm=T)
  time.to[i]<-rel}

# this gives a number only if there was a relapse, now we have to replace w the 
#last visit number if there was no relapse

visit.dat <- read.table("X:/Data/JnJ-RIS-PSY-301-csv/Data/visittot.csv", header = TRUE, sep = ",")
visit.id.u <- unique(visit.dat$DCRFID) 
time.vis<-visit.dat$VISIT_DY

for(i in 1:length(visit.id.u)){
  temp1<-time.vis[visit.dat$DCRFID==visit.id.u[i]]
  temp2<-max(temp1, na.rm=T)
  for(j in 1:length(relapse.id.u)){
    if(visit.id.u[i] == relapse.id.u[j]){
      if(time.to[j]==0){time.to[j]<-temp2}}}} 

time.to.event<-match.and.merge.func(total.ids, relapse.id.u,time.to)

time.to.event.res<-match.and.merge.func(response.ids,relapse.id.u,time.to)

time.to.event.no.res<-match.and.merge.func(no.response.ids,relapse.id.u,time.to)

rem.stat<-array(0,length(total.ids))
for(i in 1:length(total.ids)){
  for(j in 1:length(response.ids)){
    if(total.ids[i]==response.ids[j]){
      rem.stat[i]<-1}
  }
}

#SURVIVAL ANALYSIS

library(survival)
surv.obj <- Surv(time.to.event, status)
surv.obj.res <- Surv(time.to.event.res, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res, status.no.res)
survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)
study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)
##CALCULATE PERSON YEARS AND ABSOLUTE AND PERSON X YEAR INCIDENCE RATE
#person-year
per.year<-sum(time.to.event, na.rm=T)/365
per.year.res<-sum(time.to.event.res, na.rm=T)/365
per.year.no.res<-sum(time.to.event.no.res, na.rm=T)/365

#absolute incidence
abs.inc<-length(status[status==1])/length(status)*100 
abs.inc.res<-length(status.res[status.res==1])/length(status.res)*100
abs.inc.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100

#person-year incidence

py.inc<-length(status[status==1])/per.year*100 
py.inc.res<-length(status.res[status.res==1])/per.year.res*100  #
py.inc.no.res<-length(status.no.res[status.no.res==1])/per.year.no.res*100  #

#############COVARIATES

demog.dat <- read.table("X:/Data/JnJ-RIS-PSY-301-csv/Data/acrftot.csv", header = TRUE, sep = ",")

sex.1<-as.character(demog.dat$GENDER)
sex.1[sex.1=="Female"]<-0
sex.1[sex.1=="Male"]<-1
sex.1<-as.numeric(sex.1)

sex  <- match.and.merge.func(total.ids, demog.dat$DCRFID, sex.1) # ok
sex.res <- match.and.merge.func(response.ids, demog.dat$DCRFID, sex.1)
sex.no.res <- match.and.merge.func(no.response.ids, demog.dat$DCRFID, sex.1)
age  <- match.and.merge.func(total.ids, demog.dat$DCRFID, demog.dat$AGE) # ok
age.res <- match.and.merge.func(response.ids, demog.dat$DCRFID, demog.dat$AGE)
age.no.res <- match.and.merge.func(no.response.ids, demog.dat$DCRFID, demog.dat$AGE)

#all of these subjects were recruited in South Africa
region <- array(0,length(total.ids))
region.res <- array(0,length(response.ids))
region.no.res <- array(0,length(no.response.ids))

visit.dat <- read.table("X:/Data/JnJ-RIS-PSY-301-csv/Data/visittot.csv", header = TRUE, sep = ",")
visit.dat.bl<- visit.dat[visit.dat$VISITID=="Visit 2",]
visit.id.u.bl <- unique(visit.dat.bl$DCRFID)

height  <- match.and.merge.func(total.ids, visit.id.u.bl, visit.dat.bl$HEIGHT) # ok
height.res <- match.and.merge.func(response.ids, visit.id.u.bl, visit.dat.bl$HEIGHT)
height.no.res <- match.and.merge.func(no.response.ids, visit.id.u.bl, visit.dat.bl$HEIGHT)

weight  <- match.and.merge.func(total.ids, visit.id.u.bl, visit.dat.bl$WEIGHT) # ok
weight.res <- match.and.merge.func(response.ids, visit.id.u.bl, visit.dat.bl$WEIGHT)
weight.no.res <- match.and.merge.func(no.response.ids, visit.id.u.bl, visit.dat.bl$WEIGHT)

BMI<-weight/(height/100)^2  #ok
BMI.res<-weight.res/(height.res/100)^2  #ok
BMI.no.res<-weight.no.res/(height.no.res/100)^2  # ok

#for EPS we are using ESRS instead of AIMS,BARS,SARS. For simplicity we will use 
#variable names as: AIMS, BARS, SARS, but later analyze as separate measure in MA

esrs.dat <- read.table("X:/Data/JnJ-RIS-PSY-301-csv/Data/esrstot.csv", header = TRUE, sep = ",")
esrs.dat.bl<- esrs.dat[esrs.dat$VISITID=="Visit 2",]
esrs.id.u<-unique(esrs.dat.bl$DCRFID)

akath<-esrs.dat.bl$A16
akath[akath<=1]<-0
akath[akath>1]<-1
td<-esrs.dat.bl$CGIDYSKINESIA
td[td<=1]<-0
td[td>1]<-1
eps.1<-esrs.dat.bl$CGIPARK
eps.1[eps.1<=1]<-0
eps.1[eps.1>1]<-1

aims <- match.and.merge.func(total.ids, esrs.id.u, td) # ok
aims.res <- match.and.merge.func(response.ids, esrs.id.u, td) # ok
aims.no.res <- match.and.merge.func(no.response.ids, esrs.id.u, td) # ok

bars<- match.and.merge.func(total.ids, esrs.id.u,akath) #ok   
bars.res<- match.and.merge.func(response.ids, esrs.id.u,akath) # ok  
bars.no.res<- match.and.merge.func(no.response.ids, esrs.id.u,akath) # ok  

eps <- match.and.merge.func(total.ids, esrs.id.u, eps.1)# ok
eps.res <- match.and.merge.func(response.ids,esrs.id.u, eps.1)# ok
eps.no.res <- match.and.merge.func(no.response.ids,esrs.id.u, eps.1)# ok

cgi.dat <- read.table("X:/Data/JnJ-RIS-PSY-301-csv/Data/cgitot.csv", header = TRUE, sep = ",")
cgi.dat.bl<- cgi.dat[cgi.dat$VISITID=="Visit 2",]
cgi.id.u<-unique(cgi.dat.bl$DCRFID)

cgi.bl<-cgi.dat.bl$Q1

cgi <- match.and.merge.func(total.ids, cgi.id.u, cgi.bl)# ok
cgi.res <- match.and.merge.func(response.ids,cgi.id.u, cgi.bl)# ok	
cgi.no.res <- match.and.merge.func(no.response.ids,cgi.id.u, cgi.bl)# ok	

age.diag  <- match.and.merge.func(total.ids, demog.dat$DCRFID, demog.dat$AGE) #these are all FEP so age.diag and age are the same
age.diag.res <- match.and.merge.func(response.ids, demog.dat$DCRFID, demog.dat$AGE)
age.diag.no.res <- match.and.merge.func(no.response.ids, demog.dat$DCRFID, demog.dat$AGE)

doi<-age-age.diag #ok
doi.res<-age.res-age.diag.res #ok
doi.no.res<-age.no.res-age.diag.no.res #ok

panss.dat.t<-read.csv("X:/Data/JnJ-RIS-PSY-301-csv/Data/pansstot.csv", header = TRUE, sep = ",")
visit<-as.character(panss.dat.t$VISITID)
panss.dat <- panss.dat.t[visit=="Visit 2",]
panss.id.u<- unique(panss.dat$DCRFID)

panss.gen1<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array1<-c(panss.dat$G1,panss.dat$G2,panss.dat$G3,panss.dat$G4,
                 panss.dat$G5,panss.dat$G6,panss.dat$G7,panss.dat$G8,panss.dat$G9,
                 panss.dat$G10,panss.dat$G11, panss.dat$G12,panss.dat$G13,panss.dat$G14,
                 panss.dat$G15,panss.dat$G16)[panss.dat$DCRFID==panss.id.u[i]]
  panss.gen1[i]<-sum(temp.array1,na.rm=T)
}

panss.gen <- match.and.merge.func(total.ids, panss.id.u, panss.gen1)#ok
panss.gen.res <- match.and.merge.func(response.ids, panss.id.u, panss.gen1)#ok
panss.gen.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.gen1)#ok

panss.pos1<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array1<-c(panss.dat$P1,panss.dat$P2,
                 panss.dat$P3,panss.dat$P4,panss.dat$P5,panss.dat$P6,panss.dat$P7)[panss.dat$DCRFID==panss.id.u[i]]
  panss.pos1[i]<-sum(temp.array1,na.rm=T)
}

panss.pos <- match.and.merge.func(total.ids, panss.id.u, panss.pos1)# ok
panss.pos.res <- match.and.merge.func(response.ids, panss.id.u, panss.pos1)# ok
panss.pos.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.pos1)# ok

panss.neg1<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  temp.array1<-c(panss.dat$N1,panss.dat$N2,
                 panss.dat$N3,panss.dat$N4,panss.dat$N5,panss.dat$N6,panss.dat$N7)[panss.dat$DCRFID==panss.id.u[i]]
  panss.neg1[i]<-sum(temp.array1,na.rm=T)
}

panss.neg <- match.and.merge.func(total.ids, panss.id.u, panss.neg1)# ok
panss.neg.res <- match.and.merge.func(response.ids, panss.id.u, panss.neg1)#ok
panss.neg.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.neg1)#ok

panss.tot<-panss.gen+panss.pos+panss.neg # ok
panss.tot.res<-panss.gen.res+panss.pos.res+panss.neg.res # ok
panss.tot.no.res<-panss.gen.no.res+panss.pos.no.res+panss.neg.no.res # ok

visit.dat <- read.table("X:/Data/JnJ-RIS-PSY-301-csv/Data/visittot.csv", header = TRUE, sep = ",")
visit.dat.bl<- visit.dat[visit.dat$VISITID=="Visit 2",]
visit.id.u.bl <- unique(visit.dat.bl$DCRFID) 

#again, for simplicity we are naming this variable "psp.1", but it refers to 
#functioning as in the SOFAS rating scale, not PSP

psp.bl<-visit.dat.bl$SOFAS

functioning <- match.and.merge.func(total.ids, visit.id.u.bl, psp.bl)# ok
functioning.res <- match.and.merge.func(response.ids, visit.id.u.bl, psp.bl)# ok
functioning.no.res <- match.and.merge.func(no.response.ids, visit.id.u.bl, psp.bl)# ok

#this is a FEP sample w/o prior hosp

num.prev.hosp <- array(0,length(total.ids))#ok
num.prev.hosp.res <- array(0,length(response.ids))#ok
num.prev.hosp.no.res <- array(0,length(response.ids))#ok

##COX REGRESSION

coxph(formula = surv.obj ~sex )
coxph(formula = surv.obj.res ~sex.res )
coxph(formula = surv.obj.no.res ~sex.no.res )
coxph(formula = surv.obj ~age )
coxph(formula = surv.obj.res ~age.res )
coxph(formula = surv.obj.no.res ~age.no.res )
coxph(formula = surv.obj ~BMI)
coxph(formula = surv.obj.res ~BMI.res)
coxph(formula = surv.obj.no.res ~BMI.no.res)
coxph(formula = surv.obj ~aims )
coxph(formula = surv.obj.res ~aims.res )
coxph(formula = surv.obj.no.res ~aims.no.res )	 
coxph(formula = surv.obj ~bars)
coxph(formula = surv.obj.res ~bars.res )
coxph(formula = surv.obj.no.res ~bars.no.res )	
coxph(formula = surv.obj ~cgi )
coxph(formula = surv.obj.res ~cgi.res )
coxph(formula = surv.obj.no.res ~cgi.no.res ) 
coxph(formula = surv.obj ~panss.gen )
coxph(formula = surv.obj.res ~panss.gen.res)  
coxph(formula = surv.obj.no.res ~panss.gen.no.res)   
coxph(formula = surv.obj ~panss.neg) 
coxph(formula = surv.obj.res ~panss.neg.res) 
coxph(formula = surv.obj.no.res ~panss.neg.no.res)
coxph(formula = surv.obj ~panss.pos) 
coxph(formula = surv.obj.res ~panss.pos.res) 
coxph(formula = surv.obj.no.res ~panss.pos.no.res)
coxph(formula = surv.obj ~panss.tot)
coxph(formula = surv.obj.res ~panss.tot.res)
coxph(formula = surv.obj.no.res ~panss.tot.no.res)	 
coxph(formula = surv.obj ~functioning) 
coxph(formula = surv.obj.res ~functioning.res)  
coxph(formula = surv.obj.no.res ~functioning.no.res)	 
coxph(formula = surv.obj ~eps) 
coxph(formula = surv.obj.res ~eps.res) 
coxph(formula = surv.obj.no.res ~eps.no.res) 


ci.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex))[8])[c(3,9,12)]
ci.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age))[8])[c(3,9,12)]
ci.int.bmi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[8])[c(3,9,12)]
ci.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims))[8])[c(3,9,12)]
ci.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars))[8])[c(3,9,12)]
ci.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi))[8])[c(3,9,12)]
ci.int.panss.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot))[8])[c(3,9,12)]
ci.int.panss.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen))[8])[c(3,9,12)]
ci.int.panss.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos))[8])[c(3,9,12)]
ci.int.panss.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg))[8])[c(3,9,12)]
ci.int.functioning<-unlist(summary(coxph(formula = surv.obj ~rem.stat*functioning))[8])[c(3,9,12)]
ci.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps))[8])[c(3,9,12)]

#logHR and logSE for interaction terms
sei.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex))[7])[c(3,9)]
sei.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age))[7])[c(3,9)]
sei.int.bmi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[7])[c(3,9)]
sei.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims))[7])[c(3,9)]
sei.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars))[7])[c(3,9)]
sei.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi))[7])[c(3,9)]
sei.int.panss.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot))[7])[c(3,9)]
sei.int.panss.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen))[7])[c(3,9)]
sei.int.panss.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos))[7])[c(3,9)]
sei.int.panss.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg))[7])[c(3,9)]
sei.int.functioning<-unlist(summary(coxph(formula = surv.obj ~rem.stat*functioning))[7])[c(3,9)]
sei.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps))[7])[c(3,9)]

#logHR and logSE for Cox of no.remission.ids (total.ids and remission.ids, had already been calculated from CIs on previous run of analyses)
sei.sex<-unlist(summary(coxph(formula = surv.obj.no.res ~sex.no.res))[7])[c(1,3)]
sei.age<-unlist(summary(coxph(formula = surv.obj.no.res ~age.no.res))[7])[c(1,3)]
sei.bmi<-unlist(summary(coxph(formula = surv.obj.no.res ~BMI.no.res))[7])[c(1,3)]
sei.aims<-unlist(summary(coxph(formula = surv.obj.no.res ~aims.no.res))[7])[c(1,3)]
sei.bars<-unlist(summary(coxph(formula = surv.obj.no.res ~bars.no.res))[7])[c(1,3)]
sei.cgi<-unlist(summary(coxph(formula = surv.obj.no.res ~cgi.no.res))[7])[c(1,3)]
sei.panss.tot<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.tot.no.res))[7])[c(1,3)]
sei.panss.gen<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.gen.no.res))[7])[c(1,3)]
sei.panss.pos<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.pos.no.res))[7])[c(1,3)]
sei.panss.neg<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.neg.no.res))[7])[c(1,3)]
sei.functioning<-unlist(summary(coxph(formula = surv.obj.no.res ~functioning.no.res))[7])[c(1,3)]
sei.eps<-unlist(summary(coxph(formula = surv.obj.no.res ~eps.no.res))[7])[c(1,3)]


######CALCULATE HR AND 95%CI

sex.hr<-coxph(formula = surv.obj ~sex )
sex.hr.res<-coxph(formula = surv.obj.res ~sex.res )

se.sex.hr<-sqrt(sex.hr[[2]])
beta.sex.hr<-sex.hr[[1]]

up.lim.sex.hr<-exp(beta.sex.hr+(1.96*se.sex.hr))
low.lim.sex.hr<-exp(beta.sex.hr-(1.96*se.sex.hr))
hr.sex<-exp(beta.sex.hr)

se.sex.hr.res<-sqrt(sex.hr.res[[2]])
beta.sex.hr.res<-sex.hr.res[[1]]

up.lim.sex.hr.res<-exp(beta.sex.hr.res+(1.96*se.sex.hr.res))
low.lim.sex.hr.res<-exp(beta.sex.hr.res-(1.96*se.sex.hr.res))
hr.sex.res<-exp(beta.sex.hr.res)

age.hr<-coxph(formula = surv.obj ~age )
age.hr.res<-coxph(formula = surv.obj.res ~age.res )

se.age.hr<-sqrt(age.hr[[2]])
beta.age.hr<-age.hr[[1]]

up.lim.age.hr<-exp(beta.age.hr+(1.96*se.age.hr))
low.lim.age.hr<-exp(beta.age.hr-(1.96*se.age.hr))
hr.age<-exp(beta.age.hr)

se.age.hr.res<-sqrt(age.hr.res[[2]])
beta.age.hr.res<-age.hr.res[[1]]

up.lim.age.hr.res<-exp(beta.age.hr.res+(1.96*se.age.hr.res))
low.lim.age.hr.res<-exp(beta.age.hr.res-(1.96*se.age.hr.res))
hr.age.res<-exp(beta.age.hr.res)

bmi.hr<-coxph(formula = surv.obj ~BMI)
bmi.hr.res<-coxph(formula = surv.obj.res ~BMI.res)

se.bmi.hr<-sqrt(bmi.hr[[2]])
beta.bmi.hr<-bmi.hr[[1]]

up.lim.bmi.hr<-exp(beta.bmi.hr+(1.96*se.bmi.hr))
low.lim.bmi.hr<-exp(beta.bmi.hr-(1.96*se.bmi.hr))
hr.bmi<-exp(beta.bmi.hr)

se.bmi.hr.res<-sqrt(bmi.hr.res[[2]])
beta.bmi.hr.res<-bmi.hr.res[[1]]

up.lim.bmi.hr.res<-exp(beta.bmi.hr.res+(1.96*se.bmi.hr.res))
low.lim.bmi.hr.res<-exp(beta.bmi.hr.res-(1.96*se.bmi.hr.res))
hr.bmi.res<-exp(beta.bmi.hr.res)

aim.hr<-coxph(formula = surv.obj ~aims )
aim.hr.res<-coxph(formula = surv.obj.res ~aims.res )

se.aim.hr<-sqrt(aim.hr[[2]])
beta.aim.hr<-aim.hr[[1]]

up.lim.aim.hr<-exp(beta.aim.hr+(1.96*se.aim.hr))
low.lim.aim.hr<-exp(beta.aim.hr-(1.96*se.aim.hr))
hr.aim<-exp(beta.aim.hr)

se.aim.hr.res<-sqrt(aim.hr.res[[2]])
beta.aim.hr.res<-aim.hr.res[[1]]

up.lim.aim.hr.res<-exp(beta.aim.hr.res+(1.96*se.aim.hr.res))
low.lim.aim.hr.res<-exp(beta.aim.hr.res-(1.96*se.aim.hr.res))
hr.aim.res<-exp(beta.aim.hr.res)	

bar.hr<-coxph(formula = surv.obj ~bars)
bar.hr.res<-coxph(formula = surv.obj.res ~bars.res )	 

se.bar.hr<-sqrt(bar.hr[[2]])
beta.bar.hr<-bar.hr[[1]]

up.lim.bar.hr<-exp(beta.bar.hr+(1.96*se.bar.hr))
low.lim.bar.hr<-exp(beta.bar.hr-(1.96*se.bar.hr))
hr.bar<-exp(beta.bar.hr)

se.bar.hr.res<-sqrt(bar.hr.res[[2]])
beta.bar.hr.res<-bar.hr.res[[1]]

up.lim.bar.hr.res<-exp(beta.bar.hr.res+(1.96*se.bar.hr.res))
low.lim.bar.hr.res<-exp(beta.bar.hr.res-(1.96*se.bar.hr.res))
hr.bar.res<-exp(beta.bar.hr.res)	

cgi.hr<-coxph(formula = surv.obj ~cgi )
cgi.hr.res<-coxph(formula = surv.obj.res ~cgi.res )

se.cgi.hr<-sqrt(cgi.hr[[2]])
beta.cgi.hr<-cgi.hr[[1]]

up.lim.cgi.hr<-exp(beta.cgi.hr+(1.96*se.cgi.hr))
low.lim.cgi.hr<-exp(beta.cgi.hr-(1.96*se.cgi.hr))
hr.cgi<-exp(beta.cgi.hr)

se.cgi.hr.res<-sqrt(cgi.hr.res[[2]])
beta.cgi.hr.res<-cgi.hr.res[[1]]

up.lim.cgi.hr.res<-exp(beta.cgi.hr.res+(1.96*se.cgi.hr.res))
low.lim.cgi.hr.res<-exp(beta.cgi.hr.res-(1.96*se.cgi.hr.res))
hr.cgi.res<-exp(beta.cgi.hr.res) 

gen.hr<-coxph(formula = surv.obj ~panss.gen )
gen.hr.res<-coxph(formula = surv.obj.res ~panss.gen.res)  

se.gen.hr<-sqrt(gen.hr[[2]])
beta.gen.hr<-gen.hr[[1]]

up.lim.gen.hr<-exp(beta.gen.hr+(1.96*se.gen.hr))
low.lim.gen.hr<-exp(beta.gen.hr-(1.96*se.gen.hr))
hr.gen<-exp(beta.gen.hr)

se.gen.hr.res<-sqrt(gen.hr.res[[2]])
beta.gen.hr.res<-gen.hr.res[[1]]

up.lim.gen.hr.res<-exp(beta.gen.hr.res+(1.96*se.gen.hr.res))
low.lim.gen.hr.res<-exp(beta.gen.hr.res-(1.96*se.gen.hr.res))
hr.gen.res<-exp(beta.gen.hr.res)

neg.hr<-coxph(formula = surv.obj ~panss.neg) 
neg.hr.res<-coxph(formula = surv.obj.res ~panss.neg.res)  

se.neg.hr<-sqrt(neg.hr[[2]])
beta.neg.hr<-neg.hr[[1]]

up.lim.neg.hr<-exp(beta.neg.hr+(1.96*se.neg.hr))
low.lim.neg.hr<-exp(beta.neg.hr-(1.96*se.neg.hr))
hr.neg<-exp(beta.neg.hr)

se.neg.hr.res<-sqrt(neg.hr.res[[2]])
beta.neg.hr.res<-neg.hr.res[[1]]

up.lim.neg.hr.res<-exp(beta.neg.hr.res+(1.96*se.neg.hr.res))
low.lim.neg.hr.res<-exp(beta.neg.hr.res-(1.96*se.neg.hr.res))
hr.neg.res<-exp(beta.neg.hr.res)

pos.hr<-coxph(formula = surv.obj ~panss.pos) 
pos.hr.res<-coxph(formula = surv.obj.res ~panss.pos.res) 

se.pos.hr<-sqrt(pos.hr[[2]])
beta.pos.hr<-pos.hr[[1]]

up.lim.pos.hr<-exp(beta.pos.hr+(1.96*se.pos.hr))
low.lim.pos.hr<-exp(beta.pos.hr-(1.96*se.pos.hr))
hr.pos<-exp(beta.pos.hr)

se.pos.hr.res<-sqrt(pos.hr.res[[2]])
beta.pos.hr.res<-pos.hr.res[[1]]

up.lim.pos.hr.res<-exp(beta.pos.hr.res+(1.96*se.pos.hr.res))
low.lim.pos.hr.res<-exp(beta.pos.hr.res-(1.96*se.pos.hr.res))
hr.pos.res<-exp(beta.pos.hr.res)

tot.hr<-coxph(formula = surv.obj ~panss.tot)
tot.hr.res<-coxph(formula = surv.obj.res ~panss.tot.res)

se.tot.hr<-sqrt(tot.hr[[2]])
beta.tot.hr<-tot.hr[[1]]

up.lim.tot.hr<-exp(beta.tot.hr+(1.96*se.tot.hr))
low.lim.tot.hr<-exp(beta.tot.hr-(1.96*se.tot.hr))
hr.tot<-exp(beta.tot.hr)

se.tot.hr.res<-sqrt(tot.hr.res[[2]])
beta.tot.hr.res<-tot.hr.res[[1]]

up.lim.tot.hr.res<-exp(beta.tot.hr.res+(1.96*se.tot.hr.res))
low.lim.tot.hr.res<-exp(beta.tot.hr.res-(1.96*se.tot.hr.res))
hr.tot.res<-exp(beta.tot.hr.res)

fun.hr<-coxph(formula = surv.obj ~functioning) 
fun.hr.res<-coxph(formula = surv.obj.res ~functioning.res) 

se.fun.hr<-sqrt(fun.hr[[2]])
beta.fun.hr<-fun.hr[[1]]

up.lim.fun.hr<-exp(beta.fun.hr+(1.96*se.fun.hr))
low.lim.fun.hr<-exp(beta.fun.hr-(1.96*se.fun.hr))
hr.fun<-exp(beta.fun.hr)

se.fun.hr.res<-sqrt(fun.hr.res[[2]])
beta.fun.hr.res<-fun.hr.res[[1]]

up.lim.fun.hr.res<-exp(beta.fun.hr.res+(1.96*se.fun.hr.res))
low.lim.fun.hr.res<-exp(beta.fun.hr.res-(1.96*se.fun.hr.res))
hr.fun.res<-exp(beta.fun.hr.res)

eps.hr<-coxph(formula = surv.obj ~eps) 
eps.hr.res<-coxph(formula = surv.obj.res ~eps.res) 

se.eps.hr<-sqrt(eps.hr[[2]])
beta.eps.hr<-eps.hr[[1]]

up.lim.eps.hr<-exp(beta.eps.hr+(1.96*se.eps.hr))
low.lim.eps.hr<-exp(beta.eps.hr-(1.96*se.eps.hr))
hr.eps<-exp(beta.eps.hr)

se.eps.hr.res<-sqrt(eps.hr.res[[2]])
beta.eps.hr.res<-eps.hr.res[[1]]

up.lim.eps.hr.res<-exp(beta.eps.hr.res+(1.96*se.eps.hr.res))
low.lim.eps.hr.res<-exp(beta.eps.hr.res-(1.96*se.eps.hr.res))
hr.eps.res<-exp(beta.eps.hr.res)

#####SUMMARY TABLES

colname.desc.cont<- c("Age (mean)", "Age (SD)", "BMI (mean)", "BMI (SD)","Age at diagnosis (mean)","Age at diagnosis (SD)","Duration of illness (mean)","Duration of illness (SD)", "CGI (mean)","CGI (SD)","Psychopathology total score (mean)","Psychopathology total score (SD)", "Psychopathology general score (mean)","Psychopathology general score (SD)","Psychopathology positive score (mean)","Psychopathology positive score (SD)","Psychopathology negative score (mean)","Psychopathology negative score (SD)","General functioning score (mean)","General functioning score (SD)", "Quality of life score (mean)","Quality of life score (SD)")

mean.age<-mean(age, na.rm=T)
sd.age<-sd(age,na.rm=T)
mean.BMI<-mean(BMI,na.rm=T)
sd.BMI<-sd(BMI,na.rm=T)
mean.agediagnosis<-mean(age.diag, na.rm=T)
sd.agediagnsosis<-sd(age.diag,na.rm=T)
mean.doi<-mean(doi,na.rm=T)
sd.doi<-sd(doi,na.rm=T)
mean.cgi<-mean(cgi,na.rm=T)
sd.cgi<-sd(cgi,na.rm=T)
mean.totps<-mean(panss.tot,na.rm=T)
sd.totps<-sd(panss.tot, na.rm=T)
mean.genps<- mean(panss.gen, na.rm=T)
sd.genps<-sd(panss.gen, na.rm=T)
mean.posps<-mean(panss.pos, na.rm=T)
sd.posps<-sd(panss.pos, na.rm=T)
mean.negps<-mean(panss.neg, na.rm=T)
sd.negps<-sd(panss.neg, na.rm=T)
mean.func<-mean(functioning, na.rm=T)
sd.functioning<-sd(functioning, na.rm=T)
mean.qol<-NA
sd.qol<-NA

desc.cont<-c(mean.age,sd.age,mean.BMI,sd.BMI,mean.agediagnosis,sd.agediagnsosis,mean.doi,sd.doi,mean.cgi,sd.cgi,mean.totps,sd.totps,mean.genps,sd.genps,mean.posps,sd.posps,mean.negps,sd.negps,mean.func,sd.functioning,mean.qol,sd.qol)

desc.cont.mat<-rbind(colname.desc.cont,desc.cont)

mean.age.res<-mean(age.res, na.rm=T)
sd.age.res<-sd(age.res,na.rm=T)
mean.BMI.res<-mean(BMI.res,na.rm=T)
sd.BMI.res<-sd(BMI.res,na.rm=T)
mean.agediagnosis.res<-mean(age.diag.res, na.rm=T)
sd.agediagnsosis.res<-sd(age.diag.res,na.rm=T)
mean.doi.res<-mean(doi.res,na.rm=T)
sd.doi.res<-sd(doi.res,na.rm=T)
mean.cgi.res<-mean(cgi.res,na.rm=T)
sd.cgi.res<-sd(cgi.res,na.rm=T)
mean.totps.res<-mean(panss.tot.res,na.rm=T)
sd.totps.res<-sd(panss.tot.res, na.rm=T)
mean.genps.res<- mean(panss.gen.res, na.rm=T)
sd.genps.res<-sd(panss.gen.res, na.rm=T)
mean.posps.res<-mean(panss.pos.res, na.rm=T)
sd.posps.res<-sd(panss.pos.res, na.rm=T)
mean.negps.res<-mean(panss.neg.res, na.rm=T)
sd.negps.res<-sd(panss.neg.res, na.rm=T)
mean.func.res<-mean(functioning.res, na.rm=T)
sd.func.res<-sd(functioning.res, na.rm=T)
mean.qol.res<-NA
sd.qol.res<-NA

desc.cont.res<-c(mean.age.res,sd.age.res,mean.BMI.res,sd.BMI.res,mean.agediagnosis.res,sd.agediagnsosis.res,mean.doi.res,sd.doi.res,mean.cgi.res,sd.cgi.res,mean.totps.res,sd.totps.res,mean.genps.res,sd.genps.res,mean.posps.res,sd.posps.res,mean.negps.res,sd.negps.res,mean.func.res,sd.func.res,mean.qol.res,sd.qol.res)

desc.cont.mat.res<-rbind(colname.desc.cont,desc.cont.res)

mean.age.no.res<-mean(age.no.res, na.rm=T)
sd.age.no.res<-sd(age.no.res,na.rm=T)
mean.BMI.no.res<-mean(BMI.no.res,na.rm=T)
sd.BMI.no.res<-sd(BMI.no.res,na.rm=T)
mean.agediagnosis.no.res<-mean(age.diag.no.res, na.rm=T)
sd.agediagnsosis.no.res<-sd(age.diag.no.res,na.rm=T)
mean.doi.no.res<-mean(doi.no.res,na.rm=T)
sd.doi.no.res<-sd(doi.no.res,na.rm=T)
mean.cgi.no.res<-mean(cgi.no.res,na.rm=T)
sd.cgi.no.res<-sd(cgi.no.res,na.rm=T)
mean.totps.no.res<-mean(panss.tot.no.res,na.rm=T)
sd.totps.no.res<-sd(panss.tot.no.res, na.rm=T)
mean.genps.no.res<- mean(panss.gen.no.res, na.rm=T)
sd.genps.no.res<-sd(panss.gen.no.res, na.rm=T)
mean.posps.no.res<-mean(panss.pos.no.res, na.rm=T)
sd.posps.no.res<-sd(panss.pos.no.res, na.rm=T)
mean.negps.no.res<-mean(panss.neg.no.res, na.rm=T)
sd.negps.no.res<-sd(panss.neg.no.res, na.rm=T)
mean.func.no.res<-mean(functioning.no.res, na.rm=T)
sd.func.no.res<-sd(functioning.no.res, na.rm=T)
mean.qol.no.res<-NA
sd.qol.no.res<-NA

desc.cont.no.res<-c(mean.age.no.res,sd.age.no.res,mean.BMI.no.res,sd.BMI.no.res,mean.agediagnosis.no.res,sd.agediagnsosis.no.res,mean.doi.no.res,sd.doi.no.res,mean.cgi.no.res,sd.cgi.no.res,mean.totps.no.res,sd.totps.no.res,mean.genps.no.res,sd.genps.no.res,mean.posps.no.res,sd.posps.no.res,mean.negps.no.res,sd.negps.no.res,mean.func.no.res,sd.func.no.res,mean.qol.no.res,sd.qol.no.res)

desc.cont.mat.no.res<-rbind(colname.desc.cont,desc.cont.no.res)


colname.desc.cat<- c("Male (n)","Male (%)", "US (n)", "US (%)", "Family history (n)", "Family history (%)", "Smoking (n)", "Smoking (%)", "Drug use (n)", "Drug use (%)",">=3 prior hospitalizations(n)",">=3 prior hospitalizations (%)","Hospitalized in previous year (n)","Hospitalized in previous year (%)",">Moderate TD (n)",">Moderate TD (%)",">Moderate akathisia (n)",">Moderate akathisia (%)",">Moderate EPS (n)",">Moderate EPS (%)")

n.male<- length(sex[sex==1])
perc.male<-length(sex[sex==1])/length(sex)*100
n.us<- length(region[region==1])
perc.us<-length(region[region==1])/length(region)*100
n.fhx<- NA
perc.fhx<-NA
n.smok<- NA
perc.smok<-NA
n.drug<- NA
perc.drug<-NA
n.hosp.n<-NA
perc.hosp.n<-NA
n.hosp.t<-NA
perc.hosp.t<-NA
n.td<-length(aims[aims==1])
perc.td<-length(aims[aims==1])/length(aims)*100
n.aka<-length(bars[bars==1])
perc.aka<-length(bars[bars==1])/length(bars)*100
n.eps<-length(eps[eps==1])
perc.eps<-length(eps[eps==1])/length(eps)*100

desc.cat<-c(n.male,perc.male,n.us,perc.us,n.fhx,perc.fhx,n.smok,perc.smok,n.drug,perc.drug,n.hosp.n,perc.hosp.n,n.hosp.t,perc.hosp.t,n.td,perc.td,n.aka,perc.aka,n.eps,perc.eps)

desc.cat.mat<-rbind(colname.desc.cat,desc.cat)

n.male.res<- length(sex.res[sex.res==1])
perc.male.res<-length(sex.res[sex.res==1])/length(sex.res)*100
n.us.res<- length(region.res[region.res==1])
perc.us.res<-length(region.res[region.res==1])/length(region.res)*100
n.fhx.res<- NA
perc.fhx.res<-NA
n.smok.res<- NA
perc.smok.res<-NA
n.drug.res<- NA
perc.drug.res<-NA
n.hosp.n.res<-NA
perc.hosp.n.res<-NA
n.hosp.t.res<-NA
perc.hosp.t.res<-NA
n.td.res<-length(aims.res[aims.res==1])
perc.td.res<-length(aims.res[aims.res==1])/length(aims.res)*100
n.aka.res<-length(bars.res[bars.res==1])
perc.aka.res<-length(bars.res[bars.res==1])/length(bars.res)*100
n.eps.res<-length(eps.res[eps.res==1])
perc.eps.res<-length(eps.res[eps.res==1])/length(eps.res)*100

desc.cat.res<-c(n.male.res,perc.male.res,n.us.res,perc.us.res,n.fhx.res,perc.fhx.res,n.smok.res,perc.smok.res,n.drug.res,perc.drug.res,n.hosp.n.res,perc.hosp.n.res,n.hosp.t.res,perc.hosp.t.res,n.td.res,perc.td.res,n.aka.res,perc.aka.res,n.eps.res,perc.eps.res)

desc.cat.mat.res<-rbind(colname.desc.cat,desc.cat.res)

n.male.no.res<- length(sex.no.res[sex.no.res==1])
perc.male.no.res<-length(sex.no.res[sex.no.res==1])/length(sex.no.res)*100
n.us.no.res<- length(region.no.res[region.no.res==1])
perc.us.no.res<-length(region.no.res[region.no.res==1])/length(region.no.res)*100
n.fhx.no.res<- NA
perc.fhx.no.res<-NA
n.smok.no.res<- NA
perc.smok.no.res<-NA
n.drug.no.res<- NA
perc.drug.no.res<-NA
n.hosp.n.no.res<-NA
perc.hosp.n.no.res<-NA
n.hosp.t.no.res<-NA
perc.hosp.t.no.res<-NA
n.td.no.res<-length(aims.no.res[aims.no.res==1])
perc.td.no.res<-length(aims.no.res[aims.no.res==1])/length(aims.no.res)*100
n.aka.no.res<-length(bars.no.res[bars.no.res==1])
perc.aka.no.res<-length(bars.no.res[bars.no.res==1])/length(bars.no.res)*100
n.eps.no.res<-length(eps.no.res[eps.no.res==1])
perc.eps.no.res<-length(eps.no.res[eps.no.res==1])/length(eps.no.res)*100

desc.cat.no.res<-c(n.male.no.res,perc.male.no.res,n.us.no.res,perc.us.no.res,n.fhx.no.res,perc.fhx.no.res,n.smok.no.res,perc.smok.no.res,n.drug.no.res,perc.drug.no.res,n.hosp.n.no.res,perc.hosp.n.no.res,n.hosp.t.no.res,perc.hosp.t.no.res,n.td.no.res,perc.td.no.res,n.aka.no.res,perc.aka.no.res,n.eps.no.res,perc.eps.no.res)

desc.cat.mat.no.res<-rbind(colname.desc.cat,desc.cat.no.res)


colname.outc<-c("Total sample 'n'", "Relapse 'n'", "Relapse '%'", "Median time to relapse 'days'", "Events per 100 patient - years")

n.total<-length(total.ids)
n.relapse<-length(status[status==1])
perc.relapse<-length(status[status==1])/length(status)*100
median.time<-median(time.to.event, na.rm=T)
py.inc

outc<-c(n.total,n.relapse,perc.relapse,median.time,py.inc)

outc.mat<-rbind(colname.outc,outc)

n.total.res<-length(response.ids)
n.relapse.res<-length(status.res[status.res==1])
perc.relapse.res<-length(status.res[status.res==1])/length(status.res)*100
median.time.res<-median(time.to.event.res, na.rm=T)
py.inc.res

outc.res<-c(n.total.res,n.relapse.res,perc.relapse.res,median.time.res,py.inc.res)

outc.mat.res<-rbind(colname.outc,outc.res)

n.total.no.res<-length(no.response.ids)
n.relapse.no.res<-length(status.no.res[status.no.res==1])
perc.relapse.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100
median.time.no.res<-median(time.to.event.no.res, na.rm=T)
py.inc.no.res

outc.no.res<-c(n.total.no.res,n.relapse.no.res,perc.relapse.no.res,median.time.no.res,py.inc.no.res)

outc.mat.no.res<-rbind(colname.outc,outc.no.res)


colname.HR<-c("Male gender HR","Male gender Lower 95% CI","Male gender Upper 95% CI","Age HR", "Age Lower 95% CI","Age	Upper 95% CI","Proportion US HR",
              "Proportion US Lower 95% CI","Proportion US Upper 95% CI","BMI HR",  "BMI Lower 95% CI","BMI Upper 95% CI", "Age at diagnosis HR",
              "Age at diagnosis Lower 95% CI","Age at diagnosis Upper 95% CI","Duration of illness HR","Duration of illness Lower 95% CI","Duration of illness Upper 95% CI",
              "Time since last hospitalization HR","Time since last hospitalization Lower 95% CI","Time since last hospitalization Upper 95% CI",
              "Number of previous hospitalizations HR","Number of previous hospitalizations Lower 95% CI","Number of previous hospitalizations Upper 95% CI",
              "Family history HR","Family history Lower 95% CI","Family history Upper 95% CI","Smoking HR","Smoking Lower 95% CI","Smoking Upper 95% CI",
              "Drug use HR","Drug use Lower 95% CI","Drug use Upper 95% CI","CGI HR","CGI Lower 95% CI","CGI Upper 95% CI","Psychopathology total score HR",
              "Psychopathology total score Lower 95% CI","Psychopathology total score Upper 95% CI","Psychopathology general score HR",
              "Psychopathology general score Lower 95% CI","Psychopathology general score Upper 95% CI","Psychopathology positive score HR",
              "Psychopathology positive score Lower 95% CI","Psychopathology positive score Upper 95% CI","Psychopathology negative score HR",
              "Psychopathology negative score Lower 95% CI","Psychopathology negative score Upper 95% CI","General functioning score HR", 
              "General functioning score Lower 95% CI","General functioning score Upper 95% CI", "Quality of life score HR",  "Quality of life score Lower 95% CI","Quality of life score Upper 95% CI","Tardive dyskinesia score HR","Tardive dyskinesia score Lower 95% CI","Tardive dyskinesia score Upper 95% CI","Akathisia score HR","Akathisia score Lower 95% CI","Akathisia score Upper 95% CI","Parkinsonism score HR","Parkinsonism score Lower 95% CI","Parkinsonism score Upper 95% CI")


hr<- cbind(
  hr.sex,low.lim.sex.hr,up.lim.sex.hr,
  hr.age,low.lim.age.hr,up.lim.age.hr,
  NA,NA,NA,
  hr.bmi,low.lim.bmi.hr,up.lim.bmi.hr,
  hr.age,low.lim.age.hr,up.lim.age.hr,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  hr.cgi,low.lim.cgi.hr,up.lim.cgi.hr,
  hr.tot,low.lim.tot.hr,up.lim.tot.hr,
  hr.gen,low.lim.gen.hr,up.lim.gen.hr,
  hr.pos,low.lim.pos.hr,up.lim.pos.hr,
  hr.neg,low.lim.neg.hr,up.lim.neg.hr,
  hr.fun,low.lim.fun.hr,up.lim.fun.hr,
  NA,NA,NA,
  hr.aim,low.lim.aim.hr,up.lim.aim.hr,
  hr.bar,low.lim.bar.hr,up.lim.bar.hr,
  hr.eps,low.lim.eps.hr,up.lim.eps.hr)

hr.mat<-rbind(colname.HR,hr)

hr.res<- cbind(
  hr.sex.res,low.lim.sex.hr.res,up.lim.sex.hr.res,
  hr.age.res,low.lim.age.hr.res,up.lim.age.hr.res,
  NA,NA,NA,
  hr.bmi.res,low.lim.bmi.hr.res,up.lim.bmi.hr.res,
  hr.age.res,low.lim.age.hr.res,up.lim.age.hr.res,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  hr.cgi.res,low.lim.cgi.hr.res,up.lim.cgi.hr.res,
  hr.tot.res,low.lim.tot.hr.res,up.lim.tot.hr.res,
  hr.gen.res,low.lim.gen.hr.res,up.lim.gen.hr.res,
  hr.pos.res,low.lim.pos.hr.res,up.lim.pos.hr.res,
  hr.neg.res,low.lim.neg.hr.res,up.lim.neg.hr.res,
  hr.fun.res,low.lim.fun.hr.res,up.lim.fun.hr.res,
  NA,NA,NA,
  hr.aim.res,low.lim.aim.hr.res,up.lim.aim.hr.res,
  hr.bar.res,low.lim.bar.hr.res,up.lim.bar.hr.res,
  hr.eps.res,low.lim.eps.hr.res,up.lim.eps.hr.res)

hr.mat.res<-rbind(colname.HR,hr.res)


# hr.no.res (will only use sei and yi for hr.no.res in this trial)


hr.int<- cbind(
  ci.int.sex[1],ci.int.sex[2],ci.int.sex[3],
  ci.int.age[1],ci.int.age[2],ci.int.age[3],
  NA,NA,NA,
  ci.int.bmi[1],ci.int.bmi[2],ci.int.bmi[3],
  ci.int.age[1],ci.int.age[2],ci.int.age[3],
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  ci.int.cgi[1],ci.int.cgi[2],ci.int.cgi[3],
  ci.int.panss.tot[1],ci.int.panss.tot[2],ci.int.panss.tot[3],
  ci.int.panss.gen[1],ci.int.panss.gen[2],ci.int.panss.gen[3],
  ci.int.panss.pos[1],ci.int.panss.pos[2],ci.int.panss.pos[3],
  ci.int.panss.neg[1],ci.int.panss.neg[2],ci.int.panss.neg[3],
  ci.int.functioning[1],ci.int.functioning[2],ci.int.functioning[3],
  NA,NA,NA,
  ci.int.aims[1],ci.int.aims[2],ci.int.aims[3],
  ci.int.bars[1],ci.int.bars[2],ci.int.bars[3],
  ci.int.eps[1],ci.int.eps[2],ci.int.eps[3])

hr.int.mat<-rbind(colname.HR,hr.int)

hr.int.seiyi<-cbind(
  sei.int.sex[1],sei.int.sex[2],
  sei.int.age[1],sei.int.age[2],
  NA,NA,
  sei.int.bmi[1],sei.int.bmi[2],
  sei.int.age[1],sei.int.age[2],
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  sei.int.cgi[1],sei.int.cgi[2],
  sei.int.panss.tot[1],sei.int.panss.tot[2],
  sei.int.panss.gen[1],sei.int.panss.gen[2],
  sei.int.panss.pos[1],sei.int.panss.pos[2],
  sei.int.panss.neg[1],sei.int.panss.neg[2],
  sei.int.functioning[1],sei.int.functioning[2],
  NA,NA,
  sei.int.aims[1],sei.int.aims[2],
  sei.int.bars[1],sei.int.bars[2],
  sei.int.eps[1],sei.int.eps[2])

hr.nores.seiyi<-cbind(
  sei.sex[1],sei.sex[2],
  sei.age[1],sei.age[2],
  NA,NA,
  sei.bmi[1],sei.bmi[2],
  sei.age[1],sei.age[2],
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  sei.cgi[1],sei.cgi[2],
  sei.panss.tot[1],sei.panss.tot[2],
  sei.panss.gen[1],sei.panss.gen[2],
  sei.panss.pos[1],sei.panss.pos[2],
  sei.panss.neg[1],sei.panss.neg[2],
  sei.functioning[1],sei.functioning[2],
  NA,NA,
  sei.aims[1],sei.aims[2],
  sei.bars[1],sei.bars[2],
  sei.eps[1],sei.eps[2])


surv.obj <- Surv(time.to.event/7, status)
surv.obj.res <- Surv(time.to.event.res/7, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res/7, status.no.res)

survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)

study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)


xx<-study1.surv.fit
xx.res<-study1.surv.fit.res
xx.no.res<-study1.surv.fit.no.res


xx.t<-xx[[2]]
xx.p<-xx[[6]]

xx.t.res<-xx.res[[2]]
xx.p.res<-xx.res[[6]]

xx.t.no.res<-xx.no.res[[2]]
xx.p.no.res<-xx.no.res[[6]]

surv.mat<-cbind(xx.t,xx.p)
surv.mat.res<-cbind(xx.t.res,xx.p.res)
surv.mat.no.res<-cbind(xx.t.no.res,xx.p.no.res)


write.table(surv.mat,file="X:/Workspace/Results/surv_PSY301_V2.csv",sep=",")
write.table(surv.mat.res,file="X:/Workspace/Results/surv_PSY301_res_V2.csv",sep=",")
write.table(surv.mat.no.res,file="X:/Workspace/Results/surv_PSY301_no.res_V2.csv",sep=",")

write.table(desc.cont.mat,file="X:/Workspace/Results/desc_cont_PSY301_V2.csv",sep=",")
write.table(desc.cont.mat.res,file="X:/Workspace/Results/desc_cont_PSY301_res_V2.csv",sep=",")
write.table(desc.cont.mat.no.res,file="X:/Workspace/Results/desc_cont_PSY301_no.res_V2.csv",sep=",")

write.table(desc.cat.mat,file="X:/Workspace/Results/desc_cat_PSY301_V2.csv",sep=",")
write.table(desc.cat.mat.res,file="X:/Workspace/Results/desc_cat_PSY301_res_V2.csv",sep=",")
write.table(desc.cat.mat.no.res,file="X:/Workspace/Results/desc_cat_PSY301_no.res_V2.csv",sep=",")

write.table(outc.mat,file="X:/Workspace/Results/outc_PSY301_V2.csv",sep=",")
write.table(outc.mat.res,file="X:/Workspace/Results/outc_PSY301_res_V2.csv",sep=",")
write.table(outc.mat.no.res,file="X:/Workspace/Results/outc_PSY301_no.res_V2.csv",sep=",")

write.table(hr.mat,file="X:/Workspace/Results/hr_PSY301_V2.csv",sep=",")
write.table(hr.mat.res,file="X:/Workspace/Results/hr_PSY301_res_V2.csv",sep=",")
write.table(hr.int.mat,file="X:/Workspace/Results/hr.int_PSY301_v2.csv",sep=",")

write.table(hr.int.seiyi,file="X:/Workspace/Results/hr.int.seiyi_PSY301_v2.csv",sep=",")
write.table(hr.nores.seiyi,file="X:/Workspace/Results/hr.nores.seiyi_PSY301_v2.csv",sep=",")

#code to calculate the relapse criteria met
relapse.dat1<-read.csv("X:/Data/JnJ-RIS-PSY-301-csv/Data/relapsetot.csv", header = TRUE, sep = ",")
relapse.dat<-relapse.dat1[relapse.dat1$RELAPSE=="Yes",]

pt.rel.panss<-length(relapse.dat$DCRFID[relapse.dat$DETORIATION=="Ticked"])/length(relapse.dat$DCRFID)*100 
pt.rel.hosp<-length(relapse.dat$DCRFID[relapse.dat$HOSP=="Ticked"])/length(relapse.dat$DCRFID)*100 
pt.rel.sui<-length(c(relapse.dat$DCRFID[relapse.dat$SELF_INJURY=="Ticked"],relapse.dat$DCRFID[relapse.dat$SUICIDAL=="Ticked"]))/length(relapse.dat$DCRFID)*100 
pt.rel.viol<-0
 
pt.rel.panss
pt.rel.hosp
pt.rel.sui
pt.rel.viol

#code to compare functioning between relapsers and non-relapsers
ids.sofas<-unique(visit.dat$DCRFID[!is.na(visit.dat$SOFAS)])

recur<-unique(intersect(ids.sofas,total.ids[status==1]))
norecur<-unique(intersect(ids.sofas,total.ids[status==0]))

func.bl.rel<-array(,length(recur))
for(i in seq_along(recur)){
  func.bl.rel[i]<-functioning[ids.sofas==recur[i]]
}

func.bl.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
  func.bl.norel[i]<-functioning[ids.sofas==norecur[i]]
}

func.end.rel<-array(,length(recur))
for(i in seq_along(recur)){
  temp.visit<-visit.dat$VISIT_DY[visit.dat$DCRFID==recur[i]]
  max.temp.visit<-max(temp.visit,rm.na=T)
  func.end.rel[i]<-visit.dat$SOFAS[visit.dat$VISIT_DY==max.temp.visit & visit.dat$DCRFID==recur[i]]}

func.end.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
  temp.visit<-visit.dat$VISIT_DY[visit.dat$DCRFID==norecur[i]]
  max.temp.visit<-max(temp.visit,rm.na=T)
  func.end.norel[i]<-visit.dat$SOFAS[visit.dat$VISIT_DY==max.temp.visit & visit.dat$DCRFID==norecur[i]]}

delta.func.rel<-func.end.rel-func.bl.rel
delta.func.norel<-func.end.norel - func.bl.norel

t.test(delta.func.rel,delta.func.norel)

mean(delta.func.rel,na.rm=T)
sd(delta.func.rel,na.rm=T)
mean(delta.func.norel,na.rm=T)
sd(delta.func.norel,na.rm=T)

