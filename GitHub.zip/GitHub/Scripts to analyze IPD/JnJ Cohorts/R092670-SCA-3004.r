##R092670-SCA-3004
# Authored: Jose M Rubio M.D // jrubio13@northwell.edu
# Checked: George Schoretsanitis M.D.,PhD
# April 7th 2020

###COHORT JnJ-R092670-SCA-3004
#################################
### a function to match and merge variables from two datasets

match.and.merge.func <- function(dat1.id, dat2.id, dat2.var){
  dat1.var <- array(,length(dat1.id)) 
  for(i in 1:length(dat1.id)){
    for(j in 1:length(dat2.id)){
      if(dat1.id[i] == dat2.id[j]){ dat1.var[i] <- dat2.var[j] }}}
  return(dat1.var)                                       }

##########IDENTIFY TOTAL DATASET
#ALLOCATED TO LAI (ALL FOR INITIAL 25 WEEKS, THEN CENSOR THOSE ALLOCATED TO PBO)	
#FOLLOWED FOR SUFFICIENT TIME TO HAVE A THERAPEUTIC PLASMA LEVEL (>1 WEEK FOR PP)

visit.dat     <- read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/sv.csv", header = TRUE, sep = ",")
visit.dat.id  <- as.character(visit.dat$DUSUBJID)
visit.dat.id.u <- unique(as.character(visit.dat$DUSUBJID)) 

exclude.ind <- array(0, length(visit.dat.id.u)) 
for(i in 1:length(visit.dat.id.u)){
  visitnum.temp <- visit.dat$SVSTDY[visit.dat.id == visit.dat.id.u[i]]
  visitnum.temp.max <- max(visitnum.temp, na.rm = T)
  if(visitnum.temp.max <= 8){ exclude.ind[i] <- 1 } }

total.ids <- visit.dat.id.u[exclude.ind == 0] #TOTAL DATASET OK 

##########IDENTIFY 'REMISSION' DATASET 
##IF PTS STABLE UPON ENTRY  --> FIRST 2 VISITS WITH LESS THAN MILD ON POSITIVE SYMPTOMS) [THESE WILL BE LABELLED AS .RES, ALTHOUGH IN FACT ARE REMITTERS]
##IF PTS NOT STABLE UPON ENTRY XXX --> FIRST 2 VISITS AFTER WEEK 6 WITH LESS THAN MILD ON POSITIVE SYMPTOMS) [THESE WILL BE LABELLED AS .RES, ALTHOUGH IN FACT ARE REMITTERS]

qs.dat<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/qs.csv", header = TRUE, sep = ",")
visit<-as.numeric(as.character(qs.dat$VISITNUM))
item<-as.character(qs.dat$QSTESTCD)

qs.dat.res5 <- qs.dat[visit==4 & (item=="P01"|item=="P02"|item=="P03"|item=="P04"|item=="P05"|item=="P06"|item=="P07"),]
ids.u.5<-unique(as.character(qs.dat.res5$DUSUBJID))
value<-as.numeric(as.character(qs.dat.res5$QSSTRESC)) 

panss.res.id5<-array(0,length(ids.u.5))
for(i in 1:length(ids.u.5)){
  temp.array1<-value[qs.dat.res5$DUSUBJID==ids.u.5[i]]
  temp.array1[is.na(temp.array1)]<-4
  max.sc.rs<-max(temp.array1, na.rm=TRUE)
  if(max.sc.rs<4){panss.res.id5[i]<-1}}

response.ids5<-ids.u.5[panss.res.id5==1]


qs.dat.res6 <- qs.dat[visit==5 & (item=="P01"|item=="P02"|item=="P03"|item=="P04"|item=="P05"|item=="P06"|item=="P07"),]
ids.u.6<-unique(as.character(qs.dat.res6$DUSUBJID))
value<-as.numeric(as.character(qs.dat.res6$QSSTRESC)) 

panss.res.id6<-array(0,length(ids.u.6))
for(i in 1:length(ids.u.6)){
  temp.array1<-value[qs.dat.res6$DUSUBJID==ids.u.6[i]]
  temp.array1[is.na(temp.array1)]<-4
  max.sc.rs<-max(temp.array1, na.rm=TRUE)
  if(max.sc.rs<4){panss.res.id6[i]<-1}}

response.ids6<-ids.u.6[panss.res.id6==1]

response.ids<-intersect(response.ids5,response.ids6) #ok
no.response.ids<-setdiff(total.ids,response.ids) 

dm.dat<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/dm.csv", header = TRUE, sep = ",")
arm<-as.character(dm.dat$ARMCD)
dm.id.u<-dm.dat$DUSUBJID
pp.ids<-as.character(dm.dat$DUSUBJID[arm=="PALI PALM - PALI PALM"])
pbo.ids<-as.character(dm.dat$DUSUBJID[arm=="PALI PALM - PBO"])


########DEFINE STATUS PER DATASET (1=event; 0=censor)
#first for those that relapsed prior to randomization

disposit.dat<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/ds.csv", header = TRUE, sep = ",")
reas<-as.character(disposit.dat$DSDECOD)
disposit.rel<-disposit.dat[reas=="LACK OF EFFICACY",]
rel.pre<-unique(as.character(disposit.rel$DUSUBJID))

status<-array(0,length(total.ids))
for(i in 1:length(total.ids)){
  for (j in 1:length(rel.pre)){
    if(total.ids[i]==rel.pre[j]){status[i]<-1}}}

status.res<-array(0,length(response.ids))
for(i in 1:length(response.ids)){
  for (j in 1:length(rel.pre)){
    if(response.ids[i]==rel.pre[j]){status.res[i]<-1}}}

status.no.res<-array(0,length(no.response.ids))
for(i in 1:length(no.response.ids)){
  for (j in 1:length(rel.pre)){
    if(no.response.ids[i]==rel.pre[j]){status.no.res[i]<-1}}}

#now update to include those who relapsed after randomization. Here it is under FAORRES[FATESTCD=="FAPSSYMP"] 

relapse.dat<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/fa.csv", header = TRUE, sep = ",")
reas<-as.character(relapse.dat$FATESTCD)
rel.rel<-relapse.dat[reas=="FAPSSYMP",]
value<-as.character(rel.rel$FAORRES)
rel.post<-unique(as.character(rel.rel$DUSUBJID[value=="Y"]))

for(i in 1:length(total.ids)){
  for(j in 1:length(rel.post)){
    if(total.ids[i]==rel.post[j]){status[i]<-1}}}

for(i in 1:length(response.ids)){
  for(j in 1:length(rel.post)){
    if(response.ids[i]==rel.post[j]){status.res[i]<-1}}}

for(i in 1:length(no.response.ids)){
  for(j in 1:length(rel.post)){
    if(no.response.ids[i]==rel.post[j]){status.no.res[i]<-1}}}

#finally, categorize as 'non-event', or '0', those allocated to PBO after randomization	

for(i in 1:length(total.ids)){
  for(j in 1:length(pbo.ids)){
    if(total.ids[i]==pbo.ids[j]){status[i]<-0}}}

for(i in 1:length(response.ids)){
  for(j in 1:length(pbo.ids)){
    if(response.ids[i]==pbo.ids[j]){status.res[i]<-0}}}

for(i in 1:length(no.response.ids)){
  for(j in 1:length(pbo.ids)){
    if(no.response.ids[i]==pbo.ids[j]){status.no.res[i]<-0}}}


######DEFINE TIME TO EVENT PER DATASET 
#first those that relapsed before randomization

disposit.dat<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/ds.csv", header = TRUE, sep = ",")
reas<-as.character(disposit.dat$DSDECOD)
disposit.rel<-disposit.dat[reas=="LACK OF EFFICACY",]
rel.pre<-unique(as.character(disposit.rel$DUSUBJID))
day.rel<-as.numeric(disposit.rel$DSSTDY)

time.rel<-array(0,length(total.ids))
for(i in 1:length(total.ids)){
  for (j in 1:length(rel.pre)){
    if(total.ids[i]==rel.pre[j]){time.rel[i]<-day.rel[disposit.rel$DUSUBJID==rel.pre[j]]}}}

time.rel.res<-array(0,length(response.ids))
for(i in 1:length(response.ids)){
  for (j in 1:length(rel.pre)){
    if(response.ids[i]==rel.pre[j]){time.rel.res[i]<-day.rel[disposit.rel$DUSUBJID==rel.pre[j]]}}}

time.rel.no.res<-array(0,length(no.response.ids))
for(i in 1:length(no.response.ids)){
  for (j in 1:length(rel.pre)){
    if(no.response.ids[i]==rel.pre[j]){time.rel.no.res[i]<-day.rel[disposit.rel$DUSUBJID==rel.pre[j]]}}}

#now update if event occurred after randomization
relapse.dat<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/fa.csv", header = TRUE, sep = ",")
reas<-as.character(relapse.dat$FATESTCD)
rel.rel<-relapse.dat[reas=="FAPSSYMP",] # includes rows including question on relapse for psychotic sx
value<-as.character(rel.rel$FAORRES)
rel.post<-unique(as.character(rel.rel$DUSUBJID[value=="Y"]))#among rel.rel includes ids among whom the criteria of relapse is met
rel.day<-as.numeric(rel.rel$FADY)

for(i in 1:length(total.ids)){
  for (j in 1:length(rel.post)){
    if(total.ids[i]==rel.post[j]){time.rel[i]<-rel.day[rel.rel$DUSUBJID==rel.post[j]]}}}

for(i in 1:length(response.ids)){
  for (j in 1:length(rel.post)){
    if(response.ids[i]==rel.post[j]){time.rel[i]<-rel.day[rel.rel$DUSUBJID==rel.post[j]]}}}

for(i in 1:length(no.response.ids)){
  for (j in 1:length(rel.post)){
    if(no.response.ids[i]==rel.post[j]){time.rel[i]<-rel.day[rel.rel$DUSUBJID==rel.post[j]]}}}

#now include time to event for those that did not have relapse (i.e., time.rel above is 0)
visit.dat     <- read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/sv.csv", header = TRUE, sep = ",")
visit.dat.id  <- as.character(visit.dat$DUSUBJID)
visit.dat.id.u<-unique(visit.dat.id)
time.vis<-visit.dat$SVSTDY

for(i in 1:length(visit.dat.id.u)){
  temp1<-time.vis[visit.dat.id == visit.dat.id.u[i]]
  temp2<-max(temp1, na.rm=T)
  for(j in 1:length(total.ids)){
    if(visit.dat.id.u[i] == total.ids[j]){
      if(time.rel[j]==0){time.rel[j]<-temp2}}}}


for(i in 1:length(visit.dat.id.u)){
  visitnum.temp <- visit.dat$SVSTDY[visit.dat.id == visit.dat.id.u[i]]
  visitnum.temp.max <- max(visitnum.temp, na.rm = T)
  if(visitnum.temp.max <= 84){ exclude.ind[i] <- 1 } }

#finally censor on day of randomization those allocated to PBO

for(i in 1:length(total.ids)){
  for (j in 1:length(pbo.ids)){
    if(total.ids[i]==pbo.ids[j]){time.rel[i]<-175}}}

time.to.event<-match.and.merge.func(total.ids,total.ids,time.rel)
time.to.event.res<-match.and.merge.func(response.ids,response.ids,time.rel)
time.to.event.no.res<-match.and.merge.func(no.response.ids,no.response.ids,time.rel) #

rem.stat<-array(0,length(total.ids))
for(i in 1:length(total.ids)){
  for(j in 1:length(response.ids)){
    if(total.ids[i]==response.ids[j]){
      rem.stat[i]<-1}
  }
}

#SURVIVAL ANALYSIS

library(survival)
surv.obj <- Surv(time.to.event, status)
surv.obj.res <- Surv(time.to.event.res, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res, status.no.res)

survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)

study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)

##CALCULATE PERSON YEARS AND ABSOLUTE AND PERSON X YEAR INCIDENCE RATE
#person-year
per.year<-sum(time.to.event, na.rm=T)/365
per.year.res<-sum(time.to.event.res, na.rm=T)/365
per.year.no.res<-sum(time.to.event.no.res, na.rm=T)/365

#absolute incidence
abs.inc<-length(status[status==1])/length(status)*100 
abs.inc.res<-length(status.res[status.res==1])/length(status.res)*100
abs.inc.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100

# incidence by 100 person - years

py.inc<-length(status[status==1])/per.year*100
py.inc.res<-length(status.res[status.res==1])/per.year.res*100
py.inc.no.res<-length(status.no.res[status.no.res==1])/per.year.no.res*100 #ok 

#############COVARIATES
demog.dat <- read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/dm.csv", header = TRUE, sep = ",")
sex.1<-as.character(demog.dat$SEX)
sex.1[sex.1=="F"]<-0
sex.1[sex.1=="M"]<-1
sex.1<-as.numeric(sex.1)

sex  <- match.and.merge.func(total.ids, demog.dat$DUSUBJID, sex.1) #ok 
sex.res <- match.and.merge.func(response.ids, demog.dat$DUSUBJID, sex.1)
sex.no.res <- match.and.merge.func(no.response.ids, demog.dat$DUSUBJID, sex.1)

age  <- match.and.merge.func(total.ids, demog.dat$DUSUBJID, demog.dat$AGE) #ok
age.res <- match.and.merge.func(response.ids, demog.dat$DUSUBJID, demog.dat$AGE)
age.no.res <- match.and.merge.func(no.response.ids, demog.dat$DUSUBJID, demog.dat$AGE)

country<-as.character(demog.dat$DCOUNTRY)
demog.ids.u<-unique(demog.dat$DUSUBJID)
us<-array(0,length(demog.ids.u))
for(i in 1:length(demog.ids.u)){
  temp.country<-country[demog.dat$DUSUBJID==demog.ids.u[i]]
  if(temp.country=="North America"){us[i]<-1}}

region <- match.and.merge.func(total.ids, demog.dat$DUSUBJID, us) # ok
region.res <- match.and.merge.func(response.ids, demog.dat$DUSUBJID, us)
region.no.res <- match.and.merge.func(no.response.ids, demog.dat$DUSUBJID, us)

vital.dat <- read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/vs.csv", header = TRUE, sep = ",")  
vital.dat.bl<-vital.dat[vital.dat$VSTESTCD=="BMI" & vital.dat$VSBLFL=="Y",]

value<-as.numeric(vital.dat.bl$VSORRES)
vital.ids.u<-unique(vital.dat.bl$DUSUBJID)
bmi<-array(0,length(vital.ids.u))
for(i in 1:length(vital.ids.u)){
  bmi[i]<-value[vital.dat.bl$DUSUBJID==vital.ids.u[i]]}

BMI <- match.and.merge.func(total.ids, vital.ids.u, bmi) # ok
BMI.res <- match.and.merge.func(response.ids,  vital.ids.u, bmi)
BMI.no.res <- match.and.merge.func(no.response.ids,  vital.ids.u, bmi)

qs.dat<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/qs.csv", header = TRUE, sep = ",")
qs.dat.bl<-qs.dat[qs.dat$QSBLFL=="Y",]
item<-as.character(qs.dat.bl$QSTESTCD)
qs.ids.u<-unique(as.character(qs.dat.bl$DUSUBJID))
value<-as.numeric(as.character(qs.dat.bl$QSSTRESC))

#in this trial for TD instead of AIMS they use ESRSA item "ESRSA22" which stands for "CLINICAL GLOBAL IMPRESSION OF MOVEMENT SEVERITY"
#for simplicity though, we will use similar variable names as in other trials

aiscorec.sum <- array(,length(qs.ids.u)) 
for (i in 1:length(qs.ids.u)){
  aiscorec.sum[i] <- value[(item=="ESRSA22") & (qs.dat.bl$DUSUBJID==qs.ids.u[i])]} 
aiscorec.sum[aiscorec.sum<=2] <- 0
aiscorec.sum[aiscorec.sum>2] <- 1

aims <- match.and.merge.func(total.ids, qs.ids.u, aiscorec.sum) 
aims.res <- match.and.merge.func(response.ids, qs.ids.u, aiscorec.sum) 
aims.no.res <- match.and.merge.func(no.response.ids, qs.ids.u, aiscorec.sum)  # ok

#in this trial for akathisia instead of BARS they use ESRSA item "ESRSA23" which stands for "CLINICAL GLOBAL IMPRESSION OF MOVEMENT SEVERITY"
#for simplicity though, we will use similar variable names as in other trials

bascorec.sum <- array(,length(qs.ids.u)) 
for (i in 1:length(qs.ids.u)){
  bascorec.sum[i] <- value[(item=="ESRSA23") & (qs.dat.bl$DUSUBJID==qs.ids.u[i])]} # ok
bascorec.sum[bascorec.sum<=2] <- 0
bascorec.sum[bascorec.sum>2] <- 1

bars<- match.and.merge.func(total.ids, qs.ids.u,bascorec.sum) 
bars.res<- match.and.merge.func(response.ids, qs.ids.u,bascorec.sum) 
bars.no.res<- match.and.merge.func(no.response.ids, qs.ids.u,bascorec.sum) 

cgi.bl <- array(,length(qs.ids.u))
for (i in 1:length(qs.ids.u)){
  cgi.bl[i] <- value[(item=="CGISS5") & (qs.dat.bl$DUSUBJID==qs.ids.u[i])]} 

cgi <- match.and.merge.func(total.ids, qs.ids.u, cgi.bl) 
cgi.res <- match.and.merge.func(response.ids, qs.ids.u, cgi.bl) 
cgi.no.res <- match.and.merge.func(no.response.ids, qs.ids.u, cgi.bl) #ok

habit.dat1<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/su.csv", header = TRUE, sep = ",")
habit.dat<-habit.dat1[habit.dat1$VISITNUM==1,]
habit.dat.tb<-habit.dat[habit.dat$SUTRT=="TOBACCO PRODUCTS",]

habit.dat.ids<-unique(habit.dat.tb$DUSUBJID)
smoke<-as.numeric(habit.dat.tb$SUOCCUR)
habit.dat.smoke<-array(0,length(habit.dat.ids))
for(i in 1:length(habit.dat.ids)){
  sm.temp<-smoke[habit.dat.tb$DUSUBJID==habit.dat.ids[i]]
  max.sm<-max(sm.temp, na.rm=T)
  if(max.sm==2){habit.dat.smoke[i]<-1}}

nicotine <- match.and.merge.func(total.ids, habit.dat.ids, habit.dat.smoke) #ok
nicotine.res <- match.and.merge.func(response.ids, habit.dat.ids, habit.dat.smoke) #ok
nicotine.no.res <- match.and.merge.func(no.response.ids, habit.dat.ids, habit.dat.smoke) #ok  

habit.dat1<-read.csv("X:/Data/JnJ-R092670-SCA-3004-csv/Data/su.csv", header = TRUE, sep = ",")
habit.dat<-habit.dat1[habit.dat1$VISITNUM==1,]	  
habit.dat.dr<-habit.dat[!habit.dat$SUTRT=="TOBACCO PRODUCTS",]
habit.dat.dr<-habit.dat.dr[!is.na(habit.dat.dr$SUTRT),]	

habit.dat.ids<-unique(habit.dat.dr$DUSUBJID)
drug<-as.numeric(habit.dat.dr$SUOCCUR)
habit.dat.drug<-array(0,length(habit.dat.ids))
for(i in 1:length(habit.dat.ids)){
  sm.temp<-drug[habit.dat.dr$DUSUBJID==habit.dat.ids[i]]
  sm.temp[is.na(sm.temp)]<-1
  max.sm<-max(sm.temp, na.rm=T)
  if(max.sm==2){habit.dat.drug[i]<-1}}

drug <- match.and.merge.func(total.ids, habit.dat.ids, habit.dat.drug) #ok
drug.res <- match.and.merge.func(response.ids, habit.dat.ids, habit.dat.drug) #ok
drug.no.res <- match.and.merge.func(no.response.ids, habit.dat.ids, habit.dat.drug) #ok


panss.gen1<-array(0,length(qs.ids.u))
for(i in 1:length(qs.ids.u)){
  temp.array1<-c(value[item=="G01" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="G02" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="G03" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="G04" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="G05" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="G06" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="G07" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="G08" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="G09" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="G10" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="G11" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="G12" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="G13" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="G14" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="G15" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="G16" & qs.dat.bl$DUSUBJID==qs.ids.u[i]])
  panss.gen1[i]<-sum(temp.array1, na.rm=T)}

panss.gen <- match.and.merge.func(total.ids, qs.ids.u, panss.gen1)
panss.gen.res <- match.and.merge.func(response.ids, qs.ids.u, panss.gen1)
panss.gen.no.res <- match.and.merge.func(no.response.ids, qs.ids.u, panss.gen1)

panss.neg1<-array(0,length(qs.ids.u))
for(i in 1:length(qs.ids.u)){
  temp.array1<-c(value[item=="N01" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="N02" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="N03" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="N04" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="N05" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="N06" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="N07" & qs.dat.bl$DUSUBJID==qs.ids.u[i]])
  panss.neg1[i]<-sum(temp.array1, na.rm=T)}

panss.neg <- match.and.merge.func(total.ids, qs.ids.u, panss.neg1)
panss.neg.res <- match.and.merge.func(response.ids, qs.ids.u, panss.neg1)
panss.neg.no.res <- match.and.merge.func(no.response.ids, qs.ids.u, panss.neg1)

panss.pos1<-array(0,length(qs.ids.u))
for(i in 1:length(qs.ids.u)){
  temp.array1<-c(value[item=="P01" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="P02" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="P03" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="P04" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="P05" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],value[item=="P06" & qs.dat.bl$DUSUBJID==qs.ids.u[i]],
                 value[item=="P07" & qs.dat.bl$DUSUBJID==qs.ids.u[i]])
  panss.pos1[i]<-sum(temp.array1, na.rm=T)}

panss.pos<- match.and.merge.func(total.ids, qs.ids.u, panss.pos1)
panss.pos.res <- match.and.merge.func(response.ids, qs.ids.u, panss.pos1)
panss.pos.no.res <- match.and.merge.func(no.response.ids, qs.ids.u, panss.pos1)

panss.tot<-panss.gen+panss.pos+panss.neg # ok
panss.tot.res<-panss.gen.res+panss.pos.res+panss.neg.res # ok
panss.tot.no.res<-panss.gen.no.res+panss.pos.no.res+panss.neg.no.res #ok

psp.bl <- array(,length(qs.ids.u)) 
for (i in 1:length(qs.ids.u)){
  xx <- value[item=="PSPTOT" & qs.dat.bl$DUSUBJID==qs.ids.u[i]]
  psp.bl[i]<-sum(xx, na.rm=T)
  psp.bl[psp.bl==0]<-NA}

functioning <- match.and.merge.func(total.ids, qs.ids.u, psp.bl)
functioning.res <- match.and.merge.func(response.ids, qs.ids.u, psp.bl)
functioning.no.res <- match.and.merge.func(no.response.ids, qs.ids.u, psp.bl) # ok

#in this trial for EPS instead of SARS they use ESRSA item "ESRSA20" which stands for "CLINICAL GLOBAL IMPRESSION OF MOVEMENT SEVERITY"
#for simplicity though, we will use similar variable names as in other trials

eps.temp <- array(,length(qs.ids.u)) 
for (i in 1:length(qs.ids.u)){
  eps.temp[i] <- value[(item=="ESRSA20") & (qs.dat.bl$DUSUBJID==qs.ids.u[i])]} 
eps.temp[eps.temp<=2]<-0
eps.temp[eps.temp>2]<-1

eps <- match.and.merge.func(total.ids,qs.ids.u, eps.temp)
eps.res <- match.and.merge.func(response.ids, qs.ids.u, eps.temp)
eps.no.res<- match.and.merge.func(no.response.ids, qs.ids.u, eps.temp) #ok

##COX REGRESSION

coxph(formula = surv.obj ~sex )
coxph(formula = surv.obj.res ~sex.res )
coxph(formula = surv.obj.no.res ~sex.no.res )

coxph(formula = surv.obj ~age )
coxph(formula = surv.obj.res ~age.res )
coxph(formula = surv.obj.no.res ~age.no.res )

coxph(formula = surv.obj ~region)
coxph(formula = surv.obj.res ~region.res)
coxph(formula = surv.obj.no.res ~region.no.res)

coxph(formula = surv.obj ~BMI)
coxph(formula = surv.obj.res ~BMI.res)
coxph(formula = surv.obj.no.res ~BMI.no.res)

coxph(formula = surv.obj ~aims )
coxph(formula = surv.obj.res ~aims.res )
coxph(formula = surv.obj.no.res ~aims.no.res )

coxph(formula = surv.obj ~bars)
coxph(formula = surv.obj.res ~bars.res )
coxph(formula = surv.obj.no.res ~bars.no.res )	 

coxph(formula = surv.obj ~cgi )
coxph(formula = surv.obj.res ~cgi.res )
coxph(formula = surv.obj.no.res ~cgi.no.res )

coxph(formula = surv.obj ~nicotine )
coxph(formula = surv.obj.res ~nicotine.res )
coxph(formula = surv.obj.no.res ~nicotine.no.res )

coxph(formula = surv.obj ~drug )
coxph(formula = surv.obj.res ~drug.res )
coxph(formula = surv.obj.no.res ~drug.no.res )

coxph(formula = surv.obj ~panss.gen )
coxph(formula = surv.obj.res ~panss.gen.res) 
coxph(formula = surv.obj.no.res ~panss.gen.no.res)  

coxph(formula = surv.obj ~panss.neg) 
coxph(formula = surv.obj.res ~panss.neg.res) 
coxph(formula = surv.obj.no.res ~panss.neg.no.res) 

coxph(formula = surv.obj ~panss.pos) 
coxph(formula = surv.obj.res ~panss.pos.res) 
coxph(formula = surv.obj.no.res ~panss.pos.no.res) 

coxph(formula = surv.obj ~panss.tot)
coxph(formula = surv.obj.res ~panss.tot.res)
coxph(formula = surv.obj.no.res ~panss.tot.no.res)

coxph(formula = surv.obj ~functioning) 
coxph(formula = surv.obj.res ~functioning.res) 
coxph(formula = surv.obj.no.res ~functioning.no.res) 

coxph(formula = surv.obj ~eps) 
coxph(formula = surv.obj.res ~eps.res) 
coxph(formula = surv.obj.no.res ~eps.no.res) 


ci.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex))[8])[c(3,9,12)]
ci.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age))[8])[c(3,9,12)]
ci.int.reg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region))[8])[c(3,9,12)]
ci.int.bmi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[8])[c(3,9,12)]
ci.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims))[8])[c(3,9,12)]
ci.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars))[8])[c(3,9,12)]
ci.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi))[8])[c(3,9,12)]
ci.int.nicotine<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine))[8])[c(3,9,12)]
ci.int.drug<-unlist(summary(coxph(formula = surv.obj ~rem.stat*drug))[8])[c(3,9,12)]
ci.int.panss.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot))[8])[c(3,9,12)]
ci.int.panss.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen))[8])[c(3,9,12)]
ci.int.panss.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos))[8])[c(3,9,12)]
ci.int.panss.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg))[8])[c(3,9,12)]
ci.int.functioning<-unlist(summary(coxph(formula = surv.obj ~rem.stat*functioning))[8])[c(3,9,12)]
ci.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps))[8])[c(3,9,12)]

#logHR and logSE for interaction terms
sei.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex))[7])[c(3,9)]
sei.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age))[7])[c(3,9)]
sei.int.reg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region))[7])[c(3,9)]
sei.int.bmi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI))[7])[c(3,9)]
sei.int.aims<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims))[7])[c(3,9)]
sei.int.bars<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars))[7])[c(3,9)]
sei.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi))[7])[c(3,9)]
sei.int.nicotine<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine))[7])[c(3,9)]
sei.int.drug<-unlist(summary(coxph(formula = surv.obj ~rem.stat*drug))[7])[c(3,9)]
sei.int.panss.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot))[7])[c(3,9)]
sei.int.panss.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen))[7])[c(3,9)]
sei.int.panss.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos))[7])[c(3,9)]
sei.int.panss.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg))[7])[c(3,9)]
sei.int.functioning<-unlist(summary(coxph(formula = surv.obj ~rem.stat*functioning))[7])[c(3,9)]
sei.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps))[7])[c(3,9)]

#logHR and logSE for Cox of no.remission.ids (total.ids and remission.ids, had already been calculated from CIs on previous run of analyses)
sei.sex<-unlist(summary(coxph(formula = surv.obj.no.res ~sex.no.res))[7])[c(1,3)]
sei.age<-unlist(summary(coxph(formula = surv.obj.no.res ~age.no.res))[7])[c(1,3)]
sei.reg<-unlist(summary(coxph(formula = surv.obj.no.res ~region.no.res))[7])[c(1,3)]
sei.bmi<-unlist(summary(coxph(formula = surv.obj.no.res ~BMI.no.res))[7])[c(1,3)]
sei.aims<-unlist(summary(coxph(formula = surv.obj.no.res ~aims.no.res))[7])[c(1,3)]
sei.bars<-unlist(summary(coxph(formula = surv.obj.no.res ~bars.no.res))[7])[c(1,3)]
sei.cgi<-unlist(summary(coxph(formula = surv.obj.no.res ~cgi.no.res))[7])[c(1,3)]
sei.nicotine<-unlist(summary(coxph(formula = surv.obj.no.res ~nicotine.no.res))[7])[c(1,3)]
sei.drug<-unlist(summary(coxph(formula = surv.obj.no.res ~drug.no.res))[7])[c(1,3)]
sei.panss.tot<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.tot.no.res))[7])[c(1,3)]
sei.panss.gen<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.gen.no.res))[7])[c(1,3)]
sei.panss.pos<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.pos.no.res))[7])[c(1,3)]
sei.panss.neg<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.neg.no.res))[7])[c(1,3)]
sei.functioning<-unlist(summary(coxph(formula = surv.obj.no.res ~functioning.no.res))[7])[c(1,3)]
sei.eps<-unlist(summary(coxph(formula = surv.obj.no.res ~eps.no.res))[7])[c(1,3)]

######CALCULATE HR AND 95%CI

sex.hr<-coxph(formula = surv.obj ~sex )
sex.hr.res<-coxph(formula = surv.obj.res ~sex.res )
sex.hr.no.res<-coxph(formula = surv.obj.no.res ~sex.no.res )

se.sex.hr<-sqrt(sex.hr[[2]])
beta.sex.hr<-sex.hr[[1]]

up.lim.sex.hr<-exp(beta.sex.hr+(1.96*se.sex.hr))
low.lim.sex.hr<-exp(beta.sex.hr-(1.96*se.sex.hr))
hr.sex<-exp(beta.sex.hr)

se.sex.hr.res<-sqrt(sex.hr.res[[2]])
beta.sex.hr.res<-sex.hr.res[[1]]

up.lim.sex.hr.res<-exp(beta.sex.hr.res+(1.96*se.sex.hr.res))
low.lim.sex.hr.res<-exp(beta.sex.hr.res-(1.96*se.sex.hr.res))
hr.sex.res<-exp(beta.sex.hr.res)

se.sex.hr.no.res<-sqrt(sex.hr.no.res[[2]])
beta.sex.hr.no.res<-sex.hr.no.res[[1]]

up.lim.sex.hr.no.res<-exp(beta.sex.hr.no.res+(1.96*se.sex.hr.no.res))
low.lim.sex.hr.no.res<-exp(beta.sex.hr.no.res-(1.96*se.sex.hr.no.res))
hr.sex.no.res<-exp(beta.sex.hr.no.res)

age.hr<-coxph(formula = surv.obj ~age )
age.hr.res<-coxph(formula = surv.obj.res ~age.res )
age.hr.no.res<-coxph(formula = surv.obj.no.res ~age.no.res )

se.age.hr<-sqrt(age.hr[[2]])
beta.age.hr<-age.hr[[1]]

up.lim.age.hr<-exp(beta.age.hr+(1.96*se.age.hr))
low.lim.age.hr<-exp(beta.age.hr-(1.96*se.age.hr))
hr.age<-exp(beta.age.hr)

se.age.hr.res<-sqrt(age.hr.res[[2]])
beta.age.hr.res<-age.hr.res[[1]]

up.lim.age.hr.res<-exp(beta.age.hr.res+(1.96*se.age.hr.res))
low.lim.age.hr.res<-exp(beta.age.hr.res-(1.96*se.age.hr.res))
hr.age.res<-exp(beta.age.hr.res)

se.age.hr.no.res<-sqrt(age.hr.no.res[[2]])
beta.age.hr.no.res<-age.hr.no.res[[1]]

up.lim.age.hr.no.res<-exp(beta.age.hr.no.res+(1.96*se.age.hr.no.res))
low.lim.age.hr.no.res<-exp(beta.age.hr.no.res-(1.96*se.age.hr.no.res))
hr.age.no.res<-exp(beta.age.hr.no.res)

reg.hr<-coxph(formula = surv.obj ~region)
reg.hr.res<-coxph(formula = surv.obj.res ~region.res)
reg.hr.no.res<-coxph(formula = surv.obj.no.res ~region.no.res)

se.reg.hr<-sqrt(reg.hr[[2]])
beta.reg.hr<-reg.hr[[1]]

up.lim.reg.hr<-exp(beta.reg.hr+(1.96*se.reg.hr))
low.lim.reg.hr<-exp(beta.reg.hr-(1.96*se.reg.hr))
hr.reg<-exp(beta.reg.hr)

se.reg.hr.res<-sqrt(reg.hr.res[[2]])
beta.reg.hr.res<-reg.hr.res[[1]]

up.lim.reg.hr.res<-exp(beta.reg.hr.res+(1.96*se.reg.hr.res))
low.lim.reg.hr.res<-exp(beta.reg.hr.res-(1.96*se.reg.hr.res))
hr.reg.res<-exp(beta.reg.hr.res)

se.reg.hr.no.res<-sqrt(reg.hr.no.res[[2]])
beta.reg.hr.no.res<-reg.hr.no.res[[1]]

up.lim.reg.hr.no.res<-exp(beta.reg.hr.no.res+(1.96*se.reg.hr.no.res))
low.lim.reg.hr.no.res<-exp(beta.reg.hr.no.res-(1.96*se.reg.hr.no.res))
hr.reg.no.res<-exp(beta.reg.hr.no.res)

bmi.hr<-coxph(formula = surv.obj ~BMI)
bmi.hr.res<-coxph(formula = surv.obj.res ~BMI.res)
bmi.hr.no.res<-coxph(formula = surv.obj.no.res ~BMI.no.res)

se.bmi.hr<-sqrt(bmi.hr[[2]])
beta.bmi.hr<-bmi.hr[[1]]

up.lim.bmi.hr<-exp(beta.bmi.hr+(1.96*se.bmi.hr))
low.lim.bmi.hr<-exp(beta.bmi.hr-(1.96*se.bmi.hr))
hr.bmi<-exp(beta.bmi.hr)

se.bmi.hr.res<-sqrt(bmi.hr.res[[2]])
beta.bmi.hr.res<-bmi.hr.res[[1]]

up.lim.bmi.hr.res<-exp(beta.bmi.hr.res+(1.96*se.bmi.hr.res))
low.lim.bmi.hr.res<-exp(beta.bmi.hr.res-(1.96*se.bmi.hr.res))
hr.bmi.res<-exp(beta.bmi.hr.res)

se.bmi.hr.no.res<-sqrt(bmi.hr.no.res[[2]])
beta.bmi.hr.no.res<-bmi.hr.no.res[[1]]

up.lim.bmi.hr.no.res<-exp(beta.bmi.hr.no.res+(1.96*se.bmi.hr.no.res))
low.lim.bmi.hr.no.res<-exp(beta.bmi.hr.no.res-(1.96*se.bmi.hr.no.res))
hr.bmi.no.res<-exp(beta.bmi.hr.no.res)

aim.hr<-coxph(formula = surv.obj ~aims )
aim.hr.res<-coxph(formula = surv.obj.res ~aims.res )
aim.hr.no.res<-coxph(formula = surv.obj.no.res ~aims.no.res )

se.aim.hr<-sqrt(aim.hr[[2]])
beta.aim.hr<-aim.hr[[1]]

up.lim.aim.hr<-exp(beta.aim.hr+(1.96*se.aim.hr))
low.lim.aim.hr<-exp(beta.aim.hr-(1.96*se.aim.hr))
hr.aim<-exp(beta.aim.hr)

se.aim.hr.res<-sqrt(aim.hr.res[[2]])
beta.aim.hr.res<-aim.hr.res[[1]]

up.lim.aim.hr.res<-exp(beta.aim.hr.res+(1.96*se.aim.hr.res))
low.lim.aim.hr.res<-exp(beta.aim.hr.res-(1.96*se.aim.hr.res))
hr.aim.res<-exp(beta.aim.hr.res)

se.aim.hr.no.res<-sqrt(aim.hr.no.res[[2]])
beta.aim.hr.no.res<-aim.hr.no.res[[1]]

up.lim.aim.hr.no.res<-exp(beta.aim.hr.no.res+(1.96*se.aim.hr.no.res))
low.lim.aim.hr.no.res<-exp(beta.aim.hr.no.res-(1.96*se.aim.hr.no.res))
hr.aim.no.res<-exp(beta.aim.hr.no.res)	

bar.hr<-coxph(formula = surv.obj ~bars)
bar.hr.res<-coxph(formula = surv.obj.res ~bars.res )
bar.hr.no.res<-coxph(formula = surv.obj.no.res ~bars.no.res )	 

se.bar.hr<-sqrt(bar.hr[[2]])
beta.bar.hr<-bar.hr[[1]]

up.lim.bar.hr<-exp(beta.bar.hr+(1.96*se.bar.hr))
low.lim.bar.hr<-exp(beta.bar.hr-(1.96*se.bar.hr))
hr.bar<-exp(beta.bar.hr)

se.bar.hr.res<-sqrt(bar.hr.res[[2]])
beta.bar.hr.res<-bar.hr.res[[1]]

up.lim.bar.hr.res<-exp(beta.bar.hr.res+(1.96*se.bar.hr.res))
low.lim.bar.hr.res<-exp(beta.bar.hr.res-(1.96*se.bar.hr.res))
hr.bar.res<-exp(beta.bar.hr.res)

se.bar.hr.no.res<-sqrt(bar.hr.no.res[[2]])
beta.bar.hr.no.res<-bar.hr.no.res[[1]]

up.lim.bar.hr.no.res<-exp(beta.bar.hr.no.res+(1.96*se.bar.hr.no.res))
low.lim.bar.hr.no.res<-exp(beta.bar.hr.no.res-(1.96*se.bar.hr.no.res))
hr.bar.no.res<-exp(beta.bar.hr.no.res)	

cgi.hr<-coxph(formula = surv.obj ~cgi )
cgi.hr.res<-coxph(formula = surv.obj.res ~cgi.res )
cgi.hr.no.res<-coxph(formula = surv.obj.no.res ~cgi.no.res )

se.cgi.hr<-sqrt(cgi.hr[[2]])
beta.cgi.hr<-cgi.hr[[1]]

up.lim.cgi.hr<-exp(beta.cgi.hr+(1.96*se.cgi.hr))
low.lim.cgi.hr<-exp(beta.cgi.hr-(1.96*se.cgi.hr))
hr.cgi<-exp(beta.cgi.hr)

se.cgi.hr.res<-sqrt(cgi.hr.res[[2]])
beta.cgi.hr.res<-cgi.hr.res[[1]]

up.lim.cgi.hr.res<-exp(beta.cgi.hr.res+(1.96*se.cgi.hr.res))
low.lim.cgi.hr.res<-exp(beta.cgi.hr.res-(1.96*se.cgi.hr.res))
hr.cgi.res<-exp(beta.cgi.hr.res)

se.cgi.hr.no.res<-sqrt(cgi.hr.no.res[[2]])
beta.cgi.hr.no.res<-cgi.hr.no.res[[1]]

up.lim.cgi.hr.no.res<-exp(beta.cgi.hr.no.res+(1.96*se.cgi.hr.no.res))
low.lim.cgi.hr.no.res<-exp(beta.cgi.hr.no.res-(1.96*se.cgi.hr.no.res))
hr.cgi.no.res<-exp(beta.cgi.hr.no.res)

nic.hr<-coxph(formula = surv.obj ~nicotine )
nic.hr.res<-coxph(formula = surv.obj.res ~nicotine.res )
nic.hr.no.res<-coxph(formula = surv.obj.no.res ~nicotine.no.res )

se.nic.hr<-sqrt(nic.hr[[2]])
beta.nic.hr<-nic.hr[[1]]

up.lim.nic.hr<-exp(beta.nic.hr+(1.96*se.nic.hr))
low.lim.nic.hr<-exp(beta.nic.hr-(1.96*se.nic.hr))
hr.nic<-exp(beta.nic.hr)

se.nic.hr.res<-sqrt(nic.hr.res[[2]])
beta.nic.hr.res<-nic.hr.res[[1]]

up.lim.nic.hr.res<-exp(beta.nic.hr.res+(1.96*se.nic.hr.res))
low.lim.nic.hr.res<-exp(beta.nic.hr.res-(1.96*se.nic.hr.res))
hr.nic.res<-exp(beta.nic.hr.res)

se.nic.hr.no.res<-sqrt(nic.hr.no.res[[2]])
beta.nic.hr.no.res<-nic.hr.no.res[[1]]

up.lim.nic.hr.no.res<-exp(beta.nic.hr.no.res+(1.96*se.nic.hr.no.res))
low.lim.nic.hr.no.res<-exp(beta.nic.hr.no.res-(1.96*se.nic.hr.no.res))
hr.nic.no.res<-exp(beta.nic.hr.no.res)	 

dru.hr<-coxph(formula = surv.obj ~drug )
dru.hr.res<-coxph(formula = surv.obj.res ~drug.res )
dru.hr.no.res<-coxph(formula = surv.obj.no.res ~drug.no.res )

se.dru.hr<-sqrt(dru.hr[[2]])
beta.dru.hr<-dru.hr[[1]]

up.lim.dru.hr<-exp(beta.dru.hr+(1.96*se.dru.hr))
low.lim.dru.hr<-exp(beta.dru.hr-(1.96*se.dru.hr))
hr.dru<-exp(beta.dru.hr)

se.dru.hr.res<-sqrt(dru.hr.res[[2]])
beta.dru.hr.res<-dru.hr.res[[1]]

up.lim.dru.hr.res<-exp(beta.dru.hr.res+(1.96*se.dru.hr.res))
low.lim.dru.hr.res<-exp(beta.dru.hr.res-(1.96*se.dru.hr.res))
hr.dru.res<-exp(beta.dru.hr.res)

se.dru.hr.no.res<-sqrt(dru.hr.no.res[[2]])
beta.dru.hr.no.res<-dru.hr.no.res[[1]]

up.lim.dru.hr.no.res<-exp(beta.dru.hr.no.res+(1.96*se.dru.hr.no.res))
low.lim.dru.hr.no.res<-exp(beta.dru.hr.no.res-(1.96*se.dru.hr.no.res))
hr.dru.no.res<-exp(beta.dru.hr.no.res)	 

gen.hr<-coxph(formula = surv.obj ~panss.gen )
gen.hr.res<-coxph(formula = surv.obj.res ~panss.gen.res) 
gen.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.gen.no.res)  

se.gen.hr<-sqrt(gen.hr[[2]])
beta.gen.hr<-gen.hr[[1]]

up.lim.gen.hr<-exp(beta.gen.hr+(1.96*se.gen.hr))
low.lim.gen.hr<-exp(beta.gen.hr-(1.96*se.gen.hr))
hr.gen<-exp(beta.gen.hr)

se.gen.hr.res<-sqrt(gen.hr.res[[2]])
beta.gen.hr.res<-gen.hr.res[[1]]

up.lim.gen.hr.res<-exp(beta.gen.hr.res+(1.96*se.gen.hr.res))
low.lim.gen.hr.res<-exp(beta.gen.hr.res-(1.96*se.gen.hr.res))
hr.gen.res<-exp(beta.gen.hr.res)

se.gen.hr.no.res<-sqrt(gen.hr.no.res[[2]])
beta.gen.hr.no.res<-gen.hr.no.res[[1]]

up.lim.gen.hr.no.res<-exp(beta.gen.hr.no.res+(1.96*se.gen.hr.no.res))
low.lim.gen.hr.no.res<-exp(beta.gen.hr.no.res-(1.96*se.gen.hr.no.res))
hr.gen.no.res<-exp(beta.gen.hr.no.res)	 

neg.hr<-coxph(formula = surv.obj ~panss.neg) 
neg.hr.res<-coxph(formula = surv.obj.res ~panss.neg.res) 
neg.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.neg.no.res) 

se.neg.hr<-sqrt(neg.hr[[2]])
beta.neg.hr<-neg.hr[[1]]

up.lim.neg.hr<-exp(beta.neg.hr+(1.96*se.neg.hr))
low.lim.neg.hr<-exp(beta.neg.hr-(1.96*se.neg.hr))
hr.neg<-exp(beta.neg.hr)

se.neg.hr.res<-sqrt(neg.hr.res[[2]])
beta.neg.hr.res<-neg.hr.res[[1]]

up.lim.neg.hr.res<-exp(beta.neg.hr.res+(1.96*se.neg.hr.res))
low.lim.neg.hr.res<-exp(beta.neg.hr.res-(1.96*se.neg.hr.res))
hr.neg.res<-exp(beta.neg.hr.res)

se.neg.hr.no.res<-sqrt(neg.hr.no.res[[2]])
beta.neg.hr.no.res<-neg.hr.no.res[[1]]

up.lim.neg.hr.no.res<-exp(beta.neg.hr.no.res+(1.96*se.neg.hr.no.res))
low.lim.neg.hr.no.res<-exp(beta.neg.hr.no.res-(1.96*se.neg.hr.no.res))
hr.neg.no.res<-exp(beta.neg.hr.no.res) 

pos.hr<-coxph(formula = surv.obj ~panss.pos) 
pos.hr.res<-coxph(formula = surv.obj.res ~panss.pos.res) 
pos.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.pos.no.res) 

se.pos.hr<-sqrt(pos.hr[[2]])
beta.pos.hr<-pos.hr[[1]]

up.lim.pos.hr<-exp(beta.pos.hr+(1.96*se.pos.hr))
low.lim.pos.hr<-exp(beta.pos.hr-(1.96*se.pos.hr))
hr.pos<-exp(beta.pos.hr)

se.pos.hr.res<-sqrt(pos.hr.res[[2]])
beta.pos.hr.res<-pos.hr.res[[1]]

up.lim.pos.hr.res<-exp(beta.pos.hr.res+(1.96*se.pos.hr.res))
low.lim.pos.hr.res<-exp(beta.pos.hr.res-(1.96*se.pos.hr.res))
hr.pos.res<-exp(beta.pos.hr.res)

se.pos.hr.no.res<-sqrt(pos.hr.no.res[[2]])
beta.pos.hr.no.res<-pos.hr.no.res[[1]]

up.lim.pos.hr.no.res<-exp(beta.pos.hr.no.res+(1.96*se.pos.hr.no.res))
low.lim.pos.hr.no.res<-exp(beta.pos.hr.no.res-(1.96*se.pos.hr.no.res))
hr.pos.no.res<-exp(beta.pos.hr.no.res)

tot.hr<-coxph(formula = surv.obj ~panss.tot)
tot.hr.res<-coxph(formula = surv.obj.res ~panss.tot.res)
tot.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.tot.no.res)

se.tot.hr<-sqrt(tot.hr[[2]])
beta.tot.hr<-tot.hr[[1]]

up.lim.tot.hr<-exp(beta.tot.hr+(1.96*se.tot.hr))
low.lim.tot.hr<-exp(beta.tot.hr-(1.96*se.tot.hr))
hr.tot<-exp(beta.tot.hr)

se.tot.hr.res<-sqrt(tot.hr.res[[2]])
beta.tot.hr.res<-tot.hr.res[[1]]

up.lim.tot.hr.res<-exp(beta.tot.hr.res+(1.96*se.tot.hr.res))
low.lim.tot.hr.res<-exp(beta.tot.hr.res-(1.96*se.tot.hr.res))
hr.tot.res<-exp(beta.tot.hr.res)

se.tot.hr.no.res<-sqrt(tot.hr.no.res[[2]])
beta.tot.hr.no.res<-tot.hr.no.res[[1]]

up.lim.tot.hr.no.res<-exp(beta.tot.hr.no.res+(1.96*se.tot.hr.no.res))
low.lim.tot.hr.no.res<-exp(beta.tot.hr.no.res-(1.96*se.tot.hr.no.res))
hr.tot.no.res<-exp(beta.tot.hr.no.res)	 

fun.hr<-coxph(formula = surv.obj ~functioning) 
fun.hr.res<-coxph(formula = surv.obj.res ~functioning.res) 
fun.hr.no.res<-coxph(formula = surv.obj.no.res ~functioning.no.res) 

se.fun.hr<-sqrt(fun.hr[[2]])
beta.fun.hr<-fun.hr[[1]]

up.lim.fun.hr<-exp(beta.fun.hr+(1.96*se.fun.hr))
low.lim.fun.hr<-exp(beta.fun.hr-(1.96*se.fun.hr))
hr.fun<-exp(beta.fun.hr)

se.fun.hr.res<-sqrt(fun.hr.res[[2]])
beta.fun.hr.res<-fun.hr.res[[1]]

up.lim.fun.hr.res<-exp(beta.fun.hr.res+(1.96*se.fun.hr.res))
low.lim.fun.hr.res<-exp(beta.fun.hr.res-(1.96*se.fun.hr.res))
hr.fun.res<-exp(beta.fun.hr.res)

se.fun.hr.no.res<-sqrt(fun.hr.no.res[[2]])
beta.fun.hr.no.res<-fun.hr.no.res[[1]]

up.lim.fun.hr.no.res<-exp(beta.fun.hr.no.res+(1.96*se.fun.hr.no.res))
low.lim.fun.hr.no.res<-exp(beta.fun.hr.no.res-(1.96*se.fun.hr.no.res))
hr.fun.no.res<-exp(beta.fun.hr.no.res)  

eps.hr<-coxph(formula = surv.obj ~eps) 
eps.hr.res<-coxph(formula = surv.obj.res ~eps.res) 
eps.hr.no.res<-coxph(formula = surv.obj.no.res ~eps.no.res) 

se.eps.hr<-sqrt(eps.hr[[2]])
beta.eps.hr<-eps.hr[[1]]

up.lim.eps.hr<-exp(beta.eps.hr+(1.96*se.eps.hr))
low.lim.eps.hr<-exp(beta.eps.hr-(1.96*se.eps.hr))
hr.eps<-exp(beta.eps.hr)

se.eps.hr.res<-sqrt(eps.hr.res[[2]])
beta.eps.hr.res<-eps.hr.res[[1]]

up.lim.eps.hr.res<-exp(beta.eps.hr.res+(1.96*se.eps.hr.res))
low.lim.eps.hr.res<-exp(beta.eps.hr.res-(1.96*se.eps.hr.res))
hr.eps.res<-exp(beta.eps.hr.res)

se.eps.hr.no.res<-sqrt(eps.hr.no.res[[2]])
beta.eps.hr.no.res<-eps.hr.no.res[[1]]

up.lim.eps.hr.no.res<-exp(beta.eps.hr.no.res+(1.96*se.eps.hr.no.res))
low.lim.eps.hr.no.res<-exp(beta.eps.hr.no.res-(1.96*se.eps.hr.no.res))
hr.eps.no.res<-exp(beta.eps.hr.no.res) 

#####SUMMARY TABLES

colname.desc.cont<- c("Age (mean)", "Age (SD)", "BMI (mean)", "BMI (SD)","Age at diagnosis (mean)","Age at diagnosis (SD)","Duration of illness (mean)","Duration of illness (SD)", "CGI (mean)","CGI (SD)","Psychopathology total score (mean)","Psychopathology total score (SD)", "Psychopathology general score (mean)","Psychopathology general score (SD)","Psychopathology positive score (mean)","Psychopathology positive score (SD)","Psychopathology negative score (mean)","Psychopathology negative score (SD)","General functioning score (mean)","General functioning score (SD)", "Quality of life score (mean)","Quality of life score (SD)")

mean.age<-mean(age, na.rm=T)
sd.age<-sd(age,na.rm=T)
mean.BMI<-mean(BMI,na.rm=T)
sd.BMI<-sd(BMI,na.rm=T)
mean.agediagnosis<-NA
sd.agediagnsosis<-NA
mean.doi<-NA
sd.doi<-NA
mean.cgi<-mean(cgi,na.rm=T)
sd.cgi<-sd(cgi,na.rm=T)
mean.totps<-mean(panss.tot,na.rm=T)
sd.totps<-sd(panss.tot, na.rm=T)
mean.genps<- mean(panss.gen, na.rm=T)
sd.genps<-sd(panss.gen, na.rm=T)
mean.posps<-mean(panss.pos, na.rm=T)
sd.posps<-sd(panss.pos, na.rm=T)
mean.negps<-mean(panss.neg, na.rm=T)
sd.negps<-sd(panss.neg, na.rm=T)
mean.func<-mean(functioning,na.rm=T)
sd.functioning<-sd(functioning, na.rm=T)
mean.qol<-NA
sd.qol<-NA

desc.cont<-c(mean.age,sd.age,mean.BMI,sd.BMI,mean.agediagnosis,sd.agediagnsosis,mean.doi,sd.doi,mean.cgi,sd.cgi,mean.totps,sd.totps,mean.genps,sd.genps,mean.posps,sd.posps,mean.negps,sd.negps,mean.func,sd.functioning,mean.qol,sd.qol)

desc.cont.mat<-rbind(colname.desc.cont,desc.cont)

mean.age.res<-mean(age.res, na.rm=T)
sd.age.res<-sd(age.res,na.rm=T)
mean.BMI.res<-mean(BMI.res,na.rm=T)
sd.BMI.res<-sd(BMI.res,na.rm=T)
mean.agediagnosis.res<-NA
sd.agediagnsosis.res<-NA
mean.doi.res<-NA
sd.doi.res<-NA
mean.cgi.res<-mean(cgi.res,na.rm=T)
sd.cgi.res<-sd(cgi.res,na.rm=T)
mean.totps.res<-mean(panss.tot.res,na.rm=T)
sd.totps.res<-sd(panss.tot.res, na.rm=T)
mean.genps.res<- mean(panss.gen.res, na.rm=T)
sd.genps.res<-sd(panss.gen.res, na.rm=T)
mean.posps.res<-mean(panss.pos.res, na.rm=T)
sd.posps.res<-sd(panss.pos.res, na.rm=T)
mean.negps.res<-mean(panss.neg.res, na.rm=T)
sd.negps.res<-sd(panss.neg.res, na.rm=T)
mean.func.res<-mean(functioning.res,na.rm=T)
sd.func.res<-sd(functioning.res, na.rm=T)
mean.qol.res<-NA
sd.qol.res<-NA

desc.cont.res<-c(mean.age.res,sd.age.res,mean.BMI.res,sd.BMI.res,mean.agediagnosis.res,sd.agediagnsosis.res,mean.doi.res,sd.doi.res,mean.cgi.res,sd.cgi.res,mean.totps.res,sd.totps.res,mean.genps.res,sd.genps.res,mean.posps.res,sd.posps.res,mean.negps.res,sd.negps.res,mean.func.res,sd.func.res,mean.qol.res,sd.qol.res)

desc.cont.mat.res<-rbind(colname.desc.cont,desc.cont.res)

mean.age.no.res<-mean(age.no.res, na.rm=T)
sd.age.no.res<-sd(age.no.res,na.rm=T)
mean.BMI.no.res<-mean(BMI.no.res,na.rm=T)
sd.BMI.no.res<-sd(BMI.no.res,na.rm=T)
mean.agediagnosis.no.res<-NA
sd.agediagnsosis.no.res<-NA
mean.doi.no.res<-NA
sd.doi.no.res<-NA
mean.cgi.no.res<-mean(cgi.no.res,na.rm=T)
sd.cgi.no.res<-sd(cgi.no.res,na.rm=T)
mean.totps.no.res<-mean(panss.tot.no.res,na.rm=T)
sd.totps.no.res<-sd(panss.tot.no.res, na.rm=T)
mean.genps.no.res<- mean(panss.gen.no.res, na.rm=T)
sd.genps.no.res<-sd(panss.gen.no.res, na.rm=T)
mean.posps.no.res<-mean(panss.pos.no.res, na.rm=T)
sd.posps.no.res<-sd(panss.pos.no.res, na.rm=T)
mean.negps.no.res<-mean(panss.neg.no.res, na.rm=T)
sd.negps.no.res<-sd(panss.neg.no.res, na.rm=T)
mean.func.no.res<-mean(functioning.no.res, na.rm=T)
sd.func.no.res<-sd(functioning.no.res, na.rm=T)
mean.qol.no.res<-NA
sd.qol.no.res<-NA

desc.cont.no.res<-c(mean.age.no.res,sd.age.no.res,mean.BMI.no.res,sd.BMI.no.res,mean.agediagnosis.no.res,sd.agediagnsosis.no.res,mean.doi.no.res,sd.doi.no.res,mean.cgi.no.res,sd.cgi.no.res,mean.totps.no.res,sd.totps.no.res,mean.genps.no.res,sd.genps.no.res,mean.posps.no.res,sd.posps.no.res,mean.negps.no.res,sd.negps.no.res,mean.func.no.res,sd.func.no.res,mean.qol.no.res,sd.qol.no.res)

desc.cont.mat.no.res<-rbind(colname.desc.cont,desc.cont.no.res)

colname.desc.cat<- c("Male (n)","Male (%)", "US (n)", "US (%)", "Family history (n)", "Family history (%)", "Smoking (n)", "Smoking (%)", "Drug use (n)", "Drug use (%)",">=3 prior hospitalizations(n)",">=3 prior hospitalizations (%)","Hospitalized in previous year (n)","Hospitalized in previous year (%)",">Moderate TD (n)",">Moderate TD (%)",">Moderate akathisia (n)",">Moderate akathisia (%)",">Moderate EPS (n)",">Moderate EPS (%)")

n.male<- length(sex[sex==1])
perc.male<-length(sex[sex==1])/length(sex)*100
n.us<- length(region[region==1])
perc.us<-length(region[region==1])/length(region)*100
n.fhx<- NA
perc.fhx<-NA
n.smok<- length(nicotine[nicotine==1])
perc.smok<-length(nicotine[nicotine==1])/length(nicotine)*100
n.drug<- length(drug[drug==1])
perc.drug<-length(drug[drug==1])/length(drug)*100
n.hosp.n<-NA
perc.hosp.n<-NA
n.hosp.t<-NA
perc.hosp.t<-NA
n.td<-length(aims[aims==1])
perc.td<-length(aims[aims==1])/length(aims)*100
n.aka<-length(bars[bars==1])
perc.aka<-length(bars[bars==1])/length(bars)*100
n.eps<-length(eps[eps==1])
perc.eps<-length(eps[eps==1])/length(eps)*100

desc.cat<-c(n.male,perc.male,n.us,perc.us,n.fhx,perc.fhx,n.smok,perc.smok,n.drug,perc.drug,n.hosp.n,perc.hosp.n,n.hosp.t,perc.hosp.t,n.td,perc.td,n.aka,perc.aka,n.eps,perc.eps)

desc.cat.mat<-rbind(colname.desc.cat,desc.cat)

n.male.res<- length(sex.res[sex.res==1])
perc.male.res<-length(sex.res[sex.res==1])/length(sex.res)*100
n.us.res<- length(region.res[region.res==1])
perc.us.res<-length(region.res[region.res==1])/length(region.res)*100
n.fhx.res<- NA
perc.fhx.res<-NA
n.smok.res<- length(nicotine.res[nicotine.res==1])
perc.smok.res<-length(nicotine.res[nicotine.res==1])/length(nicotine.res)*100
n.drug.res<- length(drug.res[drug.res==1])
perc.drug.res<-length(drug.res[drug.res==1])/length(drug.res)*100
n.hosp.n.res<-NA
perc.hosp.n.res<-NA
n.hosp.t.res<-NA
perc.hosp.t.res<-NA
n.td.res<-length(aims.res[aims.res==1])
perc.td.res<-length(aims.res[aims.res==1])/length(aims.res)*100
n.aka.res<-length(bars.res[bars.res==1])
perc.aka.res<-length(bars.res[bars.res==1])/length(bars.res)*100
n.eps.res<-length(eps.res[eps.res==1])
perc.eps.res<-length(eps.res[eps.res==1])/length(eps.res)*100

desc.cat.res<-c(n.male.res,perc.male.res,n.us.res,perc.us.res,n.fhx.res,perc.fhx.res,n.smok.res,perc.smok.res,n.drug.res,perc.drug.res,n.hosp.n.res,perc.hosp.n.res,n.hosp.t.res,perc.hosp.t.res,n.td.res,perc.td.res,n.aka.res,perc.aka.res,n.eps.res,perc.eps.res)

desc.cat.mat.res<-rbind(colname.desc.cat,desc.cat.res)

n.male.no.res<- length(sex.no.res[sex.no.res==1])
perc.male.no.res<-length(sex.no.res[sex.no.res==1])/length(sex.no.res)*100
n.us.no.res<- length(region.no.res[region.no.res==1])
perc.us.no.res<-length(region.no.res[region.no.res==1])/length(region.no.res)*100
n.fhx.no.res<- NA
perc.fhx.no.res<-NA
n.smok.no.res<- length(nicotine.no.res[nicotine.no.res==1])
perc.smok.no.res<-length(nicotine.no.res[nicotine.no.res==1])/length(nicotine.no.res)*100
n.drug.no.res<- length(drug.no.res[drug.no.res==1])
perc.drug.no.res<-length(drug.no.res[drug.no.res==1])/length(drug.no.res)*100
n.hosp.n.no.res<-NA
perc.hosp.n.no.res<-NA
n.hosp.t.no.res<-NA
perc.hosp.t.no.res<-NA
n.td.no.res<-length(aims.no.res[aims.no.res==1])
perc.td.no.res<-length(aims.no.res[aims.no.res==1])/length(aims.no.res)*100
n.aka.no.res<-length(bars.no.res[bars.no.res==1])
perc.aka.no.res<-length(bars.no.res[bars.no.res==1])/length(bars.no.res)*100
n.eps.no.res<-length(eps.no.res[eps.no.res==1])
perc.eps.no.res<-length(eps.no.res[eps.no.res==1])/length(eps.no.res)*100

desc.cat.no.res<-c(n.male.no.res,perc.male.no.res,n.us.no.res,perc.us.no.res,n.fhx.no.res,perc.fhx.no.res,n.smok.no.res,perc.smok.no.res,n.drug.no.res,perc.drug.no.res,n.hosp.n.no.res,perc.hosp.n.no.res,n.hosp.t.no.res,perc.hosp.t.no.res,n.td.no.res,perc.td.no.res,n.aka.no.res,perc.aka.no.res,n.eps.no.res,perc.eps.no.res)

desc.cat.mat.no.res<-rbind(colname.desc.cat,desc.cat.no.res)

colname.outc<-c("Total sample 'n'", "Relapse 'n'", "Relapse '%'", "Median time to relapse 'days'", "Events per 100 patient - years")

n.total<-length(total.ids)
n.relapse<-length(status[status==1])
perc.relapse<-length(status[status==1])/length(status)*100
median.time<-median(time.to.event, na.rm=T)
py.inc

outc<-c(n.total,n.relapse,perc.relapse,median.time,py.inc)

outc.mat<-rbind(colname.outc,outc)

n.total.res<-length(response.ids)
n.relapse.res<-length(status.res[status.res==1])
perc.relapse.res<-length(status.res[status.res==1])/length(status.res)*100
median.time.res<-median(time.to.event.res, na.rm=T)
py.inc.res

outc.res<-c(n.total.res,n.relapse.res,perc.relapse.res,median.time.res,py.inc.res)

outc.mat.res<-rbind(colname.outc,outc.res)

n.total.no.res<-length(no.response.ids)
n.relapse.no.res<-length(status.no.res[status.no.res==1])
perc.relapse.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100
median.time.no.res<-median(time.to.event.no.res, na.rm=T)
py.inc.no.res

outc.no.res<-c(n.total.no.res,n.relapse.no.res,perc.relapse.no.res,median.time.no.res,py.inc.no.res)

outc.mat.no.res<-rbind(colname.outc,outc.no.res)

colname.HR<-c("Male gender HR","Male gender Lower 95% CI","Male gender Upper 95% CI","Age HR", "Age Lower 95% CI","Age	Upper 95% CI","Proportion US HR",
              "Proportion US Lower 95% CI","Proportion US Upper 95% CI","BMI HR",  "BMI Lower 95% CI","BMI Upper 95% CI", "Age at diagnosis HR",
              "Age at diagnosis Lower 95% CI","Age at diagnosis Upper 95% CI","Duration of illness HR","Duration of illness Lower 95% CI","Duration of illness Upper 95% CI",
              "Time since last hospitalization HR","Time since last hospitalization Lower 95% CI","Time since last hospitalization Upper 95% CI",
              "Number of previous hospitalizations HR","Number of previous hospitalizations Lower 95% CI","Number of previous hospitalizations Upper 95% CI",
              "Family history HR","Family history Lower 95% CI","Family history Upper 95% CI","Smoking HR","Smoking Lower 95% CI","Smoking Upper 95% CI",
              "Drug use HR","Drug use Lower 95% CI","Drug use Upper 95% CI","CGI HR","CGI Lower 95% CI","CGI Upper 95% CI","Psychopathology total score HR",
              "Psychopathology total score Lower 95% CI","Psychopathology total score Upper 95% CI","Psychopathology general score HR",
              "Psychopathology general score Lower 95% CI","Psychopathology general score Upper 95% CI","Psychopathology positive score HR",
              "Psychopathology positive score Lower 95% CI","Psychopathology positive score Upper 95% CI","Psychopathology negative score HR",
              "Psychopathology negative score Lower 95% CI","Psychopathology negative score Upper 95% CI","General functioning score HR", 
              "General functioning score Lower 95% CI","General functioning score Upper 95% CI", "Quality of life score HR",  "Quality of life score Lower 95% CI","Quality of life score Upper 95% CI","Tardive dyskinesia score HR","Tardive dyskinesia score Lower 95% CI","Tardive dyskinesia score Upper 95% CI","Akathisia score HR","Akathisia score Lower 95% CI","Akathisia score Upper 95% CI","Parkinsonism score HR","Parkinsonism score Lower 95% CI","Parkinsonism score Upper 95% CI")

hr<- cbind(
  hr.sex,low.lim.sex.hr,up.lim.sex.hr,
  hr.age,low.lim.age.hr,up.lim.age.hr,
  hr.reg,low.lim.reg.hr,up.lim.reg.hr,
  hr.bmi,low.lim.bmi.hr,up.lim.bmi.hr,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  hr.nic,low.lim.nic.hr,up.lim.nic.hr,
  hr.dru,low.lim.dru.hr,up.lim.dru.hr,
  hr.cgi,low.lim.cgi.hr,up.lim.cgi.hr,
  hr.tot,low.lim.tot.hr,up.lim.tot.hr,
  hr.gen,low.lim.gen.hr,up.lim.gen.hr,
  hr.pos,low.lim.pos.hr,up.lim.pos.hr,
  hr.neg,low.lim.neg.hr,up.lim.neg.hr,
  hr.fun,low.lim.fun.hr,up.lim.fun.hr,
  NA,NA,NA,
  hr.aim,low.lim.aim.hr,up.lim.aim.hr,
  hr.bar,low.lim.bar.hr,up.lim.bar.hr,
  hr.eps,low.lim.eps.hr,up.lim.eps.hr)

hr.mat<-rbind(colname.HR,hr)

hr.res<- cbind(
  hr.sex.res,low.lim.sex.hr.res,up.lim.sex.hr.res,
  hr.age.res,low.lim.age.hr.res,up.lim.age.hr.res,
  hr.reg.res,low.lim.reg.hr.res,up.lim.reg.hr.res,
  hr.bmi.res,low.lim.bmi.hr.res,up.lim.bmi.hr.res,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  hr.nic.res,low.lim.nic.hr.res,up.lim.nic.hr.res,
  hr.dru.res,low.lim.dru.hr.res,up.lim.dru.hr.res,
  hr.cgi.res,low.lim.cgi.hr.res,up.lim.cgi.hr.res,
  hr.tot.res,low.lim.tot.hr.res,up.lim.tot.hr.res,
  hr.gen.res,low.lim.gen.hr.res,up.lim.gen.hr.res,
  hr.pos.res,low.lim.pos.hr.res,up.lim.pos.hr.res,
  hr.neg.res,low.lim.neg.hr.res,up.lim.neg.hr.res,
  hr.fun.res,low.lim.fun.hr.res,up.lim.fun.hr.res,
  NA,NA,NA,
  hr.aim.res,low.lim.aim.hr.res,up.lim.aim.hr.res,
  hr.bar.res,low.lim.bar.hr.res,up.lim.bar.hr.res,
  hr.eps.res,low.lim.eps.hr.res,up.lim.eps.hr.res)

hr.mat.res<-rbind(colname.HR,hr.res)

hr.no.res<- cbind(
  hr.sex.no.res,low.lim.sex.hr.no.res,up.lim.sex.hr.no.res,
  hr.age.no.res,low.lim.age.hr.no.res,up.lim.age.hr.no.res,
  hr.reg.no.res,low.lim.reg.hr.no.res,up.lim.reg.hr.no.res,
  hr.bmi.no.res,low.lim.bmi.hr.no.res,up.lim.bmi.hr.no.res,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  hr.nic.no.res,low.lim.nic.hr.no.res,up.lim.nic.hr.no.res,
  hr.dru.no.res,low.lim.dru.hr.no.res,up.lim.dru.hr.no.res,
  hr.cgi.no.res,low.lim.cgi.hr.no.res,up.lim.cgi.hr.no.res,
  hr.tot.no.res,low.lim.tot.hr.no.res,up.lim.tot.hr.no.res,
  hr.gen.no.res,low.lim.gen.hr.no.res,up.lim.gen.hr.no.res,
  hr.pos.no.res,low.lim.pos.hr.no.res,up.lim.pos.hr.no.res,
  hr.neg.no.res,low.lim.neg.hr.no.res,up.lim.neg.hr.no.res,
  hr.fun.no.res,low.lim.fun.hr.no.res,up.lim.fun.hr.no.res,
  NA,NA,NA,
  hr.aim.no.res,low.lim.aim.hr.no.res,up.lim.aim.hr.no.res,
  hr.bar.no.res,low.lim.bar.hr.no.res,up.lim.bar.hr.no.res,
  hr.eps.no.res,low.lim.eps.hr.no.res,up.lim.eps.hr.no.res)

hr.mat.no.res<-rbind(colname.HR,hr.no.res)


hr.int<- cbind(
  ci.int.sex[1],ci.int.sex[2],ci.int.sex[3],
  ci.int.age[1],ci.int.age[2],ci.int.age[3],
  ci.int.reg[1],ci.int.reg[2],ci.int.reg[3],
  ci.int.bmi[1],ci.int.bmi[2],ci.int.bmi[3],
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  NA,NA,NA,
  ci.int.nicotine[1],ci.int.nicotine[2],ci.int.nicotine[3],
  ci.int.drug[1],ci.int.drug[2],ci.int.drug[3],
  ci.int.cgi[1],ci.int.cgi[2],ci.int.cgi[3],
  ci.int.panss.tot[1],ci.int.panss.tot[2],ci.int.panss.tot[3],
  ci.int.panss.gen[1],ci.int.panss.gen[2],ci.int.panss.gen[3],
  ci.int.panss.pos[1],ci.int.panss.pos[2],ci.int.panss.pos[3],
  ci.int.panss.neg[1],ci.int.panss.neg[2],ci.int.panss.neg[3],
  ci.int.functioning[1],ci.int.functioning[2],ci.int.functioning[3],
  NA,NA,NA,
  ci.int.aims[1],ci.int.aims[2],ci.int.aims[3],
  ci.int.bars[1],ci.int.bars[2],ci.int.bars[3],
  ci.int.eps[1],ci.int.eps[2],ci.int.eps[3])

hr.int.mat<-rbind(colname.HR,hr.int)

hr.int.seiyi<-cbind(
  sei.int.sex[1],sei.int.sex[2],
  sei.int.age[1],sei.int.age[2],
  sei.int.reg[1],sei.int.reg[2],
  sei.int.bmi[1],sei.int.bmi[2],
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  sei.int.nicotine[1],sei.int.nicotine[2],
  sei.int.drug[1],sei.int.drug[2],
  sei.int.cgi[1],sei.int.cgi[2],
  sei.int.panss.tot[1],sei.int.panss.tot[2],
  sei.int.panss.gen[1],sei.int.panss.gen[2],
  sei.int.panss.pos[1],sei.int.panss.pos[2],
  sei.int.panss.neg[1],sei.int.panss.neg[2],
  sei.int.functioning[1],sei.int.functioning[2],
  NA,NA,
  sei.int.aims[1],sei.int.aims[2],
  sei.int.bars[1],sei.int.bars[2],
  sei.int.eps[1],sei.int.eps[2])

hr.nores.seiyi<-cbind(
  sei.sex[1],sei.sex[2],
  sei.age[1],sei.age[2],
  sei.reg[1],sei.reg[2],
  sei.bmi[1],sei.bmi[2],
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  NA,NA,
  sei.nicotine[1],sei.nicotine[2],
  sei.drug[1],sei.drug[2],
  sei.cgi[1],sei.cgi[2],
  sei.panss.tot[1],sei.panss.tot[2],
  sei.panss.gen[1],sei.panss.gen[2],
  sei.panss.pos[1],sei.panss.pos[2],
  sei.panss.neg[1],sei.panss.neg[2],
  sei.functioning[1],sei.functioning[2],
  NA,NA,
  sei.aims[1],sei.aims[2],
  sei.bars[1],sei.bars[2],
  sei.eps[1],sei.eps[2])


surv.obj <- Surv(time.to.event/7, status)
surv.obj.res <- Surv(time.to.event.res/7, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res/7, status.no.res)

survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)

study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)


xx<-study1.surv.fit
xx.res<-study1.surv.fit.res
xx.no.res<-study1.surv.fit.no.res


xx.t<-xx[[2]]
xx.p<-xx[[6]]

xx.t.res<-xx.res[[2]]
xx.p.res<-xx.res[[6]]

xx.t.no.res<-xx.no.res[[2]]
xx.p.no.res<-xx.no.res[[6]]

surv.mat<-cbind(xx.t,xx.p)
surv.mat.res<-cbind(xx.t.res,xx.p.res)
surv.mat.no.res<-cbind(xx.t.no.res,xx.p.no.res)

write.table(surv.mat,file="X:/Workspace/Results/surv_SCA3004_V2.csv",sep=",")
write.table(surv.mat.res,file="X:/Workspace/Results/surv_SCA3004_res_V2.csv",sep=",")
write.table(surv.mat.no.res,file="X:/Workspace/Results/surv_SCA3004_no.res_V2.csv",sep=",")

write.table(desc.cont.mat,file="X:/Workspace/Results/desc_cont_SCA3004_V2.csv",sep=",")
write.table(desc.cont.mat.res,file="X:/Workspace/Results/desc_cont_SCA3004_res_V2.csv",sep=",")
write.table(desc.cont.mat.no.res,file="X:/Workspace/Results/desc_cont_SCA3004_no.res_V2.csv",sep=",")

write.table(desc.cat.mat,file="X:/Workspace/Results/desc_cat_SCA3004_V2.csv",sep=",")
write.table(desc.cat.mat.res,file="X:/Workspace/Results/desc_cat_SCA3004_res_V2.csv",sep=",")
write.table(desc.cat.mat.no.res,file="X:/Workspace/Results/desc_cat_SCA3004_no.res_V2.csv",sep=",")

write.table(outc.mat,file="X:/Workspace/Results/outc_SCA3004_V2.csv",sep=",")
write.table(outc.mat.res,file="X:/Workspace/Results/outc_SCA3004_res_V2.csv",sep=",")
write.table(outc.mat.no.res,file="X:/Workspace/Results/outc_SCA3004_no.res_V2.csv",sep=",")

write.table(hr.mat,file="X:/Workspace/Results/hr_SCA3004_V2.csv",sep=",")
write.table(hr.mat.res,file="X:/Workspace/Results/hr_SCA3004_res_V2.csv",sep=",")
write.table(hr.mat.no.res,file="X:/Workspace/Results/hr_SCA3004_no.res_V2.csv",sep=",")
write.table(hr.int.mat,file="X:/Workspace/Results/hr.int_SCA3004_v2.csv",sep=",")

write.table(hr.int.seiyi,file="X:/Workspace/Results/hr.int.seiyi_SCA3004_v2.csv",sep=",")
write.table(hr.nores.seiyi,file="X:/Workspace/Results/hr.nores.seiyi_SCA3004_v2.csv",sep=",")

#code to calculate the relapse criteria met
#All relapses for worsening psychotic symptoms selected

#code to compare functioning between relapsers and non-relapsers

recur<-total.ids[status==1]
norecur<-intersect(total.ids[status==0],qs.dat$DUSUBJID[qs.dat$QSTESTCD=="PSPTOT"])

func.bl.rel<-array(,length(recur))
for(i in seq_along(recur)){
  func.bl.rel[i]<-functioning[total.ids==recur[i]]
}

func.bl.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
  func.bl.norel[i]<-functioning[total.ids==norecur[i]]
}

func.end.rel<-array(,length(recur))
for(i in seq_along(recur)){
  temp.visit<-qs.dat$QSDY[qs.dat$QSTESTCD=="PSPTOT" & qs.dat$DUSUBJID==recur[i]]
  max.temp.visit<-max(temp.visit,rm.na=T)
  func.end.rel[i]<-qs.dat$QSSTRESN[qs.dat$QSDY==max.temp.visit & qs.dat$QSTESTCD=="PSPTOT" & qs.dat$DUSUBJID==recur[i]]}

func.end.norel<-array(,length(norecur))
for(i in seq_along(norecur)){
  temp.visit<-qs.dat$QSDY[qs.dat$QSTESTCD=="PSPTOT" & qs.dat$DUSUBJID==norecur[i]]
  max.temp.visit<-max(temp.visit,rm.na=T)
  func.end.norel[i]<-qs.dat$QSSTRESN[qs.dat$QSDY==max.temp.visit & qs.dat$QSTESTCD=="PSPTOT" & qs.dat$DUSUBJID==norecur[i]]}

delta.func.rel<-func.end.rel-func.bl.rel
delta.func.norel<-func.end.norel - func.bl.norel

t.test(delta.func.rel,delta.func.norel)

mean(delta.func.rel,na.rm=T)
sd(delta.func.rel,na.rm=T)
mean(delta.func.norel,na.rm=T)
sd(delta.func.norel,na.rm=T)
