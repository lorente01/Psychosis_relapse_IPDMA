# Authored: Jose M Rubio M.D // jrubio13@northwell.edu
# Checked: George Schoretsanitis M.D.,PhD
# April 9th 2020

##COHORT: LILLY-F1D-MC-HGLQ
#####################################################
# a function to match and merge from two datasets

match.and.merge.func <- function(dat1.id, dat2.id, dat2.var){
  dat1.var <- array( ,length(dat1.id))
  for(i in 1:length(dat1.id)){
    for(j in 1:length(dat2.id)){
      if(dat1.id[i]==dat2.id[j]){dat1.var[i]<-dat2.var[j]}}}
  return(dat1.var)                                      }

##IDENTIFY TOTAL DATASET
#Select only subject IDs allocated to lai (TRT=OPD) 

subjinfo.dat <- read.table("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
sdy.ids.u.1<-subjinfo.dat$SUBJID[subjinfo.dat$TRT=="OPD"] 

#Exclude subject IDs who do not have assessments beyond the lead-in time deemed necessary to have a therapeutic antipsychotic serum level (2 WEEKS)
###############################
## We will use a minimal lead in time of 10wks 

subijnfo.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
exb<-subjinfo.dat$TMTRLPS

sdy.ids.threshold.1<-subjinfo.dat$SUBJID[exb>14]
sdy.ids.u.threshold.1<-unique(sdy.ids.threshold.1)

total.ids<-intersect (sdy.ids.u.1,sdy.ids.u.threshold.1) 

##########IDENTIFY 'RESPONSE' DATASET (SINCE HERE PTS WERE STABLE UPON STUDY ENTRY WE ARE TAKING THOSE WITH FIRST 2 VISITS LESS THAN MILD)(ALSO, DO NOT CONFOUND THESE WITH THE TRUE REMITTERS)

panss.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/panss.csv", header = TRUE, sep = ",")

panss.dat.res5 <- panss.dat[panss.dat$VISID==1,]
panss.grp.char5 <- as.character(panss.dat.res5$PNSD)
panss.id.u.rs5<-unique(panss.dat.res5$SUBJID)


panss.res.id5<-array(0,length(panss.id.u.rs5))

for(i in 1:length(panss.id.u.rs5)){
  temp.array1<-c(panss.dat.res5$PNSBLVAL[(panss.grp.char5=="Delusions")&(panss.dat.res5$SUBJID==panss.id.u.rs5[i])],
                 panss.dat.res5$PNSBLVAL[(panss.grp.char5=="Conceptual Disorganization")&(panss.dat.res5$SUBJID==panss.id.u.rs5[i])],
                 panss.dat.res5$PNSBLVAL[(panss.grp.char5=="Hallucinatory Behavior")&(panss.dat.res5$SUBJID==panss.id.u.rs5[i])],
                 panss.dat.res5$PNSBLVAL[(panss.grp.char5=="Excitement")&(panss.dat.res5$SUBJID==panss.id.u.rs5[i])],
                 panss.dat.res5$PNSBLVAL[(panss.grp.char5=="Suspicious/persecution")&(panss.dat.res5$SUBJID==panss.id.u.rs5[i])],
                 panss.dat.res5$PNSBLVAL[(panss.grp.char5=="Grandiosity")&(panss.dat.res5$SUBJID==panss.id.u.rs5[i])],
                 panss.dat.res5$PNSBLVAL[(panss.grp.char5=="Hostility")&(panss.dat.res5$SUBJID==panss.id.u.rs5[i])])
  max.sc.rs5<-max(temp.array1, na.rm=TRUE)
  if(max.sc.rs5<4){panss.res.id5[i]<-1}
}

response.ids.5<-panss.id.u.rs5[panss.res.id5==1]

panss.dat.res6 <- panss.dat[panss.dat$VISID==2,]
panss.grp.char6 <- as.character(panss.dat.res6$PNSD)
panss.id.u.rs6<-unique(panss.dat.res6$SUBJID)


panss.res.id6<-array(0,length(panss.id.u.rs6))

for(i in 1:length(panss.id.u.rs6)){
  temp.array1<-c(panss.dat.res6$PNSBLVAL[(panss.grp.char6=="Delusions")&(panss.dat.res6$SUBJID==panss.id.u.rs6[i])],
                 panss.dat.res6$PNSBLVAL[(panss.grp.char6=="Conceptual Disorganization")&(panss.dat.res6$SUBJID==panss.id.u.rs6[i])],
                 panss.dat.res6$PNSBLVAL[(panss.grp.char6=="Hallucinatory Behavior")&(panss.dat.res6$SUBJID==panss.id.u.rs6[i])],
                 panss.dat.res6$PNSBLVAL[(panss.grp.char6=="Excitement")&(panss.dat.res6$SUBJID==panss.id.u.rs6[i])],
                 panss.dat.res6$PNSBLVAL[(panss.grp.char6=="Suspicious/persecution")&(panss.dat.res6$SUBJID==panss.id.u.rs6[i])],
                 panss.dat.res6$PNSBLVAL[(panss.grp.char6=="Grandiosity")&(panss.dat.res6$SUBJID==panss.id.u.rs6[i])],
                 panss.dat.res6$PNSBLVAL[(panss.grp.char6=="Hostility")&(panss.dat.res6$SUBJID==panss.id.u.rs6[i])])	 
  max.sc.rs6<-max(temp.array1, na.rm=TRUE)
  if(max.sc.rs6<4){panss.res.id6[i]<-1}
}

response.ids.6<-panss.id.u.rs6[panss.res.id6==1]
response.ids.1<-intersect (response.ids.5,response.ids.6)
response.ids<-intersect (total.ids,response.ids.1) # ok 6-12-19
no.response.ids<-setdiff(total.ids,response.ids)

########DEFINE STATUS PER DATASET (1=event; 0=censor)
#here we give 1 for subjects, for whom subjinfo.dat$RLPSFLG=1

subijnfo.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
exb<-subjinfo.dat$RLPSFLG
subjinfo.ids.u<-unique(subjinfo.dat$SUBJID)

status<-match.and.merge.func(total.ids,subjinfo.ids.u,exb)  # ok 6-12-19
status.res<-match.and.merge.func(response.ids,subjinfo.ids.u,exb)  # ok 6-12-19
status.no.res<-match.and.merge.func(no.response.ids,subjinfo.ids.u,exb) 

######DEFINE TIME TO EVENT PER DATASET 
#here we take the time to relapse, which is provided by visit.dat$TMTRLPS

subijnfo.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
tmtexb<-subjinfo.dat$TMTRLPS
subjinfo.ids.u<-unique(subjinfo.dat$SUBJID)

time.to.event<-match.and.merge.func(total.ids,subjinfo.ids.u,tmtexb)  # ok 6-12-19
time.to.event.res<-match.and.merge.func(response.ids,subjinfo.ids.u,tmtexb)  # ok 6-12-19
time.to.event.no.res<-match.and.merge.func(no.response.ids,subjinfo.ids.u,tmtexb) 

######SURVIVAL ANALYSIS
library(survival)
surv.obj <- Surv(time.to.event, status)
surv.obj.res <- Surv(time.to.event.res, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res, status.no.res)

survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)

study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)

#####CALCULATE PERSON YEARS AND ABSOLUTE AND PERSON X YEAR INCIDENCE RATE
#person-year

per.year<-sum(time.to.event)/365 
per.year.res<-sum(time.to.event.res)/365 
per.year.no.res<-sum(time.to.event.no.res)/365 

#absolute incidence
abs.inc<-length(status[status==1])/length(status)*100 
abs.inc.res<-length(status.res[status.res==1])/length(status.res)*100 
abs.inc.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100 

#incidence by 100 person-years

py.inc<-length(status[status==1])/per.year*100 
py.inc.res<-length(status.res[status.res==1])/per.year.res*100 
py.inc.no.res<-length(status.no.res[status.no.res==1])/per.year.no.res*100 

rem.stat<-array(0,length(total.ids))
for(i in 1: length(total.ids)){
  for(j in 1: length(response.ids)){
    if(total.ids[i]==response.ids[j]){
      rem.stat[i]<-1	
    }
  }
}

######COVARIATES
demog.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")

#SEX
sex<- match.and.merge.func(total.ids, demog.dat$SUBJID, demog.dat$SEX) # ok 6-12-19
sex.res <- match.and.merge.func(response.ids, demog.dat$SUBJID, demog.dat$SEX) # ok 6-12-19
sex.no.res <- match.and.merge.func(no.response.ids, demog.dat$SUBJID, demog.dat$SEX) # ok 6-12-19

#AGE
age<- match.and.merge.func(total.ids, demog.dat$SUBJID, demog.dat$AGEYR) # ok 6-12-19
age.res <- match.and.merge.func(response.ids, demog.dat$SUBJID, demog.dat$AGEYR)  # ok 6-12-19
age.no.res <- match.and.merge.func(no.response.ids, demog.dat$SUBJID, demog.dat$AGEYR)  # ok 6-12-19

country<-as.character(demog.dat$COUNTRY)
demog.ids.u<-unique(demog.dat$SUBJID)
us<-array(0,length(demog.ids.u))
for(i in 1:length(demog.ids.u)){
  temp.country<-country[demog.dat$SUBJID==demog.ids.u[i]]
  if(temp.country=="US"){us[i]<-1}}

#REGION
region<- match.and.merge.func(total.ids, demog.dat$SUBJID, us) # ok 6-12-19
region.res <- match.and.merge.func(response.ids, demog.dat$SUBJID, us) # ok 6-12-19
region.no.res <- match.and.merge.func(no.response.ids, demog.dat$SUBJID, us) # ok 6-12-19

vital.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")

weight.kg<-vital.dat$WGTKGBL
height.cm<-vital.dat$HGTCMBL							                               						

weight <- match.and.merge.func(total.ids, vital.dat$SUBJID, weight.kg) # ok 6-12-19
weight.res <- match.and.merge.func(response.ids, vital.dat$SUBJID, weight.kg) # ok 6-12-19
weight.no.res <- match.and.merge.func(no.response.ids, vital.dat$SUBJID, weight.kg)

height <- match.and.merge.func(total.ids, vital.dat$SUBJID, height.cm) # ok 6-12-19
height.res <- match.and.merge.func(response.ids, vital.dat$SUBJID, height.cm) # ok 6-12-19
height.no.res <- match.and.merge.func(no.response.ids, vital.dat$SUBJID, height.cm)

BMI<-weight/(height/100)^2  # ok 6-12-19
BMI.res<-weight.res/(height.res/100)^2 # ok 6-12-19
BMI.no.res<-weight.no.res/(height.no.res/100)^2


#AIMS
aims.dat<- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/aims.csv", header=TRUE, sep=",")
ad1 <- aims.dat[(aims.dat$AIMSBLFLG==1)&(aims.dat$AIMSQSNUM=="AIMSS8"),] 
ad1.ids.u <- unique(ad1$SUBJID) #here we select the unique IDs
aiscorec.sum <- array(,length(ad1.ids.u)) 
for (i in 1:length(ad1.ids.u)){
  temp<-ad1$AIMSRN[ad1$SUBJID==ad1.ids.u[i]]
  if(temp>2){aiscorec.sum[i] <- 1 }else{aiscorec.sum[i] <- 0}}

aims <- match.and.merge.func(total.ids, ad1.ids.u, aiscorec.sum) # ok 6-12-19
aims.res <- match.and.merge.func(response.ids, ad1.ids.u, aiscorec.sum) # ok 6-12-19
aims.no.res <- match.and.merge.func(no.response.ids, ad1.ids.u, aiscorec.sum)

#BARS
bars.dat<- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/barnes.csv", header=TRUE, sep=",")
ba1<-bars.dat[(bars.dat$BARBLFLG==1)&(bars.dat$BARQSNUM=="BARS4"),] 
ba1.ids.u <- unique(ba1$SUBJID)
bascorec.sum <-array(,length(ba1.ids.u))	
for (i in 1:length(ba1.ids.u)){
  temp<-ba1$BARRN[ba1$SUBJID==ba1.ids.u[i]]
  if(temp>2){bascorec.sum[i]<-1}else{bascorec.sum[i]<-0}}

bars <- match.and.merge.func(total.ids, ba1.ids.u,bascorec.sum) # ok 6-12-19
bars.res<- match.and.merge.func(response.ids, ba1.ids.u,bascorec.sum) # ok 6-12-19
bars.no.res<- match.and.merge.func(no.response.ids, ba1.ids.u,bascorec.sum)

#CGI
cgi.dat<- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/gi.csv", header=TRUE, sep=",")
cgi1 <- cgi.dat[(cgi.dat$GIBLFLG==1)&(cgi.dat$GIQSNUM=="CGISS"),]
cgi.ids.u <- unique(cgi1$SUBJID) 
cgi.bl <- array(,length(cgi.ids.u)) 
for (i in 1:length(cgi.ids.u)){
  cgi.bl[i] <- cgi1$GIRN[cgi1$SUBJID==cgi.ids.u[i]]
}

cgi <- match.and.merge.func(total.ids, cgi.ids.u, cgi.bl) # ok 6-12-19	 
cgi.res <- match.and.merge.func(response.ids, cgi.ids.u, cgi.bl) # ok 6-12-19
cgi.no.res <- match.and.merge.func(no.response.ids, cgi.ids.u, cgi.bl)

###AGE AT DIAGNOSIS
date.dat<- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
date.bl<-as.Date(date.dat$ENRLDT,"%d%B%Y")
date.bl1<-as.character(date.bl)
year.bl.d.1<-substr(date.bl1,1,4)
year.bl.1<- as.numeric(year.bl.d.1)

year.bl <- match.and.merge.func(total.ids, date.dat$SUBJID, year.bl.1)	     
year.bl.res <- match.and.merge.func(response.ids, date.dat$SUBJID, year.bl.1)
year.bl.no.res <- match.and.merge.func(no.response.ids, date.dat$SUBJID, year.bl.1)

psyhistp.table <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/mh.csv", header=TRUE, sep=",")

onset<-psyhistp.table[psyhistp.table$MHQSNUM == "FSTEPIDTYY",] 
onset.ids.u <- unique(onset$SUBJID)
onset.year<-as.numeric(as.character(onset$MHRN))	

onset.sum <-array(,length(onset.ids.u))

for (i in 1:length(onset.ids.u)){
  onset.sum[i]<-onset.year[onset$SUBJID==onset.ids.u[i]]}

year.onset<- match.and.merge.func(total.ids, onset.ids.u, onset.sum)
year.onset.res <- match.and.merge.func(response.ids, onset.ids.u, onset.sum)   	
year.onset.no.res <- match.and.merge.func(no.response.ids, onset.ids.u, onset.sum) 

#DOI
doi<- year.bl - year.onset # ok 6-13-19
doi.res<- year.bl.res - year.onset.res  # ok 6-13-19
doi.no.res<- year.bl.no.res - year.onset.no.res

age.diag<-age-doi  # ok 6-13-19 
age.diag.res <- age.res-doi.res   # ok 6-13-19
age.diag.no.res <- age.no.res-doi.no.res

subjinfo.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
tobacco<-subjinfo.dat$TBBL

#SMOKING
nicotine <- match.and.merge.func(total.ids, subjinfo.dat$SUBJID, tobacco)  # ok 6-13-19
nicotine.res <- match.and.merge.func(response.ids, subjinfo.dat$SUBJID, tobacco)  # ok 6-13-19
nicotine.no.res <- match.and.merge.func(no.response.ids, subjinfo.dat$SUBJID, tobacco)

#PANSS
panss.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/panss.csv", header=TRUE, sep=",")
panss.dat.bas <- panss.dat[panss.dat$PNSBLFLG == 1,]
panss.id.u<-unique(panss.dat.bas$SUBJID)

panss.general<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  panss.general[i]<-panss.dat.bas$PNSRN[(panss.dat.bas$SUBJID==panss.id.u[i]) & (panss.dat.bas$PNSQSNUM=="PNSPSYP")]}

panss.gen <- match.and.merge.func(total.ids, panss.id.u, panss.general)  # ok 6-13-19
panss.gen.res <- match.and.merge.func(response.ids, panss.id.u, panss.general)  # ok 6-13-19
panss.gen.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.general)

panss.total<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  panss.total[i]<-panss.dat.bas$PNSRN[(panss.dat.bas$SUBJID==panss.id.u[i]) & (panss.dat.bas$PNSQSNUM=="PNS30TS")]}

panss.tot <- match.and.merge.func(total.ids, panss.id.u, panss.total)  # ok 6-13-19
panss.tot.res <- match.and.merge.func(response.ids, panss.id.u, panss.total)  # ok 6-13-19
panss.tot.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.total)

panss.negative<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  panss.negative[i]<-panss.dat.bas$PNSRN[(panss.dat.bas$SUBJID==panss.id.u[i]) & (panss.dat.bas$PNSQSNUM=="PNSNEG")]}

panss.neg <- match.and.merge.func(total.ids, panss.id.u, panss.negative)  # ok 6-13-19
panss.neg.res <- match.and.merge.func(response.ids, panss.id.u, panss.negative)  # ok 6-13-19
panss.neg.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.negative)

panss.positive<-array(,length(panss.id.u))
for(i in 1:length(panss.id.u)){
  panss.positive[i]<-panss.dat.bas$PNSRN[(panss.dat.bas$SUBJID==panss.id.u[i]) & (panss.dat.bas$PNSQSNUM=="PNSPS")]}

panss.pos <- match.and.merge.func(total.ids, panss.id.u, panss.positive)  # ok 6-13-19
panss.pos.res <- match.and.merge.func(response.ids, panss.id.u, panss.positive)  # ok 6-13-19
panss.pos.no.res <- match.and.merge.func(no.response.ids, panss.id.u, panss.positive)

simpson.dat<-read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/sa.csv", header=TRUE, sep=",")

simpson <- simpson.dat[(simpson.dat$SABLFLG==1)&(simpson.dat$SAQSNUM=="SATS"),] 
simpson.ids.u <- unique(simpson$SUBJID) #here we select the unique IDs
simpson.tot <- array(,length(ad1.ids.u)) 
for (i in 1:length(ad1.ids.u)){
  temp.array <- simpson$SARN[simpson$SUBJID==simpson.ids.u[i]]
  temp.array2<-sum(temp.array,na.rm=T)/10
  if(temp.array2>0.65){simpson.tot[i] <- 1}else{simpson.tot[i]<-0}} 

eps <- match.and.merge.func(total.ids, simpson.ids.u, simpson.tot) # ok 6-13-19
eps.res <- match.and.merge.func(response.ids, simpson.ids.u, simpson.tot) # ok 6-13-19
eps.no.res <- match.and.merge.func(no.response.ids, simpson.ids.u, simpson.tot)

psyhistp.table <- read.table("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/mh.csv", header=TRUE, sep=",")
psyhistp.id.u<-unique(psyhistp.table$SUBJID)
pr.ep1<-psyhistp.table$MHRN[psyhistp.table$MHQSNUM == "MHN"]
pr.ep.num<-as.numeric(as.character(pr.ep1))
pr.ep.num[pr.ep.num<3]<-0
pr.ep.num[pr.ep.num>2]<-1

##PREVIOUS EPISODES    
pr.ep  <- match.and.merge.func(total.ids, psyhistp.id.u, pr.ep.num) # ok 6-13-19
pr.ep.res  <- match.and.merge.func(response.ids, psyhistp.id.u, pr.ep.num) # ok 6-13-19
pr.ep.no.res  <- match.and.merge.func(no.response.ids, psyhistp.id.u, pr.ep.num)

psyhistp.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/mh.csv", header=TRUE, sep=",")
psyhistp.id.u<-unique(psyhistp.table$SUBJID) 
date.dc1.1.1<-psyhistp.dat$MHRN[psyhistp.dat$MHQSNUM == "MRDT"]
date.dc1.1<-as.character(date.dc1.1.1) 

date.dc1<-match.and.merge.func(total.ids, psyhistp.id.u, date.dc1.1)     
date.dc1.res<-match.and.merge.func(response.ids, psyhistp.id.u, date.dc1.1)    
date.dc1.no.res<-match.and.merge.func(no.response.ids, psyhistp.id.u, date.dc1.1) 

date.dc<-as.Date(date.dc1)
date.dc.res<-as.Date(date.dc1.res)
date.dc.no.res<-as.Date(date.dc1.no.res)

subjinfo.dat <- read.csv("E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/Analysis Datasets/R_analysis/subjinfo.csv", header=TRUE, sep=",")
subjinfo.id.u<-unique(subjinfo.dat$SUBJID)     
date.bl<-as.Date(subjinfo.dat$ENRLDTTMC)
date.bl1<-as.character(date.bl)

date.bl.1<-match.and.merge.func(total.ids, subjinfo.dat$SUBJID, date.bl1)     
date.bl.1.res<-match.and.merge.func(response.ids, subjinfo.dat$SUBJID, date.bl1)
date.bl.1.no.res<-match.and.merge.func(no.response.ids, subjinfo.dat$SUBJID, date.bl1)

date.bl.d.1<-as.Date(date.bl.1)
date.bl.d.1.res<-as.Date(date.bl.1.res)
date.bl.d.1.no.res<-as.Date(date.bl.1.no.res)

##LAST HOSPITALIZATION
last.hosp<-date.bl.d.1-date.dc  # ok 6-13-19
last.hosp[last.hosp<365]<-1
last.hosp[last.hosp>364]<-0

last.hosp.res<-date.bl.d.1.res-date.dc.res  # ok 6-13-19
last.hosp.res[last.hosp.res<365]<-1
last.hosp.res[last.hosp.res>364]<-0

last.hosp.no.res<-date.bl.d.1.no.res-date.dc.no.res  # ok 6-13-19
last.hosp.no.res[last.hosp.no.res<365]<-1
last.hosp.no.res[last.hosp.no.res>364]<-0

#####COX REGRESSION

coxph(formula = surv.obj ~sex )
coxph(formula = surv.obj.res ~sex.res )
coxph(formula = surv.obj.no.res ~sex.no.res )

coxph(formula = surv.obj ~age )
coxph(formula = surv.obj.res ~age.res )
coxph(formula = surv.obj.res ~age.no.res )

coxph(formula = surv.obj ~region)
coxph(formula = surv.obj.res ~region.res)
coxph(formula = surv.obj.no.res ~region.no.res)

coxph(formula = surv.obj ~BMI)
coxph(formula = surv.obj.res ~BMI.res)
coxph(formula = surv.obj.no.res ~BMI.no.res)

coxph(formula = surv.obj ~aims )
coxph(formula = surv.obj.res ~aims.res )
coxph(formula = surv.obj.no.res ~aims.no.res )

coxph(formula = surv.obj ~bars )
coxph(formula = surv.obj.res ~bars.res )	 
coxph(formula = surv.obj.no.res ~bars.no.res )

coxph(formula = surv.obj ~cgi )
coxph(formula = surv.obj.res ~cgi.res )
coxph(formula = surv.obj.no.res ~cgi.no.res )

coxph(formula = surv.obj ~age.diag )
coxph(formula = surv.obj.res ~age.diag.res )
coxph(formula = surv.obj.no.res ~age.diag.no.res )

coxph(formula = surv.obj ~doi)
coxph(formula = surv.obj.res ~doi.res)
coxph(formula = surv.obj.no.res ~doi.no.res)

coxph(formula = surv.obj ~nicotine )
coxph(formula = surv.obj.res ~nicotine.res )
coxph(formula = surv.obj.no.res ~nicotine.no.res )

coxph(formula = surv.obj ~panss.gen) 	 
coxph(formula = surv.obj.res ~panss.gen.res) 
coxph(formula = surv.obj.no.res ~panss.gen.no.res) 

coxph(formula = surv.obj ~panss.neg)
coxph(formula = surv.obj.res ~panss.neg.res) 
coxph(formula = surv.obj.no.res ~panss.neg.no.res) 

coxph(formula = surv.obj ~panss.pos)
coxph(formula = surv.obj.res ~panss.pos.res) 
coxph(formula = surv.obj.no.res ~panss.pos.no.res)

coxph(formula = surv.obj ~panss.tot)
coxph(formula = surv.obj.res ~panss.tot.res)
coxph(formula = surv.obj.no.res ~panss.tot.no.res)

coxph(formula = surv.obj ~pr.ep)
coxph(formula = surv.obj.res ~pr.ep.res) 
coxph(formula = surv.obj.no.res ~pr.ep.no.res) 	

coxph(formula = surv.obj ~last.hosp) 
coxph(formula = surv.obj.res ~last.hosp.res) 
coxph(formula = surv.obj.no.res ~last.hosp.no.res) 

coxph(formula = surv.obj ~eps)
coxph(formula = surv.obj.res ~eps.res) 
coxph(formula = surv.obj.no.res ~eps.no.res)

#HR and 95%CI for interaction terms
ci.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex ))[8])[c(3,9,12)]
ci.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age ))[8])[c(3,9,12)]
ci.int.region<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region ))[8])[c(3,9,12)]
ci.int.BMI<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI ))[8])[c(3,9,12)]
ci.int.aim<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims ))[8])[c(3,9,12)]
ci.int.bar<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars ))[8])[c(3,9,12)]
ci.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi ))[8])[c(3,9,12)]
ci.int.dia<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age.diag ))[8])[c(3,9,12)]
ci.int.doi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*doi ))[8])[c(3,9,12)]
ci.int.nic<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine ))[8])[c(3,9,12)]
ci.int.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen ))[8])[c(3,9,12)]
ci.int.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg ))[8])[c(3,9,12)]
ci.int.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos ))[8])[c(3,9,12)]
ci.int.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot ))[8])[c(3,9,12)]
ci.int.pre<-unlist(summary(coxph(formula = surv.obj ~rem.stat*pr.ep ))[8])[c(3,9,12)]
ci.int.las<-unlist(summary(coxph(formula = surv.obj ~rem.stat*last.hosp ))[8])[c(3,9,12)]
ci.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps ))[8])[c(3,9,12)]

#LogHR and LogSE for interaction terms
sei.int.sex<-unlist(summary(coxph(formula = surv.obj ~rem.stat*sex ))[7])[c(3,9)]
sei.int.age<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age ))[7])[c(3,9)]
sei.int.region<-unlist(summary(coxph(formula = surv.obj ~rem.stat*region ))[7])[c(3,9)]
sei.int.BMI<-unlist(summary(coxph(formula = surv.obj ~rem.stat*BMI ))[7])[c(3,9)]
sei.int.aim<-unlist(summary(coxph(formula = surv.obj ~rem.stat*aims ))[7])[c(3,9)]
sei.int.bar<-unlist(summary(coxph(formula = surv.obj ~rem.stat*bars ))[7])[c(3,9)]
sei.int.cgi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*cgi ))[7])[c(3,9)]
sei.int.dia<-unlist(summary(coxph(formula = surv.obj ~rem.stat*age.diag ))[7])[c(3,9)]
sei.int.doi<-unlist(summary(coxph(formula = surv.obj ~rem.stat*doi ))[7])[c(3,9)]
sei.int.nic<-unlist(summary(coxph(formula = surv.obj ~rem.stat*nicotine ))[7])[c(3,9)]
sei.int.gen<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.gen ))[7])[c(3,9)]
sei.int.neg<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.neg ))[7])[c(3,9)]
sei.int.pos<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.pos ))[7])[c(3,9)]
sei.int.tot<-unlist(summary(coxph(formula = surv.obj ~rem.stat*panss.tot ))[7])[c(3,9)]
sei.int.pre<-unlist(summary(coxph(formula = surv.obj ~rem.stat*pr.ep ))[7])[c(3,9)]
sei.int.las<-unlist(summary(coxph(formula = surv.obj ~rem.stat*last.hosp ))[7])[c(3,9)]
sei.int.eps<-unlist(summary(coxph(formula = surv.obj ~rem.stat*eps ))[7])[c(3,9)]

#LogHR and LogSE for no.response.ids
sei.sex<-unlist(summary(coxph(formula = surv.obj.no.res ~sex.no.res ))[7])[c(1,3)]
sei.age<-unlist(summary(coxph(formula = surv.obj.no.res ~age.no.res))[7])[c(1,3)]
sei.region<-unlist(summary(coxph(formula = surv.obj.no.res ~region.no.res ))[7])[c(1,3)]
sei.BMI<-unlist(summary(coxph(formula = surv.obj.no.res~BMI.no.res))[7])[c(1,3)]
sei.aim<-unlist(summary(coxph(formula = surv.obj.no.res ~aims.no.res ))[7])[c(1,3)]
sei.bar<-unlist(summary(coxph(formula = surv.obj.no.res ~bars.no.res ))[7])[c(1,3)]
sei.cgi<-unlist(summary(coxph(formula = surv.obj.no.res ~cgi.no.res))[7])[c(1,3)]
sei.dia<-unlist(summary(coxph(formula = surv.obj.no.res ~age.diag.no.res ))[7])[c(1,3)]
sei.doi<-unlist(summary(coxph(formula = surv.obj.no.res ~doi.no.res))[7])[c(1,3)]
sei.nic<-unlist(summary(coxph(formula = surv.obj.no.res ~nicotine.no.res ))[7])[c(1,3)]
sei.gen<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.gen.no.res ))[7])[c(1,3)]
sei.neg<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.neg.no.res))[7])[c(1,3)]
sei.pos<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.pos.no.res ))[7])[c(1,3)]
sei.tot<-unlist(summary(coxph(formula = surv.obj.no.res ~panss.tot.no.res ))[7])[c(1,3)]
sei.pre<-unlist(summary(coxph(formula = surv.obj.no.res ~pr.ep.no.res))[7])[c(1,3)]
sei.las<-unlist(summary(coxph(formula = surv.obj.no.res ~last.hosp.no.res))[7])[c(1,3)]
sei.eps<-unlist(summary(coxph(formula = surv.obj.no.res ~eps.no.res))[7])[c(1,3)]

######CALCULATE HR AND 95%CI

sex.hr<-coxph(formula = surv.obj ~sex )
sex.hr.res<-coxph(formula = surv.obj.res ~sex.res )
sex.hr.no.res<-coxph(formula = surv.obj.no.res ~sex.no.res )

se.sex.hr<-sqrt(sex.hr[[2]])
beta.sex.hr<-sex.hr[[1]]

up.lim.sex.hr<-exp(beta.sex.hr+(1.96*se.sex.hr))
low.lim.sex.hr<-exp(beta.sex.hr-(1.96*se.sex.hr))
hr.sex<-exp(beta.sex.hr)

se.sex.hr.res<-sqrt(sex.hr.res[[2]])
beta.sex.hr.res<-sex.hr.res[[1]]

up.lim.sex.hr.res<-exp(beta.sex.hr.res+(1.96*se.sex.hr.res))
low.lim.sex.hr.res<-exp(beta.sex.hr.res-(1.96*se.sex.hr.res))
hr.sex.res<-exp(beta.sex.hr.res)

se.sex.hr.no.res<-sqrt(sex.hr.no.res[[2]])
beta.sex.hr.no.res<-sex.hr.no.res[[1]]

up.lim.sex.hr.no.res<-exp(beta.sex.hr.no.res+(1.96*se.sex.hr.no.res))
low.lim.sex.hr.no.res<-exp(beta.sex.hr.no.res-(1.96*se.sex.hr.no.res))
hr.sex.no.res<-exp(beta.sex.hr.no.res)

age.hr<-coxph(formula = surv.obj ~age )
age.hr.res<-coxph(formula = surv.obj.res ~age.res )
age.hr.no.res<-coxph(formula = surv.obj.no.res ~age.no.res )

se.age.hr<-sqrt(age.hr[[2]])
beta.age.hr<-age.hr[[1]]

up.lim.age.hr<-exp(beta.age.hr+(1.96*se.age.hr))
low.lim.age.hr<-exp(beta.age.hr-(1.96*se.age.hr))
hr.age<-exp(beta.age.hr)

se.age.hr.res<-sqrt(age.hr.res[[2]])
beta.age.hr.res<-age.hr.res[[1]]

up.lim.age.hr.res<-exp(beta.age.hr.res+(1.96*se.age.hr.res))
low.lim.age.hr.res<-exp(beta.age.hr.res-(1.96*se.age.hr.res))
hr.age.res<-exp(beta.age.hr.res)

se.age.hr.no.res<-sqrt(age.hr.no.res[[2]])
beta.age.hr.no.res<-age.hr.no.res[[1]]

up.lim.age.hr.no.res<-exp(beta.age.hr.no.res+(1.96*se.age.hr.no.res))
low.lim.age.hr.no.res<-exp(beta.age.hr.no.res-(1.96*se.age.hr.no.res))
hr.age.no.res<-exp(beta.age.hr.no.res)

reg.hr<-coxph(formula = surv.obj ~region)

se.reg.hr<-sqrt(reg.hr[[2]])
beta.reg.hr<-reg.hr[[1]]

up.lim.reg.hr<-exp(beta.reg.hr+(1.96*se.reg.hr))
low.lim.reg.hr<-exp(beta.reg.hr-(1.96*se.reg.hr))

hr.reg<-exp(beta.reg.hr)

reg.hr.res<-coxph(formula = surv.obj.res ~region.res)

se.reg.hr.res<-sqrt(reg.hr.res[[2]])
beta.reg.hr.res<-reg.hr.res[[1]]

up.lim.reg.hr.res<-exp(beta.reg.hr.res+(1.96*se.reg.hr.res))
low.lim.reg.hr.res<-exp(beta.reg.hr.res-(1.96*se.reg.hr.res))

hr.reg.res<-exp(beta.reg.hr.res)

reg.hr.no.res<-coxph(formula = surv.obj.no.res ~region.no.res)

se.reg.hr.no.res<-sqrt(reg.hr.no.res[[2]])
beta.reg.hr.no.res<-reg.hr.no.res[[1]]

up.lim.reg.hr.no.res<-exp(beta.reg.hr.no.res+(1.96*se.reg.hr.no.res))
low.lim.reg.hr.no.res<-exp(beta.reg.hr.no.res-(1.96*se.reg.hr.no.res))

hr.reg.no.res<-exp(beta.reg.hr.no.res)

bmi.hr<-coxph(formula = surv.obj ~BMI)
bmi.hr.res<-coxph(formula = surv.obj.res ~BMI.res)
bmi.hr.no.res<-coxph(formula = surv.obj.no.res ~BMI.no.res)

se.bmi.hr<-sqrt(bmi.hr[[2]])
beta.bmi.hr<-bmi.hr[[1]]

up.lim.bmi.hr<-exp(beta.bmi.hr+(1.96*se.bmi.hr))
low.lim.bmi.hr<-exp(beta.bmi.hr-(1.96*se.bmi.hr))
hr.bmi<-exp(beta.bmi.hr)

se.bmi.hr.res<-sqrt(bmi.hr.res[[2]])
beta.bmi.hr.res<-bmi.hr.res[[1]]

up.lim.bmi.hr.res<-exp(beta.bmi.hr.res+(1.96*se.bmi.hr.res))
low.lim.bmi.hr.res<-exp(beta.bmi.hr.res-(1.96*se.bmi.hr.res))
hr.bmi.res<-exp(beta.bmi.hr.res)

se.bmi.hr.no.res<-sqrt(bmi.hr.no.res[[2]])
beta.bmi.hr.no.res<-bmi.hr.no.res[[1]]

up.lim.bmi.hr.no.res<-exp(beta.bmi.hr.no.res+(1.96*se.bmi.hr.no.res))
low.lim.bmi.hr.no.res<-exp(beta.bmi.hr.no.res-(1.96*se.bmi.hr.no.res))
hr.bmi.no.res<-exp(beta.bmi.hr.no.res)

aim.hr<-coxph(formula = surv.obj ~aims )

se.aim.hr<-sqrt(aim.hr[[2]])
beta.aim.hr<-aim.hr[[1]]

up.lim.aim.hr<-exp(beta.aim.hr+(1.96*se.aim.hr))
low.lim.aim.hr<-exp(beta.aim.hr-(1.96*se.aim.hr))
hr.aim<-exp(beta.aim.hr)

aim.hr.res<-coxph(formula = surv.obj.res ~aims.res )

se.aim.hr.res<-sqrt(aim.hr.res[[2]])
beta.aim.hr.res<-aim.hr.res[[1]]

up.lim.aim.hr.res<-exp(beta.aim.hr.res+(1.96*se.aim.hr.res))
low.lim.aim.hr.res<-exp(beta.aim.hr.res-(1.96*se.aim.hr.res))
hr.aim.res<-exp(beta.aim.hr.res)

aim.hr.no.res<-coxph(formula = surv.obj.no.res ~aims.no.res )

se.aim.hr.no.res<-sqrt(aim.hr.no.res[[2]])
beta.aim.hr.no.res<-aim.hr.no.res[[1]]

up.lim.aim.hr.no.res<-exp(beta.aim.hr.no.res+(1.96*se.aim.hr.no.res))
low.lim.aim.hr.no.res<-exp(beta.aim.hr.no.res-(1.96*se.aim.hr.no.res))
hr.aim.no.res<-exp(beta.aim.hr.no.res)

bar.hr<-coxph(formula = surv.obj ~bars )

se.bar.hr<-sqrt(bar.hr[[2]])
beta.bar.hr<-bar.hr[[1]]

up.lim.bar.hr<-exp(beta.bar.hr+(1.96*se.bar.hr))
low.lim.bar.hr<-exp(beta.bar.hr-(1.96*se.bar.hr))
hr.bar<-exp(beta.bar.hr)

bar.hr.res<-coxph(formula = surv.obj.res ~bars.res )

se.bar.hr.res<-sqrt(bar.hr.res[[2]])
beta.bar.hr.res<-bar.hr.res[[1]]

up.lim.bar.hr.res<-exp(beta.bar.hr.res+(1.96*se.bar.hr.res))
low.lim.bar.hr.res<-exp(beta.bar.hr.res-(1.96*se.bar.hr.res))
hr.bar.res<-exp(beta.bar.hr.res)

bar.hr.no.res<-coxph(formula = surv.obj.no.res ~bars.no.res )

se.bar.hr.no.res<-sqrt(bar.hr.no.res[[2]])
beta.bar.hr.no.res<-bar.hr.no.res[[1]]

up.lim.bar.hr.no.res<-exp(beta.bar.hr.no.res+(1.96*se.bar.hr.no.res))
low.lim.bar.hr.no.res<-exp(beta.bar.hr.no.res-(1.96*se.bar.hr.no.res))
hr.bar.no.res<-exp(beta.bar.hr.no.res)

cgi.hr<-coxph(formula = surv.obj ~cgi )

se.cgi.hr<-sqrt(cgi.hr[[2]])
beta.cgi.hr<-cgi.hr[[1]]

up.lim.cgi.hr<-exp(beta.cgi.hr+(1.96*se.cgi.hr))
low.lim.cgi.hr<-exp(beta.cgi.hr-(1.96*se.cgi.hr))
hr.cgi<-exp(beta.cgi.hr)

cgi.hr.res<-coxph(formula = surv.obj.res ~cgi.res )

se.cgi.hr.res<-sqrt(cgi.hr.res[[2]])
beta.cgi.hr.res<-cgi.hr.res[[1]]

up.lim.cgi.hr.res<-exp(beta.cgi.hr.res+(1.96*se.cgi.hr.res))
low.lim.cgi.hr.res<-exp(beta.cgi.hr.res-(1.96*se.cgi.hr.res))
hr.cgi.res<-exp(beta.cgi.hr.res)

cgi.hr.no.res<-coxph(formula = surv.obj.no.res ~cgi.no.res )

se.cgi.hr.no.res<-sqrt(cgi.hr.no.res[[2]])
beta.cgi.hr.no.res<-cgi.hr.no.res[[1]]

up.lim.cgi.hr.no.res<-exp(beta.cgi.hr.no.res+(1.96*se.cgi.hr.no.res))
low.lim.cgi.hr.no.res<-exp(beta.cgi.hr.no.res-(1.96*se.cgi.hr.no.res))
hr.cgi.no.res<-exp(beta.cgi.hr.no.res)

dia.hr<-coxph(formula = surv.obj ~age.diag )

se.dia.hr<-sqrt(dia.hr[[2]])
beta.dia.hr<-dia.hr[[1]]

up.lim.dia.hr<-exp(beta.dia.hr+(1.96*se.dia.hr))
low.lim.dia.hr<-exp(beta.dia.hr-(1.96*se.dia.hr))
hr.dia<-exp(beta.dia.hr)

dia.hr.res<-coxph(formula = surv.obj.res ~age.diag.res )

se.dia.hr.res<-sqrt(dia.hr.res[[2]])
beta.dia.hr.res<-dia.hr.res[[1]]

up.lim.dia.hr.res<-exp(beta.dia.hr.res+(1.96*se.dia.hr.res))
low.lim.dia.hr.res<-exp(beta.dia.hr.res-(1.96*se.dia.hr.res))
hr.dia.res<-exp(beta.dia.hr.res)

dia.hr.no.res<-coxph(formula = surv.obj.no.res ~age.diag.no.res )

se.dia.hr.no.res<-sqrt(dia.hr.no.res[[2]])
beta.dia.hr.no.res<-dia.hr.no.res[[1]]

up.lim.dia.hr.no.res<-exp(beta.dia.hr.no.res+(1.96*se.dia.hr.no.res))
low.lim.dia.hr.no.res<-exp(beta.dia.hr.no.res-(1.96*se.dia.hr.no.res))
hr.dia.no.res<-exp(beta.dia.hr.no.res)

doi.hr<-coxph(formula = surv.obj ~doi)

se.doi.hr<-sqrt(doi.hr[[2]])
beta.doi.hr<-doi.hr[[1]]

up.lim.doi.hr<-exp(beta.doi.hr+(1.96*se.doi.hr))
low.lim.doi.hr<-exp(beta.doi.hr-(1.96*se.doi.hr))
hr.doi<-exp(beta.doi.hr)

doi.hr.res<-coxph(formula = surv.obj.res ~doi.res)

se.doi.hr.res<-sqrt(doi.hr.res[[2]])
beta.doi.hr.res<-doi.hr.res[[1]]

up.lim.doi.hr.res<-exp(beta.doi.hr.res+(1.96*se.doi.hr.res))
low.lim.doi.hr.res<-exp(beta.doi.hr.res-(1.96*se.doi.hr.res))
hr.doi.res<-exp(beta.doi.hr.res)

doi.hr.no.res<-coxph(formula = surv.obj.no.res ~doi.no.res)

se.doi.hr.no.res<-sqrt(doi.hr.no.res[[2]])
beta.doi.hr.no.res<-doi.hr.no.res[[1]]

up.lim.doi.hr.no.res<-exp(beta.doi.hr.no.res+(1.96*se.doi.hr.no.res))
low.lim.doi.hr.no.res<-exp(beta.doi.hr.no.res-(1.96*se.doi.hr.no.res))
hr.doi.no.res<-exp(beta.doi.hr.no.res)

nic.hr<-coxph(formula = surv.obj ~nicotine )

se.nic.hr<-sqrt(nic.hr[[2]])
beta.nic.hr<-nic.hr[[1]]

up.lim.nic.hr<-exp(beta.nic.hr+(1.96*se.nic.hr))
low.lim.nic.hr<-exp(beta.nic.hr-(1.96*se.nic.hr))
hr.nic<-exp(beta.nic.hr)

nic.hr.res<-coxph(formula = surv.obj.res ~nicotine.res )

se.nic.hr.res<-sqrt(nic.hr.res[[2]])
beta.nic.hr.res<-nic.hr.res[[1]]

up.lim.nic.hr.res<-exp(beta.nic.hr.res+(1.96*se.nic.hr.res))
low.lim.nic.hr.res<-exp(beta.nic.hr.res-(1.96*se.nic.hr.res))
hr.nic.res<-exp(beta.nic.hr.res)

nic.hr.no.res<-coxph(formula = surv.obj.no.res ~nicotine.no.res )

se.nic.hr.no.res<-sqrt(nic.hr.no.res[[2]])
beta.nic.hr.no.res<-nic.hr.no.res[[1]]

up.lim.nic.hr.no.res<-exp(beta.nic.hr.no.res+(1.96*se.nic.hr.no.res))
low.lim.nic.hr.no.res<-exp(beta.nic.hr.no.res-(1.96*se.nic.hr.no.res))
hr.nic.no.res<-exp(beta.nic.hr.no.res)

gen.hr<-coxph(formula = surv.obj ~panss.gen) 

se.gen.hr<-sqrt(gen.hr[[2]])
beta.gen.hr<-gen.hr[[1]]

up.lim.gen.hr<-exp(beta.gen.hr+(1.96*se.gen.hr))
low.lim.gen.hr<-exp(beta.gen.hr-(1.96*se.gen.hr))
hr.gen<-exp(beta.gen.hr)

gen.hr.res<-coxph(formula = surv.obj.res ~panss.gen.res) 

se.gen.hr.res<-sqrt(gen.hr.res[[2]])
beta.gen.hr.res<-gen.hr.res[[1]]

up.lim.gen.hr.res<-exp(beta.gen.hr.res+(1.96*se.gen.hr.res))
low.lim.gen.hr.res<-exp(beta.gen.hr.res-(1.96*se.gen.hr.res))
hr.gen.res<-exp(beta.gen.hr.res)

gen.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.gen.no.res) 

se.gen.hr.no.res<-sqrt(gen.hr.no.res[[2]])
beta.gen.hr.no.res<-gen.hr.no.res[[1]]

up.lim.gen.hr.no.res<-exp(beta.gen.hr.no.res+(1.96*se.gen.hr.no.res))
low.lim.gen.hr.no.res<-exp(beta.gen.hr.no.res-(1.96*se.gen.hr.no.res))
hr.gen.no.res<-exp(beta.gen.hr.no.res)

neg.hr<-coxph(formula = surv.obj ~panss.neg) 

se.neg.hr<-sqrt(neg.hr[[2]])
beta.neg.hr<-neg.hr[[1]]

up.lim.neg.hr<-exp(beta.neg.hr+(1.96*se.neg.hr))
low.lim.neg.hr<-exp(beta.neg.hr-(1.96*se.neg.hr))
hr.neg<-exp(beta.neg.hr)

neg.hr.res<-coxph(formula = surv.obj.res ~panss.neg.res) 

se.neg.hr.res<-sqrt(neg.hr.res[[2]])
beta.neg.hr.res<-neg.hr.res[[1]]

up.lim.neg.hr.res<-exp(beta.neg.hr.res+(1.96*se.neg.hr.res))
low.lim.neg.hr.res<-exp(beta.neg.hr.res-(1.96*se.neg.hr.res))
hr.neg.res<-exp(beta.neg.hr.res)

neg.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.neg.no.res) 

se.neg.hr.no.res<-sqrt(neg.hr.no.res[[2]])
beta.neg.hr.no.res<-neg.hr.no.res[[1]]

up.lim.neg.hr.no.res<-exp(beta.neg.hr.no.res+(1.96*se.neg.hr.no.res))
low.lim.neg.hr.no.res<-exp(beta.neg.hr.no.res-(1.96*se.neg.hr.no.res))
hr.neg.no.res<-exp(beta.neg.hr.no.res)

pos.hr<-coxph(formula = surv.obj ~panss.pos) 

se.pos.hr<-sqrt(pos.hr[[2]])
beta.pos.hr<-pos.hr[[1]]

up.lim.pos.hr<-exp(beta.pos.hr+(1.96*se.pos.hr))
low.lim.pos.hr<-exp(beta.pos.hr-(1.96*se.pos.hr))
hr.pos<-exp(beta.pos.hr)

pos.hr.res<-coxph(formula = surv.obj.res ~panss.pos.res) 

se.pos.hr.res<-sqrt(pos.hr.res[[2]])
beta.pos.hr.res<-pos.hr.res[[1]]

up.lim.pos.hr.res<-exp(beta.pos.hr.res+(1.96*se.pos.hr.res))
low.lim.pos.hr.res<-exp(beta.pos.hr.res-(1.96*se.pos.hr.res))
hr.pos.res<-exp(beta.pos.hr.res)

pos.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.pos.no.res) 

se.pos.hr.no.res<-sqrt(pos.hr.no.res[[2]])
beta.pos.hr.no.res<-pos.hr.no.res[[1]]

up.lim.pos.hr.no.res<-exp(beta.pos.hr.no.res+(1.96*se.pos.hr.no.res))
low.lim.pos.hr.no.res<-exp(beta.pos.hr.no.res-(1.96*se.pos.hr.no.res))
hr.pos.no.res<-exp(beta.pos.hr.no.res)

tot.hr<-coxph(formula = surv.obj ~panss.tot)

se.tot.hr<-sqrt(tot.hr[[2]])
beta.tot.hr<-tot.hr[[1]]

up.lim.tot.hr<-exp(beta.tot.hr+(1.96*se.tot.hr))
low.lim.tot.hr<-exp(beta.tot.hr-(1.96*se.tot.hr))
hr.tot<-exp(beta.tot.hr)

tot.hr.res<-coxph(formula = surv.obj.res ~panss.tot.res)

se.tot.hr.res<-sqrt(tot.hr.res[[2]])
beta.tot.hr.res<-tot.hr.res[[1]]

up.lim.tot.hr.res<-exp(beta.tot.hr.res+(1.96*se.tot.hr.res))
low.lim.tot.hr.res<-exp(beta.tot.hr.res-(1.96*se.tot.hr.res))
hr.tot.res<-exp(beta.tot.hr.res)

tot.hr.no.res<-coxph(formula = surv.obj.no.res ~panss.tot.no.res)

se.tot.hr.no.res<-sqrt(tot.hr.no.res[[2]])
beta.tot.hr.no.res<-tot.hr.no.res[[1]]

up.lim.tot.hr.no.res<-exp(beta.tot.hr.no.res+(1.96*se.tot.hr.no.res))
low.lim.tot.hr.no.res<-exp(beta.tot.hr.no.res-(1.96*se.tot.hr.no.res))
hr.tot.no.res<-exp(beta.tot.hr.no.res)

pre.hr<-coxph(formula = surv.obj ~pr.ep) 

se.pre.hr<-sqrt(pre.hr[[2]])
beta.pre.hr<-pre.hr[[1]]

up.lim.pre.hr<-exp(beta.pre.hr+(1.96*se.pre.hr))
low.lim.pre.hr<-exp(beta.pre.hr-(1.96*se.pre.hr))
hr.pre<-exp(beta.pre.hr)

pre.hr.res<-coxph(formula = surv.obj.res ~pr.ep.res) 

se.pre.hr.res<-sqrt(pre.hr.res[[2]])
beta.pre.hr.res<-pre.hr.res[[1]]

up.lim.pre.hr.res<-exp(beta.pre.hr.res+(1.96*se.pre.hr.res))
low.lim.pre.hr.res<-exp(beta.pre.hr.res-(1.96*se.pre.hr.res))
hr.pre.res<-exp(beta.pre.hr.res)

pre.hr.no.res<-coxph(formula = surv.obj.no.res ~pr.ep.no.res) 

se.pre.hr.no.res<-sqrt(pre.hr.no.res[[2]])
beta.pre.hr.no.res<-pre.hr.no.res[[1]]

up.lim.pre.hr.no.res<-exp(beta.pre.hr.no.res+(1.96*se.pre.hr.no.res))
low.lim.pre.hr.no.res<-exp(beta.pre.hr.no.res-(1.96*se.pre.hr.no.res))
hr.pre.no.res<-exp(beta.pre.hr.no.res)

las.hr<-coxph(formula = surv.obj ~last.hosp) 

se.las.hr<-sqrt(las.hr[[2]])
beta.las.hr<-las.hr[[1]]

up.lim.las.hr<-exp(beta.las.hr+(1.96*se.las.hr))
low.lim.las.hr<-exp(beta.las.hr-(1.96*se.las.hr))
hr.las<-exp(beta.las.hr)

las.hr.res<-coxph(formula = surv.obj.res ~last.hosp.res) 

se.las.hr.res<-sqrt(las.hr.res[[2]])
beta.las.hr.res<-las.hr.res[[1]]

up.lim.las.hr.res<-exp(beta.las.hr.res+(1.96*se.las.hr.res))
low.lim.las.hr.res<-exp(beta.las.hr.res-(1.96*se.las.hr.res))
hr.las.res<-exp(beta.las.hr.res)

las.hr.no.res<-coxph(formula = surv.obj.no.res ~last.hosp.no.res) 

se.las.hr.no.res<-sqrt(las.hr.no.res[[2]])
beta.las.hr.no.res<-las.hr.no.res[[1]]

up.lim.las.hr.no.res<-exp(beta.las.hr.no.res+(1.96*se.las.hr.no.res))
low.lim.las.hr.no.res<-exp(beta.las.hr.no.res-(1.96*se.las.hr.no.res))
hr.las.no.res<-exp(beta.las.hr.no.res)

eps.hr<-coxph(formula = surv.obj ~eps) 

se.eps.hr<-sqrt(eps.hr[[2]])
beta.eps.hr<-eps.hr[[1]]

up.lim.eps.hr<-exp(beta.eps.hr+(1.96*se.eps.hr))
low.lim.eps.hr<-exp(beta.eps.hr-(1.96*se.eps.hr))
hr.eps<-exp(beta.eps.hr)

eps.hr.res<-coxph(formula = surv.obj.res ~eps.res) 

se.eps.hr.res<-sqrt(eps.hr.res[[2]])
beta.eps.hr.res<-eps.hr.res[[1]]

up.lim.eps.hr.res<-exp(beta.eps.hr.res+(1.96*se.eps.hr.res))
low.lim.eps.hr.res<-exp(beta.eps.hr.res-(1.96*se.eps.hr.res))
hr.eps.res<-exp(beta.eps.hr.res)


eps.hr.no.res<-coxph(formula = surv.obj.no.res ~eps.no.res) 

se.eps.hr.no.res<-sqrt(eps.hr.no.res[[2]])
beta.eps.hr.no.res<-eps.hr.no.res[[1]]

up.lim.eps.hr.no.res<-exp(beta.eps.hr.no.res+(1.96*se.eps.hr.no.res))
low.lim.eps.hr.no.res<-exp(beta.eps.hr.no.res-(1.96*se.eps.hr.no.res))
hr.eps.no.res<-exp(beta.eps.hr.no.res)


#####SUMMARY TABLES

colname.desc.cont<- c("Age (mean)", "Age (SD)", "BMI (mean)", "BMI (SD)","Age at diagnosis (mean)","Age at diagnosis (SD)","Duration of illness (mean)",
                      "Duration of illness (SD)", "CGI (mean)","CGI (SD)","Psychopathology total score (mean)","Psychopathology total score (SD)", 
                      "Psychopathology general score (mean)","Psychopathology general score (SD)","Psychopathology positive score (mean)","Psychopathology positive score (SD)",
                      "Psychopathology negative score (mean)","Psychopathology negative score (SD)","General functioning score (mean)","General functioning score (SD)", 
                      "Quality of life score (mean)","Quality of life score (SD)")




mean.age<-mean(age, na.rm=T)

sd.age<-sd(age,na.rm=T)

mean.BMI<-mean(BMI,na.rm=T)

sd.BMI<-sd(BMI,na.rm=T)

mean.agediagnosis<-mean(age.diag, na.rm=T)

sd.agediagnsosis<-sd(age.diag,na.rm=T)

mean.doi<-mean(doi,na.rm=T)

sd.doi<-sd(doi,na.rm=T)

mean.cgi<-mean(cgi,na.rm=T)

sd.cgi<-sd(cgi,na.rm=T)

mean.totps<-mean(panss.tot,na.rm=T)

sd.totps<-sd(panss.tot, na.rm=T)

mean.genps<- mean(panss.gen, na.rm=T)
sd.genps<-sd(panss.gen, na.rm=T)
mean.posps<-mean(panss.pos, na.rm=T)
sd.posps<-sd(panss.pos, na.rm=T)

mean.negps<-mean(panss.neg, na.rm=T)
sd.negps<-sd(panss.neg, na.rm=T)
mean.func<-NA
sd.functioning<-NA
mean.qol<-NA

sd.qol<-NA





desc.cont<-c(mean.age,sd.age,mean.BMI,sd.BMI,mean.agediagnosis,sd.agediagnsosis,mean.doi,sd.doi,mean.cgi,
             sd.cgi,mean.totps,sd.totps,mean.genps,sd.genps,mean.posps,sd.posps,mean.negps,sd.negps,mean.func,sd.functioning,mean.qol,sd.qol)



desc.cont.mat<-rbind(colname.desc.cont,desc.cont)



mean.age.res<-mean(age.res, na.rm=T)

sd.age.res<-sd(age.res,na.rm=T)

mean.BMI.res<-mean(BMI.res,na.rm=T)

sd.BMI.res<-sd(BMI.res,na.rm=T)

mean.agediagnosis.res<-mean(age.diag.res, na.rm=T)

sd.agediagnsosis.res<-sd(age.diag.res,na.rm=T)

mean.doi.res<-mean(doi.res,na.rm=T)

sd.doi.res<-sd(doi.res,na.rm=T)

mean.cgi.res<-mean(cgi.res,na.rm=T)

sd.cgi.res<-sd(cgi.res,na.rm=T)

mean.totps.res<-mean(panss.tot.res,na.rm=T)

sd.totps.res<-sd(panss.tot.res, na.rm=T)

mean.genps.res<- mean(panss.gen.res, na.rm=T)
sd.genps.res<-sd(panss.gen.res, na.rm=T)
mean.posps.res<-mean(panss.pos.res, na.rm=T)
sd.posps.res<-sd(panss.pos.res, na.rm=T)

mean.negps.res<-mean(panss.neg.res, na.rm=T)
sd.negps.res<-sd(panss.neg.res, na.rm=T)
mean.func.res<-NA
sd.func.res<-NA
mean.qol.res<-NA

sd.qol.res<-NA




desc.cont.res<-c(mean.age.res,sd.age.res,mean.BMI.res,sd.BMI.res,mean.agediagnosis.res,sd.agediagnsosis.res,mean.doi.res,sd.doi.res,mean.cgi.res,sd.cgi.res,mean.totps.res,sd.totps.res,mean.genps.res,sd.genps.res,mean.posps.res,sd.posps.res,
                 mean.negps.res,sd.negps.res,mean.func.res,sd.func.res,mean.qol.res,sd.qol.res)



desc.cont.mat.res<-rbind(colname.desc.cont,desc.cont.res)




mean.age.no.res<-mean(age.no.res, na.rm=T)

sd.age.no.res<-sd(age.no.res,na.rm=T)

mean.BMI.no.res<-mean(BMI.no.res,na.rm=T)

sd.BMI.no.res<-sd(BMI.no.res,na.rm=T)

mean.agediagnosis.no.res<-mean(age.diag.no.res, na.rm=T)

sd.agediagnsosis.no.res<-sd(age.diag.no.res,na.rm=T)

mean.doi.no.res<-mean(doi.no.res,na.rm=T)

sd.doi.no.res<-sd(doi.no.res,na.rm=T)

mean.cgi.no.res<-mean(cgi.no.res,na.rm=T)

sd.cgi.no.res<-sd(cgi.no.res,na.rm=T)

mean.totps.no.res<-mean(panss.tot.no.res,na.rm=T)

sd.totps.no.res<-sd(panss.tot.no.res, na.rm=T)

mean.genps.no.res<- mean(panss.gen.no.res, na.rm=T)
sd.genps.no.res<-sd(panss.gen.no.res, na.rm=T)
mean.posps.no.res<-mean(panss.pos.no.res, na.rm=T)
sd.posps.no.res<-sd(panss.pos.no.res, na.rm=T)

mean.negps.no.res<-mean(panss.neg.no.res, na.rm=T)
sd.negps.no.res<-sd(panss.neg.no.res, na.rm=T)
mean.func.no.res<-NA
sd.func.no.res<-NA
mean.qol.no.res<-NA

sd.qol.no.res<-NA




desc.cont.no.res<-c(mean.age.no.res,sd.age.no.res,mean.BMI.no.res,sd.BMI.no.res,mean.agediagnosis.no.res,sd.agediagnsosis.no.res,mean.doi.no.res,sd.doi.no.res,mean.cgi.no.res,sd.cgi.no.res,mean.totps.no.res,sd.totps.no.res,mean.genps.no.res,sd.genps.no.res,mean.posps.no.res,sd.posps.no.res,
                    mean.negps.no.res,sd.negps.no.res,mean.func.no.res,sd.func.no.res,mean.qol.no.res,sd.qol.no.res)



desc.cont.mat.no.res<-rbind(colname.desc.cont,desc.cont.no.res)




colname.desc.cat<- c("Male (n)","Male (%)", "US (n)", "US (%)", "Family history (n)", "Family history (%)", "Smoking (n)", "Smoking (%)",
                     "Drug use (n)", "Drug use (%)","Moderate TD (n)","Moderate TD (%)","Moderate akathisia (n)","Moderate akathisia (%)","Moderate EPS (n)","Moderate EPS (%)","Hospitalized within last year (n)","Hospitalized within last year (%)","3 or more previous hospitalizations (n)","3 or more previous hospitalizations (%)")



n.male<- length(sex[sex==2])
perc.male<-length(sex[sex==2])/length(sex)*100

n.us<- length(region[region==1])

perc.us<-n.us/length(region)*100

n.fhx<- NA

perc.fhx<-NA

n.smok<- length(nicotine[nicotine==1])

perc.smok<-length(nicotine[nicotine==1])/length(nicotine)*100

n.drug<- NA
perc.drug<-NA


n.aims<-length(aims[aims==1])
perc.aims<-n.aims/length(aims)*100
n.bars<-length(bars[bars==1])
perc.bars<-n.bars/length(bars)*100
n.eps<-length(eps[eps==1])
perc.eps<-n.eps/length(eps)*100
n.hosplastyr<-length(last.hosp[last.hosp==1])
perc.hosp.lastyr<-n.hosplastyr/length(last.hosp)*100
n.more2hosp<-length(pr.ep[pr.ep==1])
perc.more2hosp<-n.more2hosp/length(pr.ep)*100


desc.cat<-c(n.male,perc.male,n.us,perc.us,n.fhx,perc.fhx,n.smok,perc.smok,n.drug,perc.drug,n.aims,perc.aims,n.bars,perc.bars,n.eps,perc.eps,n.hosplastyr,
            perc.hosp.lastyr,n.more2hosp,perc.more2hosp)


desc.cat.mat<-rbind(colname.desc.cat,desc.cat)



n.male.res<- length(sex.res[sex.res==2])

perc.male.res<-length(sex.res[sex.res==2])/length(sex.res)*100

n.us.res<- length(region.res[region.res==1])
perc.us.res<-n.us.res/length(region.res)*100
n.fhx.res<- NA

perc.fhx.res<-NA

n.smok.res<- length(nicotine.res[nicotine.res==1])

perc.smok.res<-length(nicotine.res[nicotine.res==1])/length(nicotine.res)*100

n.drug.res<- NA
perc.drug.res<-NA
n.aims.res<-length(aims.res[aims.res==1])
perc.aims.res<-n.aims.res/length(aims.res)*100
n.bars.res<-length(bars.res[bars.res==1])
perc.bars.res<-n.bars.res/length(bars.res)*100
n.eps.res<-length(eps.res[eps.res==1])
perc.eps.res<-n.eps.res/length(eps.res)*100
n.hosplastyr.res<-length(last.hosp.res[last.hosp.res==1])
perc.hosp.lastyr.res<-n.hosplastyr.res/length(last.hosp.res)*100
n.more2hosp.res<-length(pr.ep.res[pr.ep.res==1])
perc.more2hosp.res<-n.more2hosp.res/length(pr.ep.res)*100



desc.cat.res<-c(n.male.res,perc.male.res,n.us.res,perc.us.res,n.fhx.res,perc.fhx.res,n.smok.res,perc.smok.res,n.drug.res,perc.drug.res,n.aims.res,perc.aims.res,n.bars.res,perc.bars.res,n.eps.res,perc.eps.res,n.hosplastyr,
                perc.hosp.lastyr.res,n.more2hosp.res,perc.more2hosp.res)



desc.cat.mat.res<-rbind(colname.desc.cat,desc.cat.res)




n.male.no.res<- length(sex.no.res[sex.no.res==2])

perc.male.no.res<-length(sex.no.res[sex.no.res==2])/length(sex.no.res)*100

n.us.no.res<- length(region.no.res[region.no.res==1])
perc.us.no.res<-n.us.no.res/length(region.no.res)*100
n.fhx.no.res<- NA

perc.fhx.no.res<-NA

n.smok.no.res<- length(nicotine.no.res[nicotine.no.res==1])

perc.smok.no.res<-length(nicotine.no.res[nicotine.no.res==1])/length(nicotine.no.res)*100

n.drug.no.res<- NA
perc.drug.no.res<-NA
n.aims.no.res<-length(aims.no.res[aims.no.res==1])
perc.aims.no.res<-n.aims.no.res/length(aims.no.res)*100
n.bars.no.res<-length(bars.no.res[bars.no.res==1])
perc.bars.no.res<-n.bars.no.res/length(bars.no.res)*100
n.eps.no.res<-length(eps.no.res[eps.no.res==1])
perc.eps.no.res<-n.eps.no.res/length(eps.no.res)*100
n.hosp.lastyr.no.res<-length(last.hosp.no.res[last.hosp.no.res==1])
perc.hosp.lastyr.no.res<-n.hosp.lastyr.no.res/length(n.hosp.lastyr.no.res)*100
n.more2hosp.no.res<-length(pr.ep.no.res[pr.ep.no.res==1])
perc.more2hosp.no.res<-n.more2hosp.no.res/length(pr.ep.no.res)*100



desc.cat.no.res<-c(n.male.no.res,perc.male.no.res,n.us.no.res,perc.us.no.res,n.fhx.no.res,perc.fhx.no.res,n.smok.no.res,perc.smok.no.res,n.drug.no.res,perc.drug.no.res,n.aims.no.res,perc.aims.no.res,n.bars.no.res,perc.bars.no.res,n.eps.no.res,perc.eps.no.res,n.hosplastyr,
                   perc.hosp.lastyr.no.res,n.more2hosp.no.res,perc.more2hosp.no.res)



desc.cat.mat.no.res<-rbind(colname.desc.cat,desc.cat.no.res)

colname.outc<-c("Total sample 'n'", "Relapse 'n'", "Relapse '%'", "Median time to relapse 'days'", "Events per 100 patient - years")



n.total<-length(total.ids)

n.relapse<-length(status[status==1])

perc.relapse<-length(status[status==1])/length(status)*100

median.time<-median(time.to.event, na.rm=T)

py.inc



outc<-c(n.total,n.relapse,perc.relapse,median.time,py.inc)



outc.mat<-rbind(colname.outc,outc)



n.total.res<-length(response.ids)

n.relapse.res<-length(status.res[status.res==1])

perc.relapse.res<-length(status.res[status.res==1])/length(status.res)*100

median.time.res<-median(time.to.event.res, na.rm=T)

py.inc.res



outc.res<-c(n.total.res,n.relapse.res,perc.relapse.res,median.time.res,py.inc.res)



outc.mat.res<-rbind(colname.outc,outc.res)




n.total.no.res<-length(no.response.ids)

n.relapse.no.res<-length(status.no.res[status.no.res==1])

perc.relapse.no.res<-length(status.no.res[status.no.res==1])/length(status.no.res)*100

median.time.no.res<-median(time.to.event.no.res, na.rm=T)

py.inc.no.res



outc.no.res<-c(n.total.no.res,n.relapse.no.res,perc.relapse.no.res,median.time.no.res,py.inc.no.res)



outc.mat.no.res<-rbind(colname.outc,outc.no.res)



colname.HR<-c("Male gender HR","Male gender Lower 95% CI","Male gender Upper 95% CI","Age HR", "Age Lower 95% CI","Age	Upper 95% CI","Proportion US HR",
              "Proportion US Lower 95% CI","Proportion US Upper 95% CI","BMI HR",  "BMI Lower 95% CI","BMI Upper 95% CI", "Age at diagnosis HR",
              "Age at diagnosis Lower 95% CI","Age at diagnosis Upper 95% CI","Duration of illness HR","Duration of illness Lower 95% CI","Duration of illness Upper 95% CI",
              "Time since last hospitalization HR","Time since last hospitalization Lower 95% CI","Time since last hospitalization Upper 95% CI",
              "Number of previous hospitalizations HR","Number of previous hospitalizations Lower 95% CI","Number of previous hospitalizations Upper 95% CI",
              "Family history HR","Family history Lower 95% CI","Family history Upper 95% CI","Smoking HR","Smoking Lower 95% CI","Smoking Upper 95% CI",
              "Drug use HR","Drug use Lower 95% CI","Drug use Upper 95% CI","CGI HR","CGI Lower 95% CI","CGI Upper 95% CI","Psychopathology total score HR",
              "Psychopathology total score Lower 95% CI","Psychopathology total score Upper 95% CI","Psychopathology general score HR",
              "Psychopathology general score Lower 95% CI","Psychopathology general score Upper 95% CI","Psychopathology positive score HR",
              "Psychopathology positive score Lower 95% CI","Psychopathology positive score Upper 95% CI","Psychopathology negative score HR",
              "Psychopathology negative score Lower 95% CI","Psychopathology negative score Upper 95% CI","General functioning score HR",  
              "General functioning score Lower 95% CI","General functioning score Upper 95% CI", "Quality of life score HR",  "Quality of life score Lower 95% CI",
              "Quality of life score Upper 95% CI","Tardive dyskinesia score HR","Tardive dyskinesia score Lower 95% CI","Tardive dyskinesia score Upper 95% CI",
              "Akathisia score HR","Akathisia score Lower 95% CI","Akathisia score Upper 95% CI","Parkinsonism score HR","Parkinsonism score Lower 95% CI",
              "Parkinsonism score Upper 95% CI")



hr<- cbind(
  hr.sex,low.lim.sex.hr,up.lim.sex.hr,
  hr.age,low.lim.age.hr,up.lim.age.hr,
  hr.reg,low.lim.reg.hr.res,up.lim.reg.hr.res,
  NA,NA,NA,
  hr.bmi,low.lim.bmi.hr,up.lim.bmi.hr,
  hr.dia,low.lim.dia.hr,up.lim.dia.hr,
  hr.doi,low.lim.doi.hr,up.lim.doi.hr,
  hr.las,low.lim.las.hr,up.lim.las.hr,
  hr.pre,low.lim.pre.hr,up.lim.pre.hr,
  NA,NA,NA,
  hr.nic,low.lim.nic.hr,up.lim.nic.hr,
  NA,NA,NA,
  hr.cgi,low.lim.cgi.hr,up.lim.cgi.hr,
  hr.tot,low.lim.tot.hr,up.lim.tot.hr,
  hr.gen,low.lim.gen.hr,up.lim.gen.hr,
  hr.pos,low.lim.pos.hr,up.lim.pos.hr,
  hr.neg,low.lim.neg.hr,up.lim.neg.hr,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim,low.lim.aim.hr,up.lim.aim.hr,
  hr.bar,low.lim.bar.hr,up.lim.bar.hr,
  hr.eps,low.lim.eps.hr,up.lim.eps.hr)



hr.mat<-rbind(colname.HR,hr)




hr.res<- cbind(
  hr.sex.res,low.lim.sex.hr.res,up.lim.sex.hr.res,
  hr.age.res,low.lim.age.hr.res,up.lim.age.hr.res,
  hr.reg.res,low.lim.reg.hr.res,up.lim.reg.hr.res,
  hr.bmi.res,low.lim.bmi.hr.res,up.lim.bmi.hr.res,
  hr.dia.res,low.lim.dia.hr.res,up.lim.dia.hr.res,
  hr.doi.res,low.lim.doi.hr.res,up.lim.doi.hr.res,
  hr.las.res,low.lim.las.hr.res,up.lim.las.hr.res,
  hr.pre.res,low.lim.pre.hr.res,up.lim.pre.hr.res,
  NA,NA,NA,
  hr.nic.res,low.lim.nic.hr.res,up.lim.nic.hr.res,
  NA,NA,NA,
  hr.cgi.res,low.lim.cgi.hr.res,up.lim.cgi.hr.res,
  hr.tot.res,low.lim.tot.hr.res,up.lim.tot.hr.res,
  hr.gen.res,low.lim.gen.hr.res,up.lim.gen.hr.res,
  hr.pos.res,low.lim.pos.hr.res,up.lim.pos.hr.res,
  hr.neg.res,low.lim.neg.hr.res,up.lim.neg.hr.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim.res,low.lim.aim.hr.res,up.lim.aim.hr.res,
  hr.bar.res,low.lim.bar.hr.res,up.lim.bar.hr.res,
  hr.eps.res,low.lim.eps.hr.res,up.lim.eps.hr.res)



hr.mat.res<-rbind(colname.HR,hr.res)





hr.no.res<- cbind(
  hr.sex.no.res,low.lim.sex.hr.no.res,up.lim.sex.hr.no.res,
  hr.age.no.res,low.lim.age.hr.no.res,up.lim.age.hr.no.res,
  hr.reg.no.res,low.lim.reg.hr.no.res,up.lim.reg.hr.no.res,
  hr.bmi.no.res,low.lim.bmi.hr.no.res,up.lim.bmi.hr.no.res,
  hr.dia.no.res,low.lim.dia.hr.no.res,up.lim.dia.hr.no.res,
  hr.doi.no.res,low.lim.doi.hr.no.res,up.lim.doi.hr.no.res,
  hr.las.no.res,low.lim.las.hr.no.res,up.lim.las.hr.no.res,
  hr.pre.no.res,low.lim.pre.hr.no.res,up.lim.pre.hr.no.res,
  NA,NA,NA,
  hr.nic.no.res,low.lim.nic.hr.no.res,up.lim.nic.hr.no.res,
  NA,NA,NA,
  hr.cgi.no.res,low.lim.cgi.hr.no.res,up.lim.cgi.hr.no.res,
  hr.tot.no.res,low.lim.tot.hr.no.res,up.lim.tot.hr.no.res,
  hr.gen.no.res,low.lim.gen.hr.no.res,up.lim.gen.hr.no.res,
  hr.pos.no.res,low.lim.pos.hr.no.res,up.lim.pos.hr.no.res,
  hr.neg.no.res,low.lim.neg.hr.no.res,up.lim.neg.hr.no.res,
  NA,NA,NA,
  NA,NA,NA,
  hr.aim.no.res,low.lim.aim.hr.no.res,up.lim.aim.hr.no.res,
  hr.bar.no.res,low.lim.bar.hr.no.res,up.lim.bar.hr.no.res,
  hr.eps.no.res,low.lim.eps.hr.no.res,up.lim.eps.hr.no.res)



hr.mat.no.res<-rbind(colname.HR,hr.no.res)




hr.int<- cbind(
  ci.int.sex[1],ci.int.sex[2],ci.int.sex[3],
  ci.int.age[1],ci.int.age[2],ci.int.age[3],
  NA,NA,NA,
  ci.int.BMI[1],ci.int.BMI[2],ci.int.BMI[3],
  ci.int.dia[1],ci.int.dia[2],ci.int.dia[3],
  ci.int.doi[1],ci.int.doi[2],ci.int.doi[3],
  ci.int.las[1],ci.int.las[2],ci.int.las[3],
  ci.int.pre[1],ci.int.pre[2],ci.int.pre[3],
  NA,NA,NA,
  ci.int.nic[1],ci.int.nic[2],ci.int.nic[3],
  NA,NA,NA,
  ci.int.cgi[1],ci.int.cgi[2],ci.int.cgi[3],
  ci.int.tot[1],ci.int.tot[2],ci.int.tot[3],
  ci.int.gen[1],ci.int.gen[2],ci.int.gen[3],
  ci.int.pos[1],ci.int.pos[2],ci.int.pos[3],
  ci.int.neg[1],ci.int.neg[2],ci.int.neg[3],
  NA,NA,NA,
  NA,NA,NA,
  ci.int.aim[1],ci.int.aim[2],ci.int.aim[3],
  ci.int.bar[1],ci.int.bar[2],ci.int.bar[3],
  ci.int.eps[1],ci.int.eps[2],ci.int.eps[3])

hr.mat.int<-rbind(colname.HR,hr.int)


hr.int.seiyi<- cbind(
  sei.int.sex[1],sei.int.sex[2],
  sei.int.age[1],sei.int.age[2],
  NA,NA,
  sei.int.BMI[1],sei.int.BMI[2],
  sei.int.dia[1],sei.int.dia[2],
  sei.int.doi[1],sei.int.doi[2],
  sei.int.las[1],sei.int.las[2],
  sei.int.pre[1],sei.int.pre[2],
  NA,NA,
  sei.int.nic[1],sei.int.nic[2],
  NA,NA,
  sei.int.cgi[1],sei.int.cgi[2],
  sei.int.tot[1],sei.int.tot[2],
  sei.int.gen[1],sei.int.gen[2],
  sei.int.pos[1],sei.int.pos[2],
  sei.int.neg[1],sei.int.neg[2],
  NA,NA,
  NA,NA,
  sei.int.aim[1],sei.int.aim[2],
  sei.int.bar[1],sei.int.bar[2],
  sei.int.eps[1],sei.int.eps[2])

hr.nores.seiyi<- cbind(
  sei.sex[1],sei.sex[2],
  sei.age[1],sei.age[2],
  NA,NA,
  NA,NA,
  sei.BMI[1],sei.BMI[2],
  sei.dia[1],sei.dia[2],
  sei.doi[1],sei.doi[2],
  sei.las[1],sei.las[2],
  sei.pre[1],sei.pre[2],
  NA,NA,
  sei.nic[1],sei.nic[2],
  NA,NA,
  sei.cgi[1],sei.cgi[2],
  sei.tot[1],sei.tot[2],
  sei.gen[1],sei.gen[2],
  sei.pos[1],sei.pos[2],
  sei.neg[1],sei.neg[2],
  NA,NA,
  NA,NA,
  sei.aim[1],sei.aim[2],
  sei.bar[1],sei.bar[2],
  sei.eps[1],sei.eps[2])

surv.obj <- Surv(time.to.event/7, status)
surv.obj.res <- Surv(time.to.event.res/7, status.res)
surv.obj.no.res <- Surv(time.to.event.no.res/7, status.no.res)

survfit(surv.obj~1)
survfit(surv.obj.res~1)
survfit(surv.obj.no.res~1)

study1.surv.fit <- survfit(surv.obj~1)
study1.surv.fit.res <- survfit(surv.obj.res~1)
study1.surv.fit.no.res <- survfit(surv.obj.no.res~1)

xx<-study1.surv.fit
xx.res<-study1.surv.fit.res
xx.no.res<-study1.surv.fit.no.res

xx.t<-xx[[2]]/7
xx.p<-xx[[6]]

xx.t.res<-xx.res[[2]]/7
xx.p.res<-xx.res[[6]]

xx.t.no.res<-xx.no.res[[2]]/7
xx.p.no.res<-xx.no.res[[6]]

surv.mat<-cbind(xx.t,xx.p)
surv.mat.res<-cbind(xx.t.res,xx.p.res)
surv.mat.no.res<-cbind(xx.t.no.res,xx.p.no.res)

write.table(surv.mat,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/surv_mat_Q_v2.csv",sep=",")
write.table(surv.mat.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/surv_mat.res_Q_v2.csv",sep=",")
write.table(surv.mat.no.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/surv_mat.not.res_Q_v2.csv",sep=",")

write.table(desc.cont.mat,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/desc_contQ_v2.csv",sep=",")

write.table(desc.cont.mat.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/desc_cont_resQ_v2.csv",sep=",")

write.table(desc.cont.mat.no.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/desc_cont_no.resQ_v2.csv",sep=",")


write.table(desc.cat.mat,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/desc_catQ_v2.csv",sep=",")

write.table(desc.cat.mat.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/desc_cat.resQ_v2.csv",sep=",")

write.table(desc.cat.mat.no.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/desc_cat.no.resQ_v2.csv",sep=",")


write.table(outc.mat,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/outcQ_v2.csv",sep=",")

write.table(outc.mat.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/outc.resQ_v2.csv",sep=",")

write.table(outc.mat.no.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/outc.no.resQ_v2.csv",sep=",")

write.table(hr.mat,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/hrQ_v2.csv",sep=",")

write.table(hr.mat.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/hr.resQ_v2.csv",sep=",")

write.table(hr.mat.no.res,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/hr.no.resQ_v2.csv",sep=",")

write.table(hr.mat.int,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/hr.int_Q_v2.csv",sep=",")

write.table(hr.int.seiyi,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/hr.int.seiyi_Q_v2.csv",sep=",")

write.table(hr.nores.seiyi,file="E:/LDT-RA-RP-2056/files_LILLY-F1D-MC-HGLQ/LILLY-F1D-MC-HGLQ/results/hr.nores.seiyi_Q_v2.csv",sep=",")
