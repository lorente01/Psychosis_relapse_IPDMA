# Manuscript:Psychosis relapse during long-acting injectable antipsychotic treatment: An individual participant data meta-analysis of 19 trials and 5,111 individuals with schizophrenia-spectrum disorders
# Jose M Rubio M.D 4-10-2020
# Figure 1 and meta-regressions (Supplementary material)

library(metafor)
library(meta)

#fit random effects model
dat<-read.csv("[path]/per_year_R.csv",header=TRUE,sep=",")
pool<-escalc("IR",xi=dat$x1i*100,ti=dat$t1i)
nev<-pool[[1]]
vi<-pool[[2]]
slab<-as.character(dat$study)
aggr<-rma.uni(nev,vi, slab=slab,method="REML")
antipsychotic<-as.character(dat$antipsychotic)
status<-as.character(dat$status)
ord<-as.numeric(dat$ord)

#do forest plot
forest(aggr,xlim=c(-50,80),at=c(0,10,20,30,40,50,60,70),ylim=c(-2,26),slab=slab,cex=1,ilab=cbind(dat$x1i,dat$t1i,antipsychotic),ilab.xpos=c(-28,-21,-7),rows=c(2:11,14:22),xlab="Incidence rate per 100 person-years")
op<-par(cex=0.8,font=2)
text(-34,c(23,12),c("Studies including acutely ill patients","Studies including only stable patients"))
par(op)                                         
text(-40,-2,c(paste("I^2=",round(as.numeric(aggr[25]),2),"%; tau=",round(sqrt(as.numeric(aggr[9])),2))),cex=0.8)
text(-45,25,"Study",cex=.8,font=2)
text(67,25,"Incidence Rate (95% CI)",cex=.8,font=2)
text(-31,25,"Events",cex=.8,font=2)
text(-19,25,"Person-years",cex=.8,font=2)
text(-5,25,"Antipsychotic",cex=.8,font=2)
text(22,26,"Incidence of relapse during continuous antipsychotic treatment (k=19,n=5,130)",ps=4,font=2)
aggr<-rma.uni(nev,vi, slab=slab,method="REML",subset=(status=="Acute"))
addpoly(aggr,row=13,mlab="RE Model for Subgroup")
aggr<-rma.uni(nev,vi, slab=slab,method="REML",subset=(status=="Stable"))
addpoly(aggr,row=1,mlab="RE Model for Subgroup")

#META-REGRESSION FOR WHOLE SAMPLE

aggr1<-metarate(dat$x1i*100,dat$t1i)
aggr2<-metarate(dat$x1i[1:18]*100,dat$t1i[1:18])

us<-dat$us
status<-dat$status 
definition<-dat$definition
sponsor<-dat$sponsor
quality<-dat$quality
quality.2<-dat$quality[1:18]
entry<-dat$status

meta.entry<-metareg(aggr1,~entry)
meta.sponsor<-metareg(aggr1,~sponsor)
meta.status<-metareg(aggr1,~status)
meta.definition<-metareg(aggr1,~definition)
meta.us<-metareg(aggr1,~us)
meta.quality<-metareg(aggr1,~quality)
meta.quality.2<-metareg(aggr2,~quality.2)

beta.entry.1<-unlist(meta.entry[2])
beta.entry<-beta.entry.1[2]
p.entry.1<-unlist(meta.entry[5])
p.entry<-p.entry.1[2]
r.entry<-meta.entry[27]
bubble(meta.entry, main="Meta-regression of acute vs stable status at entry on incidence",xlab="Status at entry",ylab="Log incidence rate")
legend("bottomleft",inset=0.05,bty="n", legend=c(paste("Beta=",round(as.numeric(beta.entry),3),"\np Value=",round(as.numeric(p.entry),3),"\nExplained heterogeneity R^2=",round(as.numeric(r.entry),3),"%")))


beta.sponsor.1<-unlist(meta.sponsor[2])
beta.sponsor<-beta.sponsor.1[2]
p.sponsor.1<-unlist(meta.sponsor[5])
p.sponsor<-p.sponsor.1[2]
r.sponsor<-meta.sponsor[27]
bubble(meta.sponsor, main="Meta-regression of sponsor on incidence",xlab="Sponsor",ylab="Log incidence rate")
legend("bottomleft",inset=0.05,bty="n", legend=c(paste("Beta=",round(as.numeric(beta.sponsor),3),"\np Value=",round(as.numeric(p.sponsor),3),"\nExplained heterogeneity R^2=",round(as.numeric(r.sponsor),3),"%")))

beta.quality.1<-unlist(meta.quality[2])
beta.quality<-beta.quality.1[2]
p.quality.1<-unlist(meta.quality[5])
p.quality<-p.quality.1[2]
r.quality<-meta.quality[27]
bubble(meta.quality, main="Meta-regression of Newcastle Ottawa Score on incidence",xlab="Newcastle Ottawa Score",ylab="Log incidence rate")
legend("bottomleft",inset=0.05,bty="n", legend=c(paste("Beta=",round(as.numeric(beta.quality),3),"\np Value=",round(as.numeric(p.quality),3),"\nExplained heterogeneity R^2=",round(as.numeric(r.quality),3),"%")))

beta.quality<-unlist(meta.quality.2[2])
beta.quality.2<-beta.quality[2]
p.quality.2<-unlist(meta.quality.2[5])
p.quality.2<-p.quality.2[2]
r.quality.2<-meta.quality.2[27]
bubble(meta.quality.2, main="Meta-regression of Newcastle Ottawa Score on incidence (no outlier)",xlab="Newcastle Ottawa Score",ylab="Log incidence rate")
legend("bottomleft",inset=0.05,bty="n", legend=c(paste("Beta=",round(as.numeric(beta.quality.2),3),"\np Value=",round(as.numeric(p.quality.2),3),"\nExplained heterogeneity R^2=",round(as.numeric(r.quality.2),3),"%")))

beta.definition.1<-unlist(meta.definition[2])
beta.definition<-beta.definition.1[2]
p.definition.1<-unlist(meta.definition[5])
p.definition<-p.definition.1[2]
r.definition<-meta.definition[27]
bubble(meta.definition, main="Meta-regression of outcome definition on incidence",xlab="Outcome definition",ylab="Log incidence rate")
legend("bottomleft",inset=0.05,bty="n", legend=c(paste("Beta=",round(as.numeric(beta.definition),3),"\np Value=",round(as.numeric(p.definition),3),"\nExplained heterogeneity R^2=",round(as.numeric(r.definition),3),"%")))

beta.status.1<-unlist(meta.status[2])
beta.status<-beta.status.1[2]
p.status.1<-unlist(meta.status[5])
p.status<-p.status.1[2]
r.status<-meta.status[27]
bubble(meta.status, main="Meta-regression of patient status upon referral on incidence",xlab="Status",ylab="Log incidence rate")
legend("bottomleft",inset=0.05,bty="n", legend=c(paste("Beta=",round(as.numeric(beta.status),3),"\np Value=",round(as.numeric(p.status),3),"\nExplained heterogeneity R^2=",round(as.numeric(r.status),3),"%")))


beta.us.1<-unlist(meta.us[2])
beta.us<-beta.us.1[2]
p.us.1<-unlist(meta.us[5])
p.us<-p.us.1[2]
r.us<-meta.us[27]
bubble(meta.us, main="Meta-regression of US participants (%) on incidence",xlab="US participants (%)",ylab="Log incidence rate")
legend("bottomleft",inset=0.05,bty="n", legend=c(paste("Beta=",round(as.numeric(beta.us),3),"\np Value=",round(as.numeric(p.us),3),"\nExplained heterogeneity R^2=",round(as.numeric(r.us),3),"%")))


#FUNNEL PLOT AND TRIM-FILL FOR WHOLE SAMPLE

funnel(aggr, yaxis="vi", main="Sampling Variance")

trimfill(aggr, side="left")


##META-ANALYSIS OF INCIDENCE RATE IN PARTICIPANTS WITH PROSPECTIVE REMISSION

dat<-read.csv("[path]/per_year_res_R.csv",header=TRUE,sep=",")

pool<-escalc("IR",xi=dat$x1i*100,ti=dat$t1i)
nev<-pool[[1]]
vi<-pool[[2]]
slab<-as.character(dat$study)
aggr<-rma.uni(nev,vi, slab=slab,method="REML")
antipsychotic<-as.character(dat$antipsychotic)
status<-as.character(dat$status)
ord<-as.numeric(dat$ord)

#forest plot
forest(aggr,xlim=c(-50,80),at=c(0,10,20,30,40,50,60,70),ylim=c(-2,26),slab=slab,cex=1,ilab=cbind(dat$x1i,dat$t1i,antipsychotic),ilab.xpos=c(-28,-21,-7),rows=c(2:11,14:22),xlab="Incidence rate per 100 person-years")
op<-par(cex=0.8,font=2)
text(-34,c(23,12),c("Studies including acutely ill patients","Studies including only stable patients"))
par(op)                                         
text(-40,-2,c(paste("I^2=",round(as.numeric(aggr[25]),2),"%; tau=",round(sqrt(as.numeric(aggr[9])),2))),cex=0.8)
text(-45,25,"Study",cex=.8,font=2)
text(67,25,"Incidence Rate (95% CI)",cex=.8,font=2)
text(-31,25,"Events",cex=.8,font=2)
text(-19,25,"Person-years",cex=.8,font=2)
text(-5,25,"Antipsychotic",cex=.8,font=2)
text(15,26,"Incidence of relapse during continuous antipsychotic treatment following confirmed symptom remission (k=19,n=2,938)",ps=3.5,font=2)
aggr<-rma.uni(nev,vi, slab=slab,method="REML",subset=(status=="Acute"))
addpoly(aggr,row=13,mlab="RE Model for Subgroup")
aggr<-rma.uni(nev,vi, slab=slab,method="REML",subset=(status=="Stable"))
addpoly(aggr,row=1,mlab="RE Model for Subgroup")

##META-ANALYSIS OF INCIDENCE RATE IN PARTICIPANTS WITHOUT PROSPECTIVE REMISSION

dat<-read.csv("[path]/per_year_nores_R.csv",header=TRUE,sep=",")
pool<-escalc("IR",xi=dat$x1i*100,ti=dat$t1i)
nev<-pool[[1]]
vi<-pool[[2]]
slab<-as.character(dat$study)
aggr<-rma.uni(nev,vi, slab=slab,method="REML")
antipsychotic<-as.character(dat$antipsychotic)
status<-as.character(dat$status)

#forest plot
forest(aggr,xlim=c(-50,95),at=c(0,10,20,30,40,50,60,70),ylim=c(-2,21),slab=slab,cex=1,ilab=cbind(dat$x1i,dat$t1i,antipsychotic),ilab.xpos=c(-28,-21,-7),rows=c(2:7,10:17),xlab="Incidence rate per 100 person-years")
op<-par(cex=0.8,font=2)
text(-31,c(18,8),c("Studies including acutely ill patients","Studies including only stable patients"))
par(op)                                         
text(-40,-2,c(paste("I^2=",round(as.numeric(aggr[25]),2),"%; tau=",round(sqrt(as.numeric(aggr[9])),2))),cex=0.8)
text(-45,20,"Study",cex=.8,font=2)
text(82,20,"Incidence Rate (95% CI)",cex=.8,font=2)
text(-31,20,"Events",cex=.8,font=2)
text(-19,20,"Person-years",cex=.8,font=2)
text(-5,20,"Antipsychotic",cex=.8,font=2)
text(22,21,"Incidence of relapse during continuous antipsychotic treatment in individuals with residual symptoms (k=14,n=2,192)",ps=4,font=2)
aggr<-rma.uni(nev,vi, slab=slab,method="REML",subset=(status=="Acute"))
addpoly(aggr,row=9,mlab="RE Model for Subgroup")
aggr<-rma.uni(nev,vi, slab=slab,method="REML",subset=(status=="Stable"))
addpoly(aggr,row=1,mlab="RE Model for Subgroup")

##IRR PSR vs non-PSR
res.dat<-read.csv("[path]/per_year_res_R.csv",header=TRUE,sep=",")

no.res.dat<-read.csv("[path]/per_year_nores_R2.csv",header=TRUE,sep=",")

ev.res<-as.numeric(res.dat$x1i)*100
py.res<-as.numeric(res.dat$t1i)
ev.no.res<-as.numeric(no.res.dat$x1i)*100
py.no.res<-as.numeric(no.res.dat$t1i)

pool<-escalc("IRR",x1i=ev.res,x2i=ev.no.res,t1i=py.res,t2i=py.no.res)

nev<-pool[[1]]
vi<-pool[[2]]
slab<-res.dat[,1]
aggr<-rma.uni(nev,vi,slab=slab,method="REML")

IRR<-exp(as.numeric(aggr[[1]]))
up.lim<-exp(as.numeric(aggr[[7]]))
low.lim<-exp(as.numeric(aggr[[6]]))
IRR_CI<-c(IRR,low.lim,up.lim)
IRR_CI

