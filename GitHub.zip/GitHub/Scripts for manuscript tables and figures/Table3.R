# Manuscript:Psychosis relapse during long-acting injectable antipsychotic treatment: An individual participant data meta-analysis of 19 trials and 5,111 individuals with schizophrenia-spectrum disorders
# Jose M Rubio M.D 4-9-2020
# Table 3

#TOTAL SAMPLE
hr.dat<-read.csv("[path]/HR_rma.csv",header=TRUE,sep=",")
slab<-hr.dat$study

#here yi and sei are log converted, so we have to back transform them via 'exp' to have non-log transformed HRs

#male gender

male.yi<-hr.dat$male.yi
male.sei<-hr.dat$male.sei
gender<-rma.uni(yi=male.yi,sei=male.sei,slab=slab)
hr.male<-round(as.numeric(c(gender[1],gender[6],gender[7],gender[25])),2)

#age

age.yi<-hr.dat$age.yi
age.sei<-hr.dat$age.sei
age<-rma.uni(yi=age.yi,sei=age.sei,slab=slab)
hr.age<-round(as.numeric(c(age[1],age[6],age[7],age[25])),2)

#Prop US pts

prop.yi<-hr.dat$prop.yi
prop.sei<-hr.dat$prop.sei
prop<-rma.uni(yi=prop.yi,sei=prop.sei,slab=slab)
hr.prop<-round(as.numeric(c(prop[1],prop[6],prop[7],prop[25])),2)

#BMI

bmi.yi<-hr.dat$bmi.yi
bmi.sei<-hr.dat$bmi.sei
bmi<-rma.uni(yi=bmi.yi,sei=bmi.sei,slab=slab)
hr.bmi<-round(as.numeric(c(bmi[1],bmi[6],bmi[7],bmi[25])),2)

#AGE OF DIAGNOSIS

agedi.yi<-hr.dat$diag.yi
agedi.sei<-hr.dat$diag..sei
agedi<-rma.uni(yi=agedi.yi,sei=agedi.sei,slab=slab)
hr.agedi<-round(as.numeric(c(agedi[1],agedi[6],agedi[7],agedi[25])),2)

#DURATION OF ILLNESS

doi.yi<-hr.dat$doi.yi
doi.sei<-hr.dat$doi.sei
doi<-rma.uni(yi=doi.yi,sei=doi.sei,slab=slab)
hr.doi<-round(as.numeric(c(doi[1],doi[6],doi[7],doi[25])),2)

#TIME SINCE LAST DISCHARGE

hosplyr.yi<-hr.dat$time.yi
hosplyr.sei<-hr.dat$time.sei
hosplyr<-rma.uni(yi=hosplyr.yi,sei=hosplyr.sei,slab=slab)
hr.hosplyr<-round(as.numeric(c(hosplyr[1],hosplyr[6],hosplyr[7],hosplyr[25])),2)

#NUMBER OF HOSPITALIZATIONS

num.yi<-hr.dat$num.yi
num.sei<-hr.dat$num.sei
num<-rma.uni(yi=num.yi,sei=num.sei,slab=slab)
hr.num<-round(as.numeric(c(num[1],num[6],num[7],num[25])),2)

#FAMILY HISTORY

fam.yi<-hr.dat$fam.yi
fam.sei<-hr.dat$fam.sei
fam<-rma.uni(yi=fam.yi,sei=fam.sei,slab=slab)
hr.fam<-round(as.numeric(c(fam[1],fam[6],fam[7],fam[25])),2)

#NICOTINE USE

smo.yi<-hr.dat$smo.yi
smo.sei<-hr.dat$smo.sei
smo<-rma.uni(yi=smo.yi,sei=smo.sei,slab=slab)
hr.smo<-round(as.numeric(c(smo[1],smo[6],smo[7],smo[25])),2)

#DRUG USE

dru.yi<-hr.dat$dru.yi
dru.sei<-hr.dat$dru.sei
dru<-rma.uni(yi=dru.yi,sei=dru.sei,slab=slab)
hr.dru<-round(as.numeric(c(dru[1],dru[6],dru[7],dru[25])),2)

#CGI

cgi.yi<-hr.dat$cgi.yi
cgi.sei<-hr.dat$cgi.sei
cgi<-rma.uni(yi=cgi.yi,sei=cgi.sei,slab=slab)
hr.cgi<-round(as.numeric(c(cgi[1],cgi[6],cgi[7],cgi[25])),2)

#TOTAL PSYCHOPATHOLOGY

tot.yi<-hr.dat$tot.yi
tot.sei<-hr.dat$tot.sei
tot<-rma.uni(yi=tot.yi,sei=tot.sei,slab=slab)
hr.tot<-round(as.numeric(c(tot[1],tot[6],tot[7],tot[25])),2)

#GENERAL PSYCHOPATHOLOGY

gen.yi<-hr.dat$gen.yi
gen.sei<-hr.dat$gen.sei
gen<-rma.uni(yi=gen.yi,sei=gen.sei,slab=slab)
hr.gen<-round(as.numeric(c(gen[1],gen[6],gen[7],gen[25])),2)

#POSITIVE PSYCHOPATHOLOGY

pos.yi<-hr.dat$pos.yi
pos.sei<-hr.dat$pos.sei
pos<-rma.uni(yi=pos.yi,sei=pos.sei,slab=slab)
hr.pos<-round(as.numeric(c(pos[1],pos[6],pos[7],pos[25])),2)

#NEGATIVE PSYCHOPATHOLOGY

neg.yi<-hr.dat$neg.yi
neg.sei<-hr.dat$neg.sei
neg<-rma.uni(yi=neg.yi,sei=neg.sei,slab=slab)
hr.neg<-round(as.numeric(c(neg[1],neg[6],neg[7],neg[25])),2)

#FUNCTIONING

fun.yi<-hr.dat$fun.yi
fun.sei<-hr.dat$fun.sei
fun<-rma.uni(yi=fun.yi,sei=fun.sei,slab=slab)
hr.fun<-round(as.numeric(c(fun[1],fun[6],fun[7],fun[25])),2)

#TARDIVE DYSKINESIA 

td.yi<-hr.dat$td.yi
td.sei<-hr.dat$td.sei
td<-rma.uni(yi=td.yi,sei=td.sei,slab=slab)
hr.td<-round(as.numeric(c(td[1],td[6],td[7],td[25])),2)

#AKATHISIA
aka.yi<-hr.dat$aka.yi
aka.sei<-hr.dat$aka.sei
aka<-rma.uni(yi=aka.yi,sei=aka.sei,slab=slab)
hr.aka<-round(as.numeric(c(aka[1],aka[6],aka[7],aka[25])),2)

#PARKINSONISM
par.yi<-hr.dat$par.yi
par.sei<-hr.dat$par.sei
par<-rma.uni(yi=par.yi,sei=par.sei,slab=slab)
hr.par<-round(as.numeric(c(par[1],par[6],par[7],par[25])),2)


hr.male<-c(exp(hr.male[1:3]),hr.male[4])
hr.age<-c(exp(hr.age[1:3]),hr.age[4])
hr.prop<-c(exp(hr.prop[1:3]),hr.prop[4])
hr.bmi<-c(exp(hr.bmi[1:3]),hr.bmi[4])
hr.agedi<-c(exp(hr.agedi[1:3]),hr.agedi[4])
hr.doi<-c(exp(hr.doi[1:3]),hr.doi[4])
hr.hosplyr<-c(exp(hr.hosplyr[1:3]),hr.hosplyr[4])
hr.num<-c(exp(hr.num[1:3]),hr.num[4])
hr.fam<-c(exp(hr.fam[1:3]),hr.fam[4])
hr.smo<-c(exp(hr.smo[1:3]),hr.smo[4])
hr.dru<-c(exp(hr.dru[1:3]),hr.dru[4])
hr.cgi<-c(exp(hr.cgi[1:3]),hr.cgi[4])
hr.tot<-c(exp(hr.tot[1:3]),hr.tot[4])
hr.gen<-c(exp(hr.gen[1:3]),hr.gen[4])
hr.pos<-c(exp(hr.pos[1:3]),hr.pos[4])
hr.neg<-c(exp(hr.neg[1:3]),hr.neg[4])
hr.fun<-c(exp(hr.fun[1:3]),hr.fun[4])
hr.td<-c(exp(hr.td[1:3]),hr.td[4])
hr.aka<-c(exp(hr.aka[1:3]),hr.aka[4])
hr.par<-c(exp(hr.par[1:3]),hr.par[4])

colnames<-c("Hazard Ratio","Lower limit 95% CI","Upper limit 95% CI","Heterogeneity (I^2%)")

mat.hr1<-rbind(colnames,hr.male,hr.age,hr.prop,hr.fam,hr.bmi,hr.td,hr.aka,hr.par,hr.smo,hr.dru,hr.agedi,hr.doi,hr.cgi,hr.fun,hr.tot,hr.gen,hr.pos,hr.neg)

rownames<-c("","Male gender","Age","US","Family history",
            "BMI","Tardive diskynesia","Akathisia","Parkinsonism","Smoking","Drug use","Age at diagnosis","Duration of illness","CGI","Functioning","Total psychopathology","General psychopathology","Positive psychopathology","Negative psychopathology")

mat.hr<-cbind(rownames,mat.hr1)

write.csv(mat.hr,"[path]/pooled HR.csv")

#####REMISSION SUBSAMPLE

hr.dat<-read.csv("[path]/HR_Res_rma.csv",header=TRUE,sep=",")
slab<-hr.dat$study

#male gender

male.yi<-hr.dat$male.yi
male.sei<-hr.dat$male.sei
gender<-rma.uni(yi=male.yi,sei=male.sei,slab=slab)
hr.male<-round(as.numeric(c(gender[1],gender[6],gender[7],gender[25])),2)

#age

age.yi<-hr.dat$age.yi
age.sei<-hr.dat$age.sei
age<-rma.uni(yi=age.yi,sei=age.sei,slab=slab)
hr.age<-round(as.numeric(c(age[1],age[6],age[7],age[25])),2)


#Prop US pts

prop.yi<-hr.dat$prop.yi
prop.sei<-hr.dat$prop.sei
prop<-rma.uni(yi=prop.yi,sei=prop.sei,slab=slab)
hr.prop<-round(as.numeric(c(prop[1],prop[6],prop[7],prop[25])),2)

#BMI

bmi.yi<-hr.dat$bmi.yi
bmi.sei<-hr.dat$bmi.sei
bmi<-rma.uni(yi=bmi.yi,sei=bmi.sei,slab=slab)
hr.bmi<-round(as.numeric(c(bmi[1],bmi[6],bmi[7],bmi[25])),2)

#AGE OF DIAGNOSIS

agedi.yi<-hr.dat$diag.yi
agedi.sei<-hr.dat$diag..sei
agedi<-rma.uni(yi=agedi.yi,sei=agedi.sei,slab=slab)
hr.agedi<-round(as.numeric(c(agedi[1],agedi[6],agedi[7],agedi[25])),2)

#DURATION OF ILLNESS

doi.yi<-hr.dat$doi.yi
doi.sei<-hr.dat$doi.sei
doi<-rma.uni(yi=doi.yi,sei=doi.sei,slab=slab)
hr.doi<-round(as.numeric(c(doi[1],doi[6],doi[7],doi[25])),2)

#TIME SINCE LAST DISCHARGE

hosplyr.yi<-hr.dat$time.yi
hosplyr.sei<-hr.dat$time.sei
hosplyr<-rma.uni(yi=hosplyr.yi,sei=hosplyr.sei,slab=slab)
hr.hosplyr<-round(as.numeric(c(hosplyr[1],hosplyr[6],hosplyr[7],hosplyr[25])),2)

#NUMBER OF HOSPITALIZATIONS

num.yi<-hr.dat$num.yi
num.sei<-hr.dat$num.sei
num<-rma.uni(yi=num.yi,sei=num.sei,slab=slab)
hr.num<-round(as.numeric(c(num[1],num[6],num[7],num[25])),2)

#FAMILY HISTORY

fam.yi<-hr.dat$fam.yi
fam.sei<-hr.dat$fam.sei
fam<-rma.uni(yi=fam.yi,sei=fam.sei,slab=slab)
hr.fam<-round(as.numeric(c(fam[1],fam[6],fam[7],fam[25])),2)

#NICOTINE USE

smo.yi<-hr.dat$smo.yi
smo.sei<-hr.dat$smo.sei
smo<-rma.uni(yi=smo.yi,sei=smo.sei,slab=slab)
hr.smo<-round(as.numeric(c(smo[1],smo[6],smo[7],smo[25])),2)

#DRUG USE

dru.yi<-hr.dat$dru.yi
dru.sei<-hr.dat$dru.sei
dru<-rma.uni(yi=dru.yi,sei=dru.sei,slab=slab)
hr.dru<-round(as.numeric(c(dru[1],dru[6],dru[7],dru[25])),2)

#CGI

cgi.yi<-hr.dat$cgi.yi
cgi.sei<-hr.dat$cgi.sei
cgi<-rma.uni(yi=cgi.yi,sei=cgi.sei,slab=slab)
hr.cgi<-round(as.numeric(c(cgi[1],cgi[6],cgi[7],cgi[25])),2)

#TOTAL PSYCHOPATHOLOGY

tot.yi<-hr.dat$tot.yi
tot.sei<-hr.dat$tot.sei
tot<-rma.uni(yi=tot.yi,sei=tot.sei,slab=slab)
hr.tot<-round(as.numeric(c(tot[1],tot[6],tot[7],tot[25])),2)

#GENERAL PSYCHOPATHOLOGY

gen.yi<-hr.dat$gen.yi
gen.sei<-hr.dat$gen.sei
gen<-rma.uni(yi=gen.yi,sei=gen.sei,slab=slab)
hr.gen<-round(as.numeric(c(gen[1],gen[6],gen[7],gen[25])),2)

#POSITIVE PSYCHOPATHOLOGY

pos.yi<-hr.dat$pos.yi
pos.sei<-hr.dat$pos.sei
pos<-rma.uni(yi=pos.yi,sei=pos.sei,slab=slab)
hr.pos<-round(as.numeric(c(pos[1],pos[6],pos[7],pos[25])),2)

#NEGATIVE PSYCHOPATHOLOGY

neg.yi<-hr.dat$neg.yi
neg.sei<-hr.dat$neg.sei
neg<-rma.uni(yi=neg.yi,sei=neg.sei,slab=slab)
hr.neg<-round(as.numeric(c(neg[1],neg[6],neg[7],neg[25])),2)

#FUNCTIONING

fun.yi<-hr.dat$fun.yi
fun.sei<-hr.dat$fun.sei
fun<-rma.uni(yi=fun.yi,sei=fun.sei,slab=slab)
hr.fun<-round(as.numeric(c(fun[1],fun[6],fun[7],fun[25])),2)

#TARDIVE DYSKINESIA 

td.yi<-hr.dat$td.yi
td.sei<-hr.dat$td.sei
td<-rma.uni(yi=td.yi,sei=td.sei,slab=slab)
hr.td<-round(as.numeric(c(td[1],td[6],td[7],td[25])),2)

#AKATHISIA
aka.yi<-hr.dat$aka.yi
aka.sei<-hr.dat$aka.sei
aka<-rma.uni(yi=aka.yi,sei=aka.sei,slab=slab)
hr.aka<-round(as.numeric(c(aka[1],aka[6],aka[7],aka[25])),2)

#PARKINSONISM
par.yi<-hr.dat$par.yi
par.sei<-hr.dat$par.sei
par<-rma.uni(yi=par.yi,sei=par.sei,slab=slab)
hr.par<-round(as.numeric(c(par[1],par[6],par[7],par[25])),2)

#FAMILY HISTORY
fam.yi<-hr.dat$fam.yi
fam.sei<-hr.dat$fam.sei
fam<-rma.uni(yi=fam.yi,sei=fam.sei,slab=slab)
hr.fam<-round(as.numeric(c(fam[1],fam[6],fam[7],fam[25])),2)

hr.male<-c(exp(hr.male[1:3]),hr.male[4])
hr.age<-c(exp(hr.age[1:3]),hr.age[4])
hr.prop<-c(exp(hr.prop[1:3]),hr.prop[4])
hr.bmi<-c(exp(hr.bmi[1:3]),hr.bmi[4])
hr.agedi<-c(exp(hr.agedi[1:3]),hr.agedi[4])
hr.doi<-c(exp(hr.doi[1:3]),hr.doi[4])
hr.hosplyr<-c(exp(hr.hosplyr[1:3]),hr.hosplyr[4])
hr.num<-c(exp(hr.num[1:3]),hr.num[4])
hr.fam<-c(exp(hr.fam[1:3]),hr.fam[4])
hr.smo<-c(exp(hr.smo[1:3]),hr.smo[4])
hr.dru<-c(exp(hr.dru[1:3]),hr.dru[4])
hr.cgi<-c(exp(hr.cgi[1:3]),hr.cgi[4])
hr.tot<-c(exp(hr.tot[1:3]),hr.tot[4])
hr.gen<-c(exp(hr.gen[1:3]),hr.gen[4])
hr.pos<-c(exp(hr.pos[1:3]),hr.pos[4])
hr.neg<-c(exp(hr.neg[1:3]),hr.neg[4])
hr.fun<-c(exp(hr.fun[1:3]),hr.fun[4])
hr.td<-c(exp(hr.td[1:3]),hr.td[4])
hr.aka<-c(exp(hr.aka[1:3]),hr.aka[4])
hr.par<-c(exp(hr.par[1:3]),hr.par[4])

colnames<-c("Hazard Ratio","Lower limit 95% CI","Upper limit 95% CI","Heterogeneity (I^2%)")

mat.hr1<-rbind(colnames,hr.male,hr.age,hr.prop,hr.fam,hr.bmi,hr.td,hr.aka,hr.par,hr.smo,hr.dru,hr.agedi,hr.doi,hr.cgi,hr.fun,hr.tot,hr.gen,hr.pos,hr.neg)

rownames<-c("","Male gender","Age","US","Family history",
            "BMI","Tardive diskynesia","Akathisia","Parkinsonism","Smoking","Drug use","Age at diagnosis","Duration of illness","CGI","Functioning","Total psychopathology","General psychopathology","Positive psychopathology","Negative psychopathology")

mat.hr<-cbind(rownames,mat.hr1)

write.csv(mat.hr,"[path]/pooled HR_remission.csv")

##### NO REMISSION SUBSAMPLE

hr.dat<-read.csv("[path]/HR_Nores.csv",header=TRUE,sep=",")
slab<-hr.dat$study

#male gender

male.yi<-hr.dat$male.yi
male.sei<-hr.dat$male.sei
gender<-rma.uni(yi=male.yi,sei=male.sei,slab=slab)
hr.male<-round(as.numeric(c(gender[1],gender[6],gender[7],gender[25])),2)

#age

age.yi<-hr.dat$age.yi
age.sei<-hr.dat$age.sei
age<-rma.uni(yi=age.yi,sei=age.sei,slab=slab)
hr.age<-round(as.numeric(c(age[1],age[6],age[7],age[25])),2)


#Prop US pts

prop.yi<-hr.dat$prop.yi
prop.sei<-hr.dat$prop.sei
prop<-rma.uni(yi=prop.yi,sei=prop.sei,slab=slab)
hr.prop<-round(as.numeric(c(prop[1],prop[6],prop[7],prop[25])),2)

#BMI

bmi.yi<-hr.dat$bmi.yi
bmi.sei<-hr.dat$bmi.sei
bmi<-rma.uni(yi=bmi.yi,sei=bmi.sei,slab=slab)
hr.bmi<-round(as.numeric(c(bmi[1],bmi[6],bmi[7],bmi[25])),2)

#AGE OF DIAGNOSIS

agedi.yi<-hr.dat$diag.yi
agedi.sei<-hr.dat$diag..sei
agedi<-rma.uni(yi=agedi.yi,sei=agedi.sei,slab=slab)
hr.agedi<-round(as.numeric(c(agedi[1],agedi[6],agedi[7],agedi[25])),2)

#DURATION OF ILLNESS

doi.yi<-hr.dat$doi.yi
doi.sei<-hr.dat$doi.sei
doi<-rma.uni(yi=doi.yi,sei=doi.sei,slab=slab)
hr.doi<-round(as.numeric(c(doi[1],doi[6],doi[7],doi[25])),2)

#TIME SINCE LAST DISCHARGE

hosplyr.yi<-hr.dat$time.yi
hosplyr.sei<-hr.dat$time.sei
hosplyr<-rma.uni(yi=hosplyr.yi,sei=hosplyr.sei,slab=slab)
hr.hosplyr<-round(as.numeric(c(hosplyr[1],hosplyr[6],hosplyr[7],hosplyr[25])),2)

#NUMBER OF HOSPITALIZATIONS

num.yi<-hr.dat$num.yi
num.sei<-hr.dat$num.sei
num<-rma.uni(yi=num.yi,sei=num.sei,slab=slab)
hr.num<-round(as.numeric(c(num[1],num[6],num[7],num[25])),2)

#FAMILY HISTORY

fam.yi<-hr.dat$fam.yi
fam.sei<-hr.dat$fam.sei
fam<-rma.uni(yi=fam.yi,sei=fam.sei,slab=slab)
hr.fam<-round(as.numeric(c(fam[1],fam[6],fam[7],fam[25])),2)

#NICOTINE USE

smo.yi<-hr.dat$smo.yi
smo.sei<-hr.dat$smo.sei
smo<-rma.uni(yi=smo.yi,sei=smo.sei,slab=slab)
hr.smo<-round(as.numeric(c(smo[1],smo[6],smo[7],smo[25])),2)

#DRUG USE

dru.yi<-hr.dat$dru.yi
dru.sei<-hr.dat$dru.sei
dru<-rma.uni(yi=dru.yi,sei=dru.sei,slab=slab)
hr.dru<-round(as.numeric(c(dru[1],dru[6],dru[7],dru[25])),2)

#CGI

cgi.yi<-hr.dat$cgi.yi
cgi.sei<-hr.dat$cgi.sei
cgi<-rma.uni(yi=cgi.yi,sei=cgi.sei,slab=slab)
hr.cgi<-round(as.numeric(c(cgi[1],cgi[6],cgi[7],cgi[25])),2)

#TOTAL PSYCHOPATHOLOGY

tot.yi<-hr.dat$tot.yi
tot.sei<-hr.dat$tot.sei
tot<-rma.uni(yi=tot.yi,sei=tot.sei,slab=slab)
hr.tot<-round(as.numeric(c(tot[1],tot[6],tot[7],tot[25])),2)

#GENERAL PSYCHOPATHOLOGY

gen.yi<-hr.dat$gen.yi
gen.sei<-hr.dat$gen.sei
gen<-rma.uni(yi=gen.yi,sei=gen.sei,slab=slab)
hr.gen<-round(as.numeric(c(gen[1],gen[6],gen[7],gen[25])),2)

#POSITIVE PSYCHOPATHOLOGY

pos.yi<-hr.dat$pos.yi
pos.sei<-hr.dat$pos.sei
pos<-rma.uni(yi=pos.yi,sei=pos.sei,slab=slab)
hr.pos<-round(as.numeric(c(pos[1],pos[6],pos[7],pos[25])),2)

#NEGATIVE PSYCHOPATHOLOGY

neg.yi<-hr.dat$neg.yi
neg.sei<-hr.dat$neg.sei
neg<-rma.uni(yi=neg.yi,sei=neg.sei,slab=slab)
hr.neg<-round(as.numeric(c(neg[1],neg[6],neg[7],neg[25])),2)

#FUNCTIONING

fun.yi<-hr.dat$fun.yi
fun.sei<-hr.dat$fun.sei
fun<-rma.uni(yi=fun.yi,sei=fun.sei,slab=slab)
hr.fun<-round(as.numeric(c(fun[1],fun[6],fun[7],fun[25])),2)

#TARDIVE DYSKINESIA 

td.yi<-hr.dat$td.yi
td.sei<-hr.dat$td.sei
td<-rma.uni(yi=td.yi,sei=td.sei,slab=slab)
hr.td<-round(as.numeric(c(td[1],td[6],td[7],td[25])),2)

#AKATHISIA
aka.yi<-hr.dat$aka.yi
aka.sei<-hr.dat$aka.sei
aka<-rma.uni(yi=aka.yi,sei=aka.sei,slab=slab)
hr.aka<-round(as.numeric(c(aka[1],aka[6],aka[7],aka[25])),2)

#PARKINSONISM
par.yi<-hr.dat$par.yi
par.sei<-hr.dat$par.sei
par<-rma.uni(yi=par.yi,sei=par.sei,slab=slab)
hr.par<-round(as.numeric(c(par[1],par[6],par[7],par[25])),2)

#FAMILY HISTORY
fam.yi<-hr.dat$fam.yi
fam.sei<-hr.dat$fam.sei
fam<-rma.uni(yi=fam.yi,sei=fam.sei,slab=slab)
hr.fam<-round(as.numeric(c(fam[1],fam[6],fam[7],fam[25])),2)


hr.male<-c(exp(hr.male[1:3]),hr.male[4])
hr.age<-c(exp(hr.age[1:3]),hr.age[4])
hr.prop<-c(exp(hr.prop[1:3]),hr.prop[4])
hr.bmi<-c(exp(hr.bmi[1:3]),hr.bmi[4])
hr.agedi<-c(exp(hr.agedi[1:3]),hr.agedi[4])
hr.doi<-c(exp(hr.doi[1:3]),hr.doi[4])
hr.hosplyr<-c(exp(hr.hosplyr[1:3]),hr.hosplyr[4])
hr.num<-c(exp(hr.num[1:3]),hr.num[4])
hr.fam<-c(exp(hr.fam[1:3]),hr.fam[4])
hr.smo<-c(exp(hr.smo[1:3]),hr.smo[4])
hr.dru<-c(exp(hr.dru[1:3]),hr.dru[4])
hr.cgi<-c(exp(hr.cgi[1:3]),hr.cgi[4])
hr.tot<-c(exp(hr.tot[1:3]),hr.tot[4])
hr.gen<-c(exp(hr.gen[1:3]),hr.gen[4])
hr.pos<-c(exp(hr.pos[1:3]),hr.pos[4])
hr.neg<-c(exp(hr.neg[1:3]),hr.neg[4])
hr.fun<-c(exp(hr.fun[1:3]),hr.fun[4])
hr.td<-c(exp(hr.td[1:3]),hr.td[4])
hr.aka<-c(exp(hr.aka[1:3]),hr.aka[4])
hr.par<-c(exp(hr.par[1:3]),hr.par[4])

colnames<-c("Hazard Ratio","Lower limit 95% CI","Upper limit 95% CI","Heterogeneity (I^2%)")

mat.hr1<-rbind(colnames,hr.male,hr.age,hr.prop,hr.fam,hr.bmi,hr.td,hr.aka,hr.par,hr.smo,hr.dru,hr.agedi,hr.doi,hr.cgi,hr.fun,hr.tot,hr.gen,hr.pos,hr.neg)

rownames<-c("","Male gender","Age","US","Family history",
            "BMI","Tardive diskynesia","Akathisia","Parkinsonism","Smoking","Drug use","Age at diagnosis","Duration of illness","CGI","Functioning","Total psychopathology","General psychopathology","Positive psychopathology","Negative psychopathology")

mat.hr<-cbind(rownames,mat.hr1)

write.csv(mat.hr,"[path]/pooled HR_no_remission.csv")

# Outlier studies drive to "Inf" result for "smoking","TD,"akathisia,"parkinsonism"
# Will repeat those analysis removing outliers

#TARDIVE DYSKINESIA 

td.yi<-hr.dat$td.yi[c(1:3,10:12)]
td.sei<-hr.dat$td.sei[c(1:3,10:12)]
td<-rma.uni(yi=td.yi,sei=td.sei)
hr.td<-round(as.numeric(c(td[1],td[6],td[7],td[25])),2)
hr.td<-c(exp(hr.td[1:3]),hr.td[4])

#AKATHISIA
aka.yi<-hr.dat$aka.yi[c(1,2,3,6,7,11,12,13)]
aka.sei<-hr.dat$aka.sei[c(1,2,3,6,7,11,12,13)]
aka<-rma.uni(yi=aka.yi,sei=aka.sei)
hr.aka<-round(as.numeric(c(aka[1],aka[6],aka[7],aka[25])),2)
hr.aka<-c(exp(hr.aka[1:3]),hr.aka[4])

#PARKINSONISM
par.yi<-hr.dat$par.yi[c(1:4,6:8,10:13)]
par.sei<-hr.dat$par.sei[c(1:4,6:8,10:13)]
par<-rma.uni(yi=par.yi,sei=par.sei)
hr.par<-round(as.numeric(c(par[1],par[6],par[7],par[25])),2)
hr.par<-c(exp(hr.par[1:3]),hr.par[4])

#SMOKING
smo.yi<-hr.dat$smo.yi[c(1:4,6:19)]
smo.sei<-hr.dat$smo.sei[c(1:4,6:19)]
smo<-rma.uni(yi=smo.yi,sei=smo.sei)
hr.smo<-round(as.numeric(c(smo[1],smo[6],smo[7],smo[25])),2)
hr.smo<-c(exp(hr.smo[1:3]),hr.smo[4])


##NOW COMPARISON OF HRs BETWEEN REMISSION AND NO REMISSION IS DONE USING p Values OF INTERACTION TERM (covariate*status)

hr.dat<-read.csv("[path]/HR_int.csv",header=TRUE,sep=",")

#male gender

male.yi<-hr.dat$male.yi
male.sei<-hr.dat$male.sei
gender<-rma.uni(yi=male.yi,sei=male.sei,slab=slab)
hr.male<-round(as.numeric(c(gender[1],gender[6],gender[7],gender[25])),2)
p.male<-gender[5]

#age

age.yi<-hr.dat$age.yi
age.sei<-hr.dat$age.sei
age<-rma.uni(yi=age.yi,sei=age.sei,slab=slab)
hr.age<-round(as.numeric(c(age[1],age[6],age[7],age[25])),2)
p.age<-age[5]


#Prop US pts

prop.yi<-hr.dat$prop.yi
prop.sei<-hr.dat$prop.sei
prop<-rma.uni(yi=prop.yi,sei=prop.sei,slab=slab)
hr.prop<-round(as.numeric(c(prop[1],prop[6],prop[7],prop[25])),2)
p.prop<-prop[5]

#BMI

bmi.yi<-hr.dat$bmi.yi
bmi.sei<-hr.dat$bmi.sei
bmi<-rma.uni(yi=bmi.yi,sei=bmi.sei,slab=slab)
hr.bmi<-round(as.numeric(c(bmi[1],bmi[6],bmi[7],bmi[25])),2)
p.bmi<-bmi[5]

#AGE OF DIAGNOSIS

agedi.yi<-hr.dat$diag.yi
agedi.sei<-hr.dat$diag..sei
agedi<-rma.uni(yi=agedi.yi,sei=agedi.sei,slab=slab)
hr.agedi<-round(as.numeric(c(agedi[1],agedi[6],agedi[7],agedi[25])),2)
p.agedi<-agedi[5]

#DURATION OF ILLNESS

doi.yi<-hr.dat$doi.yi
doi.sei<-hr.dat$doi.sei
doi<-rma.uni(yi=doi.yi,sei=doi.sei,slab=slab)
hr.doi<-round(as.numeric(c(doi[1],doi[6],doi[7],doi[25])),2)
p.doi<-doi[5]

#TIME SINCE LAST DISCHARGE

hosplyr.yi<-hr.dat$time.yi
hosplyr.sei<-hr.dat$time.sei
hosplyr<-rma.uni(yi=hosplyr.yi,sei=hosplyr.sei,slab=slab)
hr.hosplyr<-round(as.numeric(c(hosplyr[1],hosplyr[6],hosplyr[7],hosplyr[25])),2)
p.hosplyr<-hosplyr[5]

#NUMBER OF HOSPITALIZATIONS

num.yi<-hr.dat$num.yi
num.sei<-hr.dat$num.sei
num<-rma.uni(yi=num.yi,sei=num.sei,slab=slab)
hr.num<-round(as.numeric(c(num[1],num[6],num[7],num[25])),2)
p.num<-num[5]

#FAMILY HISTORY

fam.yi<-hr.dat$fam.yi
fam.sei<-hr.dat$fam.sei
fam<-rma.uni(yi=fam.yi,sei=fam.sei,slab=slab)
hr.fam<-round(as.numeric(c(fam[1],fam[6],fam[7],fam[25])),2)
p.fam<-fam[5]

#NICOTINE USE

smo.yi<-hr.dat$smo.yi
smo.sei<-hr.dat$smo.sei
smo<-rma.uni(yi=smo.yi,sei=smo.sei,slab=slab)
hr.smo<-round(as.numeric(c(smo[1],smo[6],smo[7],smo[25])),2)
p.smo<-smo[5]

#DRUG USE

dru.yi<-hr.dat$dru.yi
dru.sei<-hr.dat$dru.sei
dru<-rma.uni(yi=dru.yi,sei=dru.sei,slab=slab)
hr.dru<-round(as.numeric(c(dru[1],dru[6],dru[7],dru[25])),2)
p.dru<-dru[5]

#CGI

cgi.yi<-hr.dat$cgi.yi
cgi.sei<-hr.dat$cgi.sei
cgi<-rma.uni(yi=cgi.yi,sei=cgi.sei,slab=slab)
hr.cgi<-round(as.numeric(c(cgi[1],cgi[6],cgi[7],cgi[25])),2)
p.cgi<-cgi[5]

#TOTAL PSYCHOPATHOLOGY

tot.yi<-hr.dat$tot.yi
tot.sei<-hr.dat$tot.sei
tot<-rma.uni(yi=tot.yi,sei=tot.sei,slab=slab)
hr.tot<-round(as.numeric(c(tot[1],tot[6],tot[7],tot[25])),2)
p.tot<-tot[5]

#GENERAL PSYCHOPATHOLOGY

gen.yi<-hr.dat$gen.yi
gen.sei<-hr.dat$gen.sei
gen<-rma.uni(yi=gen.yi,sei=gen.sei,slab=slab)
hr.gen<-round(as.numeric(c(gen[1],gen[6],gen[7],gen[25])),2)
p.gen<-gen[5]

#POSITIVE PSYCHOPATHOLOGY

pos.yi<-hr.dat$pos.yi
pos.sei<-hr.dat$pos.sei
pos<-rma.uni(yi=pos.yi,sei=pos.sei,slab=slab)
hr.pos<-round(as.numeric(c(pos[1],pos[6],pos[7],pos[25])),2)
p.pos<-pos[5]

#NEGATIVE PSYCHOPATHOLOGY

neg.yi<-hr.dat$neg.yi
neg.sei<-hr.dat$neg.sei
neg<-rma.uni(yi=neg.yi,sei=neg.sei,slab=slab)
hr.neg<-round(as.numeric(c(neg[1],neg[6],neg[7],neg[25])),2)
p.neg<-neg[5]

#FUNCTIONING

fun.yi<-hr.dat$fun.yi
fun.sei<-hr.dat$fun.sei
fun<-rma.uni(yi=fun.yi,sei=fun.sei,slab=slab)
hr.fun<-round(as.numeric(c(fun[1],fun[6],fun[7],fun[25])),2)
p.fun<-fun[5]

#TARDIVE DYSKINESIA 

td.yi<-hr.dat$td.yi
td.sei<-hr.dat$td.sei
td<-rma.uni(yi=td.yi,sei=td.sei,slab=slab)
hr.td<-round(as.numeric(c(td[1],td[6],td[7],td[25])),2)
p.td<-td[5]

#AKATHISIA
aka.yi<-hr.dat$aka.yi
aka.sei<-hr.dat$aka.sei
aka<-rma.uni(yi=aka.yi,sei=aka.sei,slab=slab)
hr.aka<-round(as.numeric(c(aka[1],aka[6],aka[7],aka[25])),2)
p.aka<-aka[5]

#PARKINSONISM
par.yi<-hr.dat$par.yi
par.sei<-hr.dat$par.sei
par<-rma.uni(yi=par.yi,sei=par.sei,slab=slab)
hr.par<-round(as.numeric(c(par[1],par[6],par[7],par[25])),2)
p.par<-par[5]

pvals<-c(p.male,p.age,p.prop,p.fam,p.bmi,p.td,p.aka,p.par,p.smo,p.dru,p.agedi,p.doi,p.cgi,p.fun,p.tot,p.gen,p.pos,p.neg)
