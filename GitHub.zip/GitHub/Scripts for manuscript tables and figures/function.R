# Manuscript:Psychosis relapse during long-acting injectable antipsychotic treatment: An individual participant data meta-analysis of 19 trials and 5,111 individuals with schizophrenia-spectrum disorders
# Jose M Rubio M.D 4-9-2020
# Comparison of change in overall functioning over observation period between relapsers and non-relapsers

library(tidyverse)
library(metafor)
data<-read_csv("[path]/deltafunc.csv")

mean_rel<-data$`mean delta rel`
sd_rel<-data$`sd delta rel`
n_rel<-data$`n rel`
mean_norel<-data$`mean delta norel`
sd_norel<-data$`sd delta norel`
n_norel<-data$`n norel`
  
obj<-escalc(m1i=mean_rel, sd1i=sd_rel, n1i=n_rel,m2i=mean_norel,sd2i=sd_norel,n2i=n_norel,measure="SMD")
rma.uni(obj)

#PSR
data<-read_csv("[path]/deltafunc_PSR.csv")

mean_rel<-data$`mean delta rel`
sd_rel<-data$`sd delta rel`
n_rel<-data$`n rel`
mean_norel<-data$`mean delta norel`
sd_norel<-data$`sd delta norel`
n_norel<-data$`n norel`

obj<-escalc(m1i=mean_rel, sd1i=sd_rel, n1i=n_rel,m2i=mean_norel,sd2i=sd_norel,n2i=n_norel,measure="SMD")
rma.uni(obj)

#Non-PSR
data<-read_csv("[path]/deltafunc_NoPSR.csv")

mean_rel<-data$`mean delta rel`
sd_rel<-data$`sd delta rel`
n_rel<-data$`n rel`
mean_norel<-data$`mean delta norel`
sd_norel<-data$`sd delta norel`
n_norel<-data$`n norel`

obj<-escalc(m1i=mean_rel, sd1i=sd_rel, n1i=n_rel,m2i=mean_norel,sd2i=sd_norel,n2i=n_norel,measure="SMD")
rma.uni(obj)