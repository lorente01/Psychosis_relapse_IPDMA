# Manuscript:Psychosis relapse during long-acting injectable antipsychotic treatment: An individual participant data meta-analysis of 19 trials and 5,111 individuals with schizophrenia-spectrum disorders
# Jose M Rubio M.D 4-9-2020
# Table 2

library(metafor)
################# TOTAL SAMPLE
data<-read.csv("[path]/table1raw.csv", header=TRUE, sep=",")
num<-data[,2]

## categorical variables total - total

k.male<-length(data[1:19,2])
n.male<-sum(data[1:19,2],na.rm=T)
num.male<-sum(data[1:19,3],na.rm=T)
perc.male<-(num.male/n.male)*100

k.US<-length(data[1:19,2])
n.US<-sum(data[1:19,2],na.rm=T)
num.US<-sum(data[1:19,5],na.rm=T)
perc.US<-(num.US/n.US)*100

k.fhx<-length(data[c(10,15:17),2])
n.fhx<-sum(data[c(10,15:17),2],na.rm=T)
num.fhx<-sum(data[c(10,15:17),7],na.rm=T)
perc.fhx<-(num.fhx/n.fhx)*100

k.smok<-length(data[c(1:7,9,11:17),2])
n.smok<-sum(data[c(1:7,9,11:17),2],na.rm=T)
num.smok<-sum(data[c(1:7,9,11:17),9],na.rm=T)
perc.smok<-num.smok/n.smok*100

k.drug<-length(data[c(9,11:13),2])
n.drug<-sum((data[c(9,11:13),2]),na.rm=T)
num.drug<-sum(data[c(9,11:13),11],na.rm=T)
perc.drug<-num.drug/n.drug*100

k.3hosp<-length(data[c(1,10:17),2])
n.3hosp<-sum((data[c(1,10:17),2]),na.rm=T)
num.3hosp<-sum(data[c(1,10:17),13],na.rm=T)
perc.3hosp<-num.3hosp/n.3hosp*100

k.hosplyr<-length(data[c(1:6,13:17),2])
n.hosplyr<-sum((data[c(1:6,13:17),2]),na.rm=T)
num.hosplyr<-sum(data[c(1:6,13:17),15],na.rm=T)
perc.hosplyr<-num.hosplyr/n.hosplyr*100

k.td<-length(data[1:17,2])
n.td<-sum((data[1:17,2]),na.rm=T)
num.td<-sum(data[1:17,17],na.rm=T)
perc.td<-num.td/n.td*100

k.aka<-length(data[1:17,2])
n.aka<-sum((data[1:17,2]),na.rm=T)
num.aka<-sum(data[1:17,19],na.rm=T)
perc.aka<-num.aka/n.aka*100

k.eps<-length(data[1:17,2])
n.eps<-sum((data[1:17,2]),na.rm=T)
num.eps<-sum(data[1:17,21],na.rm=T)
perc.eps<-num.eps/n.eps*100

####NOW CONTINUOUS VARIABLES

k.age<-length(data[,2])
num.age<-sum(data[,2],na.rm=T)
n.age<-data[,2]
m.age<-data[,23]
sd.age<-data[,24]
age.pool<-escalc(measure="MN",ni=n.age,mi=m.age,sdi=sd.age)
yi<-age.pool[[1]]
vi<-age.pool[[2]]
age.rma<-rma.uni(yi,vi,method="REML")
mean.age<-as.numeric(age.rma[[1]])
SE.age<-age.rma[[3]]


#BMI
k.BMI<-length(data[,2])
num.BMI<-sum(data[,2],na.rm=T)
n.BMI<-data[,2]
m.BMI<-data[,25]
sd.BMI<-data[,26]
BMI.pool<-escalc(measure="MN",ni=n.BMI,mi=m.BMI,sdi=sd.BMI)
yi<-BMI.pool[[1]]
vi<-BMI.pool[[2]]
BMI.rma<-rma.uni(yi,vi,method="REML")
mean.BMI<-as.numeric(BMI.rma[[1]])
SE.BMI<-BMI.rma[[3]]


#AGEDIAG
k.agediag<-length(data[c(1:6,8,10:19),2])
num.agediag<-sum(data[c(1:6,8,10:19),2],na.rm=T)
n.agediag<-data[c(1:6,8,10:19),2]
m.agediag<-data[c(1:6,8,10:19),27]
sd.agediag<-data[c(1:6,8,10:19),28]
agediag.pool<-escalc(measure="MN",ni=n.agediag,mi=m.agediag,sdi=sd.agediag)
yi<-agediag.pool[[1]]
vi<-agediag.pool[[2]]
agediag.rma<-rma.uni(yi,vi,method="REML")
mean.agediag<-as.numeric(agediag.rma[[1]])
SE.agediag<-agediag.rma[[3]]


#DOI
k.doi<-length(data[c(1:6,8,10:19),2])
num.doi<-sum(data[c(1:6,8,10:19),2],na.rm=T)
n.doi<-data[c(1:6,8,10:19),2]
m.doi<-data[c(1:6,8,10:19),29]
sd.doi<-data[c(1:6,8,10:19),30]
doi.pool<-escalc(measure="MN",ni=n.doi,mi=m.doi,sdi=sd.doi)
yi<-doi.pool[[1]]
vi<-doi.pool[[2]]
doi.rma<-rma.uni(yi,vi,method="REML")
mean.doi<-as.numeric(doi.rma[[1]])
SE.doi<-doi.rma[[3]]


# CGI
k.CGI<-length(data[,2])
num.CGI<-sum(data[,2],na.rm=T)
n.CGI<-data[,2]
m.CGI<-data[,31]
sd.CGI<-data[,32]
CGI.pool<-escalc(measure="MN",ni=n.CGI,mi=m.CGI,sdi=sd.CGI)
yi<-CGI.pool[[1]]
vi<-CGI.pool[[2]]
CGI.rma<-rma.uni(yi,vi,method="REML")
mean.CGI<-as.numeric(CGI.rma[[1]])
SE.CGI<-CGI.rma[[3]]


# PANSSTot
k.PANSSTot<-length(data[c(1:12,14:19),2])
num.PANSSTot<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSTot<-data[c(1:12,14:19),2]
m.PANSSTot<-data[c(1:12,14:19),33]
sd.PANSSTot<-data[c(1:12,14:19),34]
PANSSTot.pool<-escalc(measure="MN",ni=n.PANSSTot,mi=m.PANSSTot,sdi=sd.PANSSTot)
yi<-PANSSTot.pool[[1]]
vi<-PANSSTot.pool[[2]]
PANSSTot.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSTot<-as.numeric(PANSSTot.rma[[1]])
SE.PANSSTot<-PANSSTot.rma[[3]]


# PANSSGen
k.PANSSGen<-length(data[c(1:12,14:19),2])
num.PANSSGen<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSGen<-data[c(1:12,14:19),2]
m.PANSSGen<-data[c(1:12,14:19),35]
sd.PANSSGen<-data[c(1:12,14:19),36]
PANSSGen.pool<-escalc(measure="MN",ni=n.PANSSGen,mi=m.PANSSGen,sdi=sd.PANSSGen)
yi<-PANSSGen.pool[[1]]
vi<-PANSSGen.pool[[2]]
PANSSGen.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSGen<-as.numeric(PANSSGen.rma[[1]])
SE.PANSSGen<-PANSSGen.rma[[3]]



# PANSSPos
k.PANSSPos<-length(data[c(1:12,14:19),2])
num.PANSSPos<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSPos<-data[c(1:12,14:19),2]
m.PANSSPos<-data[c(1:12,14:19),37]
sd.PANSSPos<-data[c(1:12,14:19),38]
PANSSPos.pool<-escalc(measure="MN",ni=n.PANSSPos,mi=m.PANSSPos,sdi=sd.PANSSPos)
yi<-PANSSPos.pool[[1]]
vi<-PANSSPos.pool[[2]]
PANSSPos.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSPos<-as.numeric(PANSSPos.rma[[1]])
SE.PANSSPos<-PANSSPos.rma[[3]]


# PANSSNeg
k.PANSSNeg<-length(data[c(1:12,14:19),2])
num.PANSSNeg<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSNeg<-data[c(1:12,14:19),2]
m.PANSSNeg<-data[c(1:12,14:19),39]
sd.PANSSNeg<-data[c(1:12,14:19),40]
PANSSNeg.pool<-escalc(measure="MN",ni=n.PANSSNeg,mi=m.PANSSNeg,sdi=sd.PANSSNeg)
yi<-PANSSNeg.pool[[1]]
vi<-PANSSNeg.pool[[2]]
PANSSNeg.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSNeg<-as.numeric(PANSSNeg.rma[[1]])
SE.PANSSNeg<-PANSSNeg.rma[[3]]


#PSP
k.PSP<-length(data[c(1:3,7,9:10),2])
num.PSP<-sum(data[c(1:3,7,9:10),2],na.rm=T)
n.PSP<-data[c(1:3,7,9:10),2]
m.PSP<-data[c(1:3,7,9:10),41]
sd.PSP<-data[c(1:3,7,9:10),42]
PSP.pool<-escalc(measure="MN",ni=n.PSP,mi=m.PSP,sdi=sd.PSP)
yi<-PSP.pool[[1]]
vi<-PSP.pool[[2]]
PSP.rma<-rma.uni(yi,vi,method="REML")
mean.PSP<-as.numeric(PSP.rma[[1]])
SE.PSP<-PSP.rma[[3]]*sqrt(k.PSP)


male<-round(c(k.male,n.male,num.male,perc.male),2)

US<-round(c(k.US,n.US,num.US,perc.US),2)

fhx<-round(c(k.fhx,n.fhx,num.fhx,perc.fhx),2)

smok<-round(c(k.smok,n.smok,num.smok,perc.smok),2)

drug<-round(c(k.drug,n.drug,num.drug,perc.drug),2)

threehosp<-round(c(k.3hosp,n.3hosp,num.3hosp,perc.3hosp),2)

hosplyr<-round(c(k.hosplyr,n.hosplyr,num.hosplyr,perc.hosplyr),2)

td<-round(c(k.td,n.td,num.td,perc.td),2)

aka<-round(c(k.aka,n.aka,num.aka,perc.aka),2)

eps<-round(c(k.eps,n.eps,num.eps,perc.eps),2)

age<-c(floor(k.age),floor(num.age),round(mean.age,2),round(SE.age,2))

BMI<-c(floor(k.BMI),floor(num.BMI),round(mean.BMI,2),round(SE.BMI,2))

agediag<-c(floor(k.agediag),floor(num.agediag),round(mean.agediag,2),round(SE.agediag,2))

doi<-c(floor(k.doi),floor(num.doi),round(mean.doi,2),round(SE.doi,2))

CGI<-c(floor(k.CGI),floor(num.CGI),round(mean.CGI,2),round(SE.CGI,2))

PANSSTot<-c(floor(k.PANSSTot),floor(num.PANSSTot),round(mean.PANSSTot,2),round(SE.PANSSTot,2))

PANSSGen<-c(floor(k.PANSSGen),floor(num.PANSSGen),round(mean.PANSSGen,2),round(SE.PANSSGen,2))

PANSSPos<-c(floor(k.PANSSPos),floor(num.PANSSPos),round(mean.PANSSPos,2),round(SE.PANSSPos,2))

PANSSNeg<-c(floor(k.PANSSNeg),floor(num.PANSSNeg),round(mean.PANSSNeg,2),round(SE.PANSSNeg,2))

PSP<-c(floor(k.PSP),floor(num.PSP),round(mean.PSP,2),round(SE.PSP,2))

rownames1<-c("Male","","","","US","","","","Family history","","","","Smoking","","","","Drug use","","","",">=3 hospitalizations","","","","Hospitalized in previous year","","","","At least moderate TD","","","","At least moderate akathisia","","","","At least moderate EPS","","","","Age","","","","BMI","","","","Age at diagnosis","","","","Duration of illness","","","","CGI","","","","PANSS Total","","","","PANSS General","","","","PANSS Positive","","","","PANSS Negative","","","","Personal and social performance scale","","","")
rownames2<-c("k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD")
values<-c(male,US,fhx,smok,drug,threehosp,hosplyr,td,aka,eps,age,BMI,agediag,doi,CGI,PANSSTot,PANSSGen,PANSSPos,PANSSNeg,PSP)

mat<-cbind(rownames1,rownames2,values)

write.csv(mat,"C:/Users/jrubio13/desktop/processedtable1.csv") 

##############SUBSET WITH CONFIRMED REMISSION SAMPLE

data<-read.csv("[path]/table1remraw.csv", header=TRUE, sep=",")
num<-data[,2]

## categorical variables total - total

k.male<-length(data[1:19,2])
n.male<-sum(data[1:19,2],na.rm=T)
num.male<-sum(data[1:19,3],na.rm=T)
perc.male<-(num.male/n.male)*100

k.US<-length(data[1:19,2])
n.US<-sum(data[1:19,2],na.rm=T)
num.US<-sum(data[1:19,5],na.rm=T)
perc.US<-(num.US/n.US)*100

k.fhx<-length(data[c(10,15:17),2])
n.fhx<-sum(data[c(10,15:17),2],na.rm=T)
num.fhx<-sum(data[c(10,15:17),7],na.rm=T)
perc.fhx<-(num.fhx/n.fhx)*100

k.smok<-length(data[c(1:7,9,11:17),2])
n.smok<-sum(data[c(1:7,9,11:17),2],na.rm=T)
num.smok<-sum(data[c(1:7,9,11:17),9],na.rm=T)
perc.smok<-num.smok/n.smok*100

k.drug<-length(data[c(9,11:13),2])
n.drug<-sum((data[c(9,11:13),2]),na.rm=T)
num.drug<-sum(data[c(9,11:13),11],na.rm=T)
perc.drug<-num.drug/n.drug*100

k.3hosp<-length(data[c(1,10:17),2])
n.3hosp<-sum((data[c(1,10:17),2]),na.rm=T)
num.3hosp<-sum(data[c(1,10:17),13],na.rm=T)
perc.3hosp<-num.3hosp/n.3hosp*100

k.hosplyr<-length(data[c(1:6,13:17),2])
n.hosplyr<-sum((data[c(1:6,13:17),2]),na.rm=T)
num.hosplyr<-sum(data[c(1:6,13:17),15],na.rm=T)
perc.hosplyr<-num.hosplyr/n.hosplyr*100

k.td<-length(data[1:17,2])
n.td<-sum((data[1:17,2]),na.rm=T)
num.td<-sum(data[1:17,17],na.rm=T)
perc.td<-num.td/n.td*100

k.aka<-length(data[1:17,2])
n.aka<-sum((data[1:17,2]),na.rm=T)
num.aka<-sum(data[1:17,19],na.rm=T)
perc.aka<-num.aka/n.aka*100

k.eps<-length(data[1:17,2])
n.eps<-sum((data[1:17,2]),na.rm=T)
num.eps<-sum(data[1:17,21],na.rm=T)
perc.eps<-num.eps/n.eps*100

####NOW CONTINUOUS VARIABLES

k.age<-length(data[,2])
num.age<-sum(data[,2],na.rm=T)
n.age<-data[,2]
m.age<-data[,23]
sd.age<-data[,24]
age.pool<-escalc(measure="MN",ni=n.age,mi=m.age,sdi=sd.age)
yi<-age.pool[[1]]
vi<-age.pool[[2]]
age.rma<-rma.uni(yi,vi,method="REML")
mean.age<-as.numeric(age.rma[[1]])
SE.age<-age.rma[[3]]

#BMI
k.BMI<-length(data[,2])
num.BMI<-sum(data[,2],na.rm=T)
n.BMI<-data[,2]
m.BMI<-data[,25]
sd.BMI<-data[,26]
BMI.pool<-escalc(measure="MN",ni=n.BMI,mi=m.BMI,sdi=sd.BMI)
yi<-BMI.pool[[1]]
vi<-BMI.pool[[2]]
BMI.rma<-rma.uni(yi,vi,method="REML")
mean.BMI<-as.numeric(BMI.rma[[1]])
SE.BMI<-BMI.rma[[3]]


#AGEDIAG
k.agediag<-length(data[c(1:6,8,10:19),2])
num.agediag<-sum(data[c(1:6,8,10:19),2],na.rm=T)
n.agediag<-data[c(1:6,8,10:19),2]
m.agediag<-data[c(1:6,8,10:19),27]
sd.agediag<-data[c(1:6,8,10:19),28]
agediag.pool<-escalc(measure="MN",ni=n.agediag,mi=m.agediag,sdi=sd.agediag)
yi<-agediag.pool[[1]]
vi<-agediag.pool[[2]]
agediag.rma<-rma.uni(yi,vi,method="REML")
mean.agediag<-as.numeric(agediag.rma[[1]])
SE.agediag<-agediag.rma[[3]]


#DOI
k.doi<-length(data[c(1:6,8,10:19),2])
num.doi<-sum(data[c(1:6,8,10:19),2],na.rm=T)
n.doi<-data[c(1:6,8,10:19),2]
m.doi<-data[c(1:6,8,10:19),29]
sd.doi<-data[c(1:6,8,10:19),30]
doi.pool<-escalc(measure="MN",ni=n.doi,mi=m.doi,sdi=sd.doi)
yi<-doi.pool[[1]]
vi<-doi.pool[[2]]
doi.rma<-rma.uni(yi,vi,method="REML")
mean.doi<-as.numeric(doi.rma[[1]])
SE.doi<-doi.rma[[3]]


# CGI
k.CGI<-length(data[,2])
num.CGI<-sum(data[,2],na.rm=T)
n.CGI<-data[,2]
m.CGI<-data[,31]
sd.CGI<-data[,32]
CGI.pool<-escalc(measure="MN",ni=n.CGI,mi=m.CGI,sdi=sd.CGI)
yi<-CGI.pool[[1]]
vi<-CGI.pool[[2]]
CGI.rma<-rma.uni(yi,vi,method="REML")
mean.CGI<-as.numeric(CGI.rma[[1]])
SE.CGI<-CGI.rma[[3]]


# PANSSTot
k.PANSSTot<-length(data[c(1:12,14:19),2])
num.PANSSTot<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSTot<-data[c(1:12,14:19),2]
m.PANSSTot<-data[c(1:12,14:19),33]
sd.PANSSTot<-data[c(1:12,14:19),34]
PANSSTot.pool<-escalc(measure="MN",ni=n.PANSSTot,mi=m.PANSSTot,sdi=sd.PANSSTot)
yi<-PANSSTot.pool[[1]]
vi<-PANSSTot.pool[[2]]
PANSSTot.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSTot<-as.numeric(PANSSTot.rma[[1]])
SE.PANSSTot<-PANSSTot.rma[[3]]


# PANSSGen
k.PANSSGen<-length(data[c(1:12,14:19),2])
num.PANSSGen<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSGen<-data[c(1:12,14:19),2]
m.PANSSGen<-data[c(1:12,14:19),35]
sd.PANSSGen<-data[c(1:12,14:19),36]
PANSSGen.pool<-escalc(measure="MN",ni=n.PANSSGen,mi=m.PANSSGen,sdi=sd.PANSSGen)
yi<-PANSSGen.pool[[1]]
vi<-PANSSGen.pool[[2]]
PANSSGen.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSGen<-as.numeric(PANSSGen.rma[[1]])
SE.PANSSGen<-PANSSGen.rma[[3]]

# PANSSPos
k.PANSSPos<-length(data[c(1:12,14:19),2])
num.PANSSPos<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSPos<-data[c(1:12,14:19),2]
m.PANSSPos<-data[c(1:12,14:19),37]
sd.PANSSPos<-data[c(1:12,14:19),38]
PANSSPos.pool<-escalc(measure="MN",ni=n.PANSSPos,mi=m.PANSSPos,sdi=sd.PANSSPos)
yi<-PANSSPos.pool[[1]]
vi<-PANSSPos.pool[[2]]
PANSSPos.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSPos<-as.numeric(PANSSPos.rma[[1]])
SE.PANSSPos<-PANSSPos.rma[[3]]


# PANSSNeg
k.PANSSNeg<-length(data[c(1:12,14:19),2])
num.PANSSNeg<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSNeg<-data[c(1:12,14:19),2]
m.PANSSNeg<-data[c(1:12,14:19),39]
sd.PANSSNeg<-data[c(1:12,14:19),40]
PANSSNeg.pool<-escalc(measure="MN",ni=n.PANSSNeg,mi=m.PANSSNeg,sdi=sd.PANSSNeg)
yi<-PANSSNeg.pool[[1]]
vi<-PANSSNeg.pool[[2]]
PANSSNeg.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSNeg<-as.numeric(PANSSNeg.rma[[1]])
SE.PANSSNeg<-PANSSNeg.rma[[3]]

#PSP
k.PSP<-length(data[c(1:3,7,9:10),2])
num.PSP<-sum(data[c(1:3,7,9:10),2],na.rm=T)
n.PSP<-data[c(1:3,7,9:10),2]
m.PSP<-data[c(1:3,7,9:10),41]
sd.PSP<-data[c(1:3,7,9:10),42]
PSP.pool<-escalc(measure="MN",ni=n.PSP,mi=m.PSP,sdi=sd.PSP)
yi<-PSP.pool[[1]]
vi<-PSP.pool[[2]]
PSP.rma<-rma.uni(yi,vi,method="REML")
mean.PSP<-as.numeric(PSP.rma[[1]])
SE.PSP<-PSP.rma[[3]]*sqrt(k.PSP)


male<-round(c(k.male,n.male,num.male,perc.male),2)

US<-round(c(k.US,n.US,num.US,perc.US),2)

fhx<-round(c(k.fhx,n.fhx,num.fhx,perc.fhx),2)

smok<-round(c(k.smok,n.smok,num.smok,perc.smok),2)

drug<-round(c(k.drug,n.drug,num.drug,perc.drug),2)

threehosp<-round(c(k.3hosp,n.3hosp,num.3hosp,perc.3hosp),2)

hosplyr<-round(c(k.hosplyr,n.hosplyr,num.hosplyr,perc.hosplyr),2)

td<-round(c(k.td,n.td,num.td,perc.td),2)

aka<-round(c(k.aka,n.aka,num.aka,perc.aka),2)

eps<-round(c(k.eps,n.eps,num.eps,perc.eps),2)

age<-c(floor(k.age),floor(num.age),round(mean.age,2),round(SE.age,2))

BMI<-c(floor(k.BMI),floor(num.BMI),round(mean.BMI,2),round(SE.BMI,2))

agediag<-c(floor(k.agediag),floor(num.agediag),round(mean.agediag,2),round(SE.agediag,2))

doi<-c(floor(k.doi),floor(num.doi),round(mean.doi,2),round(SE.doi,2))

CGI<-c(floor(k.CGI),floor(num.CGI),round(mean.CGI,2),round(SE.CGI,2))

PANSSTot<-c(floor(k.PANSSTot),floor(num.PANSSTot),round(mean.PANSSTot,2),round(SE.PANSSTot,2))

PANSSGen<-c(floor(k.PANSSGen),floor(num.PANSSGen),round(mean.PANSSGen,2),round(SE.PANSSGen,2))

PANSSPos<-c(floor(k.PANSSPos),floor(num.PANSSPos),round(mean.PANSSPos,2),round(SE.PANSSPos,2))

PANSSNeg<-c(floor(k.PANSSNeg),floor(num.PANSSNeg),round(mean.PANSSNeg,2),round(SE.PANSSNeg,2))

PSP<-c(floor(k.PSP),floor(num.PSP),round(mean.PSP,2),round(SE.PSP,2))

rownames1<-c("Male","","","","US","","","","Family history","","","","Smoking","","","","Drug use","","","",">=3 hospitalizations","","","","Hospitalized in previous year","","","","At least moderate TD","","","","At least moderate akathisia","","","","At least moderate EPS","","","","Age","","","","BMI","","","","Age at diagnosis","","","","Duration of illness","","","","CGI","","","","PANSS Total","","","","PANSS General","","","","PANSS Positive","","","","PANSS Negative","","","","Personal and social performance scale","","","")
rownames2<-c("k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD")
values<-c(male,US,fhx,smok,drug,threehosp,hosplyr,td,aka,eps,age,BMI,agediag,doi,CGI,PANSSTot,PANSSGen,PANSSPos,PANSSNeg,PSP)

mat<-cbind(rownames1,rownames2,values)

write.csv(mat,"[path]/processedtable1rem.csv") 


############## SUBSET WITH RESIDUAL SX

data<-read.csv("[path]/table1noremraw.csv", header=TRUE, sep=",")
num<-data[,2]

## categorical variables total - total

#add values to total n and also consider changing the script to count only those which !is.na

k.male<-data[1:19,2]
k.male<-k.male[!is.na(k.male)]
k.male<-length(k.male)
n.male<-sum(data[1:19,2],na.rm=T)
num.male<-sum(data[1:19,3],na.rm=T)
perc.male<-(num.male/n.male)*100

k.US<-data[1:19,2]
k.US<-k.male[!is.na(k.US)]
k.US<-length(k.US)
n.US<-sum(data[1:19,2],na.rm=T)
num.US<-sum(data[1:19,5],na.rm=T)
perc.US<-(num.US/n.US)*100

k.fhx<-data[c(10,15:17),2]
k.fhx<-k.fhx[!is.na(k.fhx)]
k.fhx<-length(k.fhx)
n.fhx<-sum(data[c(10,15:17),2],na.rm=T)
num.fhx<-sum(data[c(10,15:17),7],na.rm=T)
perc.fhx<-(num.fhx/n.fhx)*100


k.smok<-data[c(1:7,9,11:17),2]
k.smok<-k.smok[!is.na(k.smok)]
k.smok<-length(k.smok)
n.smok<-sum(data[c(1:7,9,11:17),2],na.rm=T)
num.smok<-sum(data[c(1:7,9,11:17),9],na.rm=T)
perc.smok<-num.smok/n.smok*100

k.drug<-data[c(9,11:13),2]
k.drug<-k.drug[!is.na(k.drug)]
k.drug<-length(k.drug)
n.drug<-sum((data[c(9,11:13),2]),na.rm=T)
num.drug<-sum(data[c(9,11:13),11],na.rm=T)
perc.drug<-num.drug/n.drug*100

k.3hosp<-data[c(1,10:17),2]
k.3hosp<-k.3hosp[!is.na(k.3hosp)]
k.3hosp<-length(k.3hosp)
n.3hosp<-sum((data[c(1,10:17),2]),na.rm=T)
num.3hosp<-sum(data[c(1,10:17),13],na.rm=T)
perc.3hosp<-num.3hosp/n.3hosp*100

k.hosplyr<-data[c(1:6,13:17),2]
k.hosplyr<-k.hosplyr[!is.na(k.hosplyr)]
k.hosplyr<-length(k.hosplyr)
n.hosplyr<-sum((data[c(1:6,13:17),2]),na.rm=T)
num.hosplyr<-sum(data[c(1:6,13:17),15],na.rm=T)
perc.hosplyr<-num.hosplyr/n.hosplyr*100

k.td<-data[1:19,2]
k.td<-k.td[!is.na(k.td)]
k.td<-length(k.td)
n.td<-sum((data[1:17,2]),na.rm=T)
num.td<-sum(data[1:17,17],na.rm=T)
perc.td<-num.td/n.td*100

k.aka<-data[1:19,2]
k.aka<-k.aka[!is.na(k.aka)]
k.aka<-length(k.aka)
n.aka<-sum((data[1:17,2]),na.rm=T)
num.aka<-sum(data[1:17,19],na.rm=T)
perc.aka<-num.aka/n.aka*100

k.eps<-data[1:19,2]
k.eps<-k.eps[!is.na(k.eps)]
k.eps<-length(k.eps)
n.eps<-sum((data[1:17,2]),na.rm=T)
num.eps<-sum(data[1:17,21],na.rm=T)
perc.eps<-num.eps/n.eps*100

####NOW CONTINUOUS VARIABLES

k.age<-data[1:19,2]
k.age<-k.age[!is.na(k.age)]
k.age<-length(k.age)
num.age<-sum(data[,2],na.rm=T)
n.age<-data[,2]
m.age<-data[,23]
sd.age<-data[,24]
age.pool<-escalc(measure="MN",ni=n.age,mi=m.age,sdi=sd.age)
yi<-age.pool[[1]]
vi<-age.pool[[2]]
age.rma<-rma.uni(yi,vi,method="REML")
mean.age<-as.numeric(age.rma[[1]])
SE.age<-age.rma[[3]]

#BMI
k.BMI<-data[1:19,2]
k.BMI<-k.BMI[!is.na(k.BMI)]
k.BMI<-length(k.BMI)
num.BMI<-sum(data[,2],na.rm=T)
n.BMI<-data[,2]
m.BMI<-data[,25]
sd.BMI<-data[,26]
BMI.pool<-escalc(measure="MN",ni=n.BMI,mi=m.BMI,sdi=sd.BMI)
yi<-BMI.pool[[1]]
vi<-BMI.pool[[2]]
BMI.rma<-rma.uni(yi,vi,method="REML")
mean.BMI<-as.numeric(BMI.rma[[1]])
SE.BMI<-BMI.rma[[3]]


#AGEDIAG
k.agediag<-data[c(1:6,8,10:19),2]
k.agediag<-k.agediag[!is.na(k.agediag)]
k.agediag<-length(k.agediag)
num.agediag<-sum(data[c(1:6,8,10:19),2],na.rm=T)
n.agediag<-data[c(1:6,8,10:19),2]
m.agediag<-data[c(1:6,8,10:19),27]
sd.agediag<-data[c(1:6,8,10:19),28]
agediag.pool<-escalc(measure="MN",ni=n.agediag,mi=m.agediag,sdi=sd.agediag)
yi<-agediag.pool[[1]]
vi<-agediag.pool[[2]]
agediag.rma<-rma.uni(yi,vi,method="REML")
mean.agediag<-as.numeric(agediag.rma[[1]])
SE.agediag<-agediag.rma[[3]]


#DOI
k.doi<-data[c(1:6,8,10:19),2]
k.doi<-k.doi[!is.na(k.doi)]
k.doi<-length(k.doi)
num.doi<-sum(data[c(1:6,8,10:19),2],na.rm=T)
n.doi<-data[c(1:6,8,10:19),2]
m.doi<-data[c(1:6,8,10:19),29]
sd.doi<-data[c(1:6,8,10:19),30]
doi.pool<-escalc(measure="MN",ni=n.doi,mi=m.doi,sdi=sd.doi)
yi<-doi.pool[[1]]
vi<-doi.pool[[2]]
doi.rma<-rma.uni(yi,vi,method="REML")
mean.doi<-as.numeric(doi.rma[[1]])
SE.doi<-doi.rma[[3]]


# CGI
k.CGI<-data[1:19,2]
k.CGI<-k.CGI[!is.na(k.CGI)]
k.CGI<-length(k.CGI)
num.CGI<-sum(data[,2],na.rm=T)
n.CGI<-data[,2]
m.CGI<-data[,31]
sd.CGI<-data[,32]
CGI.pool<-escalc(measure="MN",ni=n.CGI,mi=m.CGI,sdi=sd.CGI)
yi<-CGI.pool[[1]]
vi<-CGI.pool[[2]]
CGI.rma<-rma.uni(yi,vi,method="REML")
mean.CGI<-as.numeric(CGI.rma[[1]])
SE.CGI<-CGI.rma[[3]]


# PANSSTot
k.PANSSTot<-data[c(1:12,14:19),2]
k.PANSSTot<-k.PANSSTot[!is.na(k.PANSSTot)]
k.PANSSTot<-length(k.PANSSTot)
num.PANSSTot<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSTot<-data[c(1:12,14:19),2]
m.PANSSTot<-data[c(1:12,14:19),33]
sd.PANSSTot<-data[c(1:12,14:19),34]
PANSSTot.pool<-escalc(measure="MN",ni=n.PANSSTot,mi=m.PANSSTot,sdi=sd.PANSSTot)
yi<-PANSSTot.pool[[1]]
vi<-PANSSTot.pool[[2]]
PANSSTot.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSTot<-as.numeric(PANSSTot.rma[[1]])
SE.PANSSTot<-PANSSTot.rma[[3]]


# PANSSGen
k.PANSSGen<-data[c(1:12,14:19),2]
k.PANSSGen<-k.PANSSGen[!is.na(k.PANSSGen)]
k.PANSSGen<-length(k.PANSSGen)
num.PANSSGen<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSGen<-data[c(1:12,14:19),2]
m.PANSSGen<-data[c(1:12,14:19),35]
sd.PANSSGen<-data[c(1:12,14:19),36]
PANSSGen.pool<-escalc(measure="MN",ni=n.PANSSGen,mi=m.PANSSGen,sdi=sd.PANSSGen)
yi<-PANSSGen.pool[[1]]
vi<-PANSSGen.pool[[2]]
PANSSGen.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSGen<-as.numeric(PANSSGen.rma[[1]])
SE.PANSSGen<-PANSSGen.rma[[3]]

# PANSSPos
k.PANSSPos<-data[c(1:12,14:19),2]
k.PANSSPos<-k.PANSSPos[!is.na(k.PANSSPos)]
k.PANSSPos<-length(k.PANSSPos)
num.PANSSPos<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSPos<-data[c(1:12,14:19),2]
m.PANSSPos<-data[c(1:12,14:19),37]
sd.PANSSPos<-data[c(1:12,14:19),38]
PANSSPos.pool<-escalc(measure="MN",ni=n.PANSSPos,mi=m.PANSSPos,sdi=sd.PANSSPos)
yi<-PANSSPos.pool[[1]]
vi<-PANSSPos.pool[[2]]
PANSSPos.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSPos<-as.numeric(PANSSPos.rma[[1]])
SE.PANSSPos<-PANSSPos.rma[[3]]


# PANSSNeg
k.PANSSNeg<-data[c(1:12,14:19),2]
k.PANSSNeg<-k.PANSSNeg[!is.na(k.PANSSNeg)]
k.PANSSNeg<-length(k.PANSSNeg)
num.PANSSNeg<-sum(data[c(1:12,14:19),2],na.rm=T)
n.PANSSNeg<-data[c(1:12,14:19),2]
m.PANSSNeg<-data[c(1:12,14:19),39]
sd.PANSSNeg<-data[c(1:12,14:19),40]
PANSSNeg.pool<-escalc(measure="MN",ni=n.PANSSNeg,mi=m.PANSSNeg,sdi=sd.PANSSNeg)
yi<-PANSSNeg.pool[[1]]
vi<-PANSSNeg.pool[[2]]
PANSSNeg.rma<-rma.uni(yi,vi,method="REML")
mean.PANSSNeg<-as.numeric(PANSSNeg.rma[[1]])
SE.PANSSNeg<-PANSSNeg.rma[[3]]

#PSP
k.PSP<-data[c(1:3,7,9:10),2]
k.PSP<-k.PSP[!is.na(k.PSP)]
k.PSP<-length(k.PSP)
num.PSP<-sum(data[c(1:3,7,9:10),2],na.rm=T)
n.PSP<-data[c(1:3,7,9:10),2]
m.PSP<-data[c(1:3,7,9:10),41]
sd.PSP<-data[c(1:3,7,9:10),42]
PSP.pool<-escalc(measure="MN",ni=n.PSP,mi=m.PSP,sdi=sd.PSP)
yi<-PSP.pool[[1]]
vi<-PSP.pool[[2]]
PSP.rma<-rma.uni(yi,vi,method="REML")
mean.PSP<-as.numeric(PSP.rma[[1]])
SE.PSP<-PSP.rma[[3]]*sqrt(k.PSP)


male<-round(c(k.male,n.male,num.male,perc.male),2)

US<-round(c(k.US,n.US,num.US,perc.US),2)

fhx<-round(c(k.fhx,n.fhx,num.fhx,perc.fhx),2)

smok<-round(c(k.smok,n.smok,num.smok,perc.smok),2)

drug<-round(c(k.drug,n.drug,num.drug,perc.drug),2)

threehosp<-round(c(k.3hosp,n.3hosp,num.3hosp,perc.3hosp),2)

hosplyr<-round(c(k.hosplyr,n.hosplyr,num.hosplyr,perc.hosplyr),2)

td<-round(c(k.td,n.td,num.td,perc.td),2)

aka<-round(c(k.aka,n.aka,num.aka,perc.aka),2)

eps<-round(c(k.eps,n.eps,num.eps,perc.eps),2)

age<-c(floor(k.age),floor(num.age),round(mean.age,2),round(SE.age,2))

BMI<-c(floor(k.BMI),floor(num.BMI),round(mean.BMI,2),round(SE.BMI,2))

agediag<-c(floor(k.agediag),floor(num.agediag),round(mean.agediag,2),round(SE.agediag,2))

doi<-c(floor(k.doi),floor(num.doi),round(mean.doi,2),round(SE.doi,2))

CGI<-c(floor(k.CGI),floor(num.CGI),round(mean.CGI,2),round(SE.CGI,2))

PANSSTot<-c(floor(k.PANSSTot),floor(num.PANSSTot),round(mean.PANSSTot,2),round(SE.PANSSTot,2))

PANSSGen<-c(floor(k.PANSSGen),floor(num.PANSSGen),round(mean.PANSSGen,2),round(SE.PANSSGen,2))

PANSSPos<-c(floor(k.PANSSPos),floor(num.PANSSPos),round(mean.PANSSPos,2),round(SE.PANSSPos,2))

PANSSNeg<-c(floor(k.PANSSNeg),floor(num.PANSSNeg),round(mean.PANSSNeg,2),round(SE.PANSSNeg,2))

PSP<-c(floor(k.PSP),floor(num.PSP),round(mean.PSP,2),round(SE.PSP,2))

rownames1<-c("Male","","","","US","","","","Family history","","","","Smoking","","","","Drug use","","","",">=3 hospitalizations","","","","Hospitalized in previous year","","","","At least moderate TD","","","","At least moderate akathisia","","","","At least moderate EPS","","","","Age","","","","BMI","","","","Age at diagnosis","","","","Duration of illness","","","","CGI","","","","PANSS Total","","","","PANSS General","","","","PANSS Positive","","","","PANSS Negative","","","","Personal and social performance scale","","","")
rownames2<-c("k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","n with condition","%","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD","k","n","Mean","SD")
values<-c(male,US,fhx,smok,drug,threehosp,hosplyr,td,aka,eps,age,BMI,agediag,doi,CGI,PANSSTot,PANSSGen,PANSSPos,PANSSNeg,PSP)

mat<-cbind(rownames1,rownames2,values)

write.csv(mat,"[path]/processedtable1norem.csv")

###########NOW COMPARISONS BETWEEN REM AND NO.REM

rem.data<-read.csv("[path]/table1remraw.csv")

no.rem.data<-read.csv("[path]/table1noremraw.csv")

#comparisons for categorical variables

#male gender
n.male.rem<-rem.data[1:19,2]
num.male.rem<-rem.data[1:19,3]
n.male.no.rem<-no.rem.data[1:19,2]
num.male.no.rem<-no.rem.data[1:19,3]

male.pool<-escalc(measure="RD",ai=num.male.rem,n1i=n.male.rem,
                  ci=num.male.no.rem,n2i=n.male.no.rem)
yi<-male.pool[[1]]
vi<-male.pool[[2]]
male.rma<-rma.uni(yi,vi,method="REML")
p.male<-male.rma[[5]]

#US

n.US.rem<-rem.data[1:19,2]
num.US.rem<-rem.data[1:19,5]
n.US.no.rem<-no.rem.data[1:19,2]
num.US.no.rem<-no.rem.data[1:19,5]

US.pool<-escalc(measure="RD",ai=num.US.rem,n1i=n.US.rem,
                ci=num.US.no.rem,n2i=n.US.no.rem)
yi<-US.pool[[1]]
vi<-US.pool[[2]]
US.rma<-rma.uni(yi,vi,method="REML")
p.US<-US.rma[[5]]


#FHX

n.fhx.rem<-rem.data[c(10,15:17),2]
num.fhx.rem<-rem.data[c(10,15:17),7]
n.fhx.no.rem<-no.rem.data[c(10,15:17),2]
num.fhx.no.rem<-no.rem.data[c(10,15:17),7]

fhx.pool<-escalc(measure="RD",ai=num.fhx.rem,n1i=n.fhx.rem,
                 ci=num.fhx.no.rem,n2i=n.fhx.no.rem)
yi<-fhx.pool[[1]]
vi<-fhx.pool[[2]]
fhx.rma<-rma.uni(yi,vi,method="REML")
p.fhx<-fhx.rma[[5]]

#SMOKING

n.smok.rem<-rem.data[c(1:7,9,11:17),2]
num.smok.rem<-rem.data[c(1:7,9,11:17),9]
n.smok.no.rem<-no.rem.data[c(1:7,9,11:17),2]
num.smok.no.rem<-no.rem.data[c(1:7,9,11:17),9]

smok.pool<-escalc(measure="RD",ai=num.smok.rem,n1i=n.smok.rem,
                  ci=num.smok.no.rem,n2i=n.smok.no.rem)
yi<-smok.pool[[1]]
vi<-smok.pool[[2]]
smok.rma<-rma.uni(yi,vi,method="REML")
p.smok<-smok.rma[[5]]

#DRUGS
n.drug.rem<-rem.data[c(9,11:13),2]
num.drug.rem<-rem.data[c(9,11:13),11]
n.drug.no.rem<-no.rem.data[c(9,11:13),2]
num.drug.no.rem<-no.rem.data[c(9,11:13),11]

drug.pool<-escalc(measure="RD",ai=num.drug.rem,n1i=n.drug.rem,
                  ci=num.drug.no.rem,n2i=n.drug.no.rem)
yi<-drug.pool[[1]]
vi<-drug.pool[[2]]
drug.rma<-rma.uni(yi,vi,method="REML")
p.drug<-drug.rma[[5]]

#>3 HOSPITALIZATIONS

n.3hosp.rem<-rem.data[c(1,10:17),2]
num.3hosp.rem<-rem.data[c(1,10:17),13]
n.3hosp.no.rem<-no.rem.data[c(1,10:17),2]
num.3hosp.no.rem<-no.rem.data[c(1,10:17),13]

n.3hosp.pool<-escalc(measure="RD",ai=num.3hosp.rem,n1i=n.3hosp.rem,
                     ci=num.3hosp.no.rem,n2i=n.3hosp.no.rem)
yi<-n.3hosp.pool[[1]]
vi<-n.3hosp.pool[[2]]
n.3hosp.rma<-rma.uni(yi,vi,method="REML")
p.3hosp<-n.3hosp.rma[[5]]

#HOSPITALIZED LAST YEAR

n.hosplyr.rem<-rem.data[c(1:6,13:17),2]
num.hosplyr.rem<-rem.data[c(1:6,13:17),15]
n.hosplyr.no.rem<-no.rem.data[c(1:6,13:17),2]
num.hosplyr.no.rem<-no.rem.data[c(1:6,13:17),15]

hosplyr.pool<-escalc(measure="RD",ai=num.hosplyr.rem,n1i=n.hosplyr.rem,
                     ci=num.hosplyr.no.rem,n2i=n.hosplyr.no.rem)
yi<-hosplyr.pool[[1]]
vi<-hosplyr.pool[[2]]
hosplyr.rma<-rma.uni(yi,vi,method="REML")
p.hosplyr<-hosplyr.rma[[5]]

#TD
n.td.rem<-rem.data[1:17,2]
num.td.rem<-rem.data[1:17,17]
n.td.no.rem<-rem.data[1:17,2]
num.td.no.rem<-no.rem.data[1:17,17]

td.pool<-escalc(measure="RD",ai=num.td.rem,n1i=n.td.rem,
                ci=num.td.no.rem,n2i=n.td.no.rem)
yi<-td.pool[[1]]
vi<-td.pool[[2]]
td.rma<-rma.uni(yi,vi,method="REML")
p.td<-td.rma[[5]]

#AKATHISIA

n.aka.rem<-rem.data[1:17,2]
num.aka.rem<-rem.data[1:17,19]
n.aka.no.rem<-no.rem.data[1:17,2]
num.aka.no.rem<-no.rem.data[1:17,19]

aka.pool<-escalc(measure="RD",ai=num.aka.rem,n1i=n.aka.rem,
                 ci=num.aka.no.rem,n2i=n.aka.no.rem)
yi<-aka.pool[[1]]
vi<-aka.pool[[2]]
aka.rma<-rma.uni(yi,vi,method="REML")
p.aka<-aka.rma[[5]]

#EPS

n.eps.rem<-rem.data[1:17,2]
num.eps.rem<-rem.data[1:17,21]
n.eps.no.rem<-no.rem.data[1:17,2]
num.eps.no.rem<-no.rem.data[1:17,21]

eps.pool<-escalc(measure="RD",ai=num.eps.rem,n1i=n.eps.rem,
                 ci=num.eps.no.rem,n2i=n.eps.no.rem)
yi<-eps.pool[[1]]
vi<-eps.pool[[2]]
eps.rma<-rma.uni(yi,vi,method="REML")
p.eps<-eps.rma[[5]]

#comparisons for continuous variables 

#age
n.age.rem<-rem.data[,2]
m.age.rem<-rem.data[,23]
sd.age.rem<-rem.data[,24]
n.age.no.rem<-no.rem.data[,2]
m.age.no.rem<-no.rem.data[,23]
sd.age.no.rem<-no.rem.data[,24]

age.pool<-escalc(measure="MD",n1i=n.age.rem,m1i=m.age.rem,sd1i=sd.age.rem,n2i=n.age.no.rem,m2i=m.age.no.rem,sd2i=sd.age.no.rem)
yi<-age.pool[[1]]
vi<-age.pool[[2]]
age.rma<-rma.uni(yi,vi,method="REML")
p.age<-age.rma[[5]]

#BMI
n.BMI.rem<-rem.data[,2]
m.BMI.rem<-rem.data[,25]
sd.BMI.rem<-rem.data[,26]
n.BMI.no.rem<-no.rem.data[,2]
m.BMI.no.rem<-no.rem.data[,25]
sd.BMI.no.rem<-no.rem.data[,26]

BMI.pool<-escalc(measure="MD",n1i=n.BMI.rem,m1i=m.BMI.rem,sd1i=sd.BMI.rem,n2i=n.BMI.no.rem,m2i=m.BMI.no.rem,sd2i=sd.BMI.no.rem)
yi<-BMI.pool[[1]]
vi<-BMI.pool[[2]]
BMI.rma<-rma.uni(yi,vi,method="REML")
p.BMI<-BMI.rma[[5]]

#AGEDIAG
n.agediag.rem<-rem.data[c(1:6,8,10:19),2]
m.agediag.rem<-rem.data[c(1:6,8,10:19),27]
sd.agediag.rem<-rem.data[c(1:6,8,10:19),28]
n.agediag.no.rem<-no.rem.data[c(1:6,8,10:19),2]
m.agediag.no.rem<-no.rem.data[c(1:6,8,10:19),27]
sd.agediag.no.rem<-no.rem.data[c(1:6,8,10:19),28]

agediag.pool<-escalc(measure="MD",n1i=n.agediag.rem,m1i=m.agediag.rem,sd1i=sd.agediag.rem,n2i=n.agediag.no.rem,m2i=m.agediag.no.rem,sd2i=sd.agediag.no.rem)
yi<-agediag.pool[[1]]
vi<-agediag.pool[[2]]
agediag.rma<-rma.uni(yi,vi,method="REML")
p.agediag<-agediag.rma[[5]]


#DOI
n.doi.rem<-rem.data[c(1:6,8,10:19),2]
m.doi.rem<-rem.data[c(1:6,8,10:19),29]
sd.doi.rem<-rem.data[c(1:6,8,10:19),30]
n.doi.no.rem<-no.rem.data[c(1:6,8,10:19),2]
m.doi.no.rem<-no.rem.data[c(1:6,8,10:19),29]
sd.doi.no.rem<-no.rem.data[c(1:6,8,10:19),30]

doi.pool<-escalc(measure="MD",n1i=n.doi.rem,m1i=m.doi.rem,sd1i=sd.doi.rem,n2i=n.doi.no.rem,m2i=m.doi.no.rem,sd2i=sd.doi.no.rem)
yi<-doi.pool[[1]]
vi<-doi.pool[[2]]
doi.rma<-rma.uni(yi,vi,method="REML")
p.doi<-doi.rma[[5]]

# CGI
n.CGI.rem<-rem.data[,2]
m.CGI.rem<-rem.data[,31]
sd.CGI.rem<-rem.data[,32]
n.CGI.no.rem<-no.rem.data[,2]
m.CGI.no.rem<-no.rem.data[,31]
sd.CGI.no.rem<-no.rem.data[,32]
CGI.pool<-escalc(measure="MD",n1i=n.CGI.rem,m1i=m.CGI.rem,sd1i=sd.CGI.rem,n2i=n.CGI.no.rem,m2i=m.CGI.no.rem,sd2i=sd.CGI.no.rem)
yi<-CGI.pool[[1]]
vi<-CGI.pool[[2]]
CGI.rma<-rma.uni(yi,vi,method="REML")
p.CGI<-CGI.rma[[5]]

# PANSSTot
n.PANSSTot.rem<-rem.data[c(1:12,14:19),2]
m.PANSSTot.rem<-rem.data[c(1:12,14:19),33]
sd.PANSSTot.rem<-rem.data[c(1:12,14:19),34]
n.PANSSTot.no.rem<-no.rem.data[c(1:12,14:19),2]
m.PANSSTot.no.rem<-no.rem.data[c(1:12,14:19),33]
sd.PANSSTot.no.rem<-no.rem.data[c(1:12,14:19),34]

PANSSTot.pool<-escalc(measure="MD",n1i=n.PANSSTot.rem,m1i=m.PANSSTot.rem,sd1i=sd.PANSSTot.rem,n2i=n.PANSSTot.no.rem,m2i=m.PANSSTot.no.rem,sd2i=sd.PANSSTot.no.rem)
yi<-PANSSTot.pool[[1]]
vi<-PANSSTot.pool[[2]]
PANSSTot.rma<-rma.uni(yi,vi,method="REML")
p.PANSSTot<-PANSSTot.rma[[5]]

# PANSSGen
n.PANSSGen.rem<-rem.data[c(1:12,14:19),2]
m.PANSSGen.rem<-rem.data[c(1:12,14:19),35]
sd.PANSSGen.rem<-rem.data[c(1:12,14:19),36]
n.PANSSGen.no.rem<-no.rem.data[c(1:12,14:19),2]
m.PANSSGen.no.rem<-no.rem.data[c(1:12,14:19),35]
sd.PANSSGen.no.rem<-no.rem.data[c(1:12,14:19),36]

PANSSGen.pool<-escalc(measure="MD",n1i=n.PANSSGen.rem,m1i=m.PANSSGen.rem,sd1i=sd.PANSSGen.rem,n2i=n.PANSSGen.no.rem,m2i=m.PANSSGen.no.rem,sd2i=sd.PANSSGen.no.rem)
yi<-PANSSGen.pool[[1]]
vi<-PANSSGen.pool[[2]]
PANSSGen.rma<-rma.uni(yi,vi,method="REML")
p.PANSSGen<-PANSSGen.rma[[5]]

# PANSSPos
n.PANSSPos.rem<-rem.data[c(1:12,14:19),2]
m.PANSSPos.rem<-rem.data[c(1:12,14:19),37]
sd.PANSSPos.rem<-rem.data[c(1:12,14:19),38]
n.PANSSPos.no.rem<-no.rem.data[c(1:12,14:19),2]
m.PANSSPos.no.rem<-no.rem.data[c(1:12,14:19),37]
sd.PANSSPos.no.rem<-no.rem.data[c(1:12,14:19),38]
PANSSPos.pool<-escalc(measure="MD",n1i=n.PANSSPos.rem,m1i=m.PANSSPos.rem,sd1i=sd.PANSSPos.rem,n2i=n.PANSSPos.no.rem,m2i=m.PANSSPos.no.rem,sd2i=sd.PANSSPos.no.rem)
yi<-PANSSPos.pool[[1]]
vi<-PANSSPos.pool[[2]]
PANSSPos.rma<-rma.uni(yi,vi,method="REML")
p.PANSSPos<-PANSSPos.rma[[5]]

# PANSSNeg
n.PANSSNeg.rem<-rem.data[c(1:12,14:19),2]
m.PANSSNeg.rem<-rem.data[c(1:12,14:19),39]
sd.PANSSNeg.rem<-rem.data[c(1:12,14:19),40]
n.PANSSNeg.no.rem<-no.rem.data[c(1:12,14:19),2]
m.PANSSNeg.no.rem<-no.rem.data[c(1:12,14:19),39]
sd.PANSSNeg.no.rem<-no.rem.data[c(1:12,14:19),40]

PANSSNeg.pool<-escalc(measure="MD",n1i=n.PANSSNeg.rem,m1i=m.PANSSNeg.rem,sd1i=sd.PANSSNeg.rem,n2i=n.PANSSNeg.no.rem,m2i=m.PANSSNeg.no.rem,sd2i=sd.PANSSNeg.no.rem)
yi<-PANSSNeg.pool[[1]]
vi<-PANSSNeg.pool[[2]]
PANSSNeg.rma<-rma.uni(yi,vi,method="REML")
p.PANSSNeg<-PANSSNeg.rma[[5]]

#PSP
# PSP
n.PSP.rem<-rem.data[c(1:3,7,9:10),2]
m.PSP.rem<-rem.data[c(1:3,7,9:10),41]
sd.PSP.rem<-rem.data[c(1:3,7,9:10),42]
n.PSP.no.rem<-no.rem.data[c(1:3,7,9:10),2]
m.PSP.no.rem<-no.rem.data[c(1:3,7,9:10),41]
sd.PSP.no.rem<-no.rem.data[c(1:3,7,9:10),42]

PSP.pool<-escalc(measure="MD",n1i=n.PSP.rem,m1i=m.PSP.rem,sd1i=sd.PSP.rem,n2i=n.PSP.no.rem,m2i=m.PSP.no.rem,sd2i=sd.PSP.no.rem)
yi<-PSP.pool[[1]]
vi<-PSP.pool[[2]]
PSP.rma<-rma.uni(yi,vi,method="REML")
p.PSP<-PSP.rma[[5]]

p.column<-cbind(p.male,p.US,p.fhx,p.smok,p.drug,p.3hosp,p.hosplyr,p.td,p.aka,p.eps,p.age,p.BMI,p.doi,p.CGI,p.PANSSTot,p.PANSSGen,p.PANSSPos,p.PANSSNeg,p.PSP)


